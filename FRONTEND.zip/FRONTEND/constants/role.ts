export enum ROLE  {
    ADMIN=  2,
    WRITER= 1,
    READER= 0
}