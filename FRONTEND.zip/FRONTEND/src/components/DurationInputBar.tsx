import React from 'react';
import { createStyles, makeStyles, withStyles, Theme } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import NativeSelect from '@material-ui/core/NativeSelect';
import InputBase from '@material-ui/core/InputBase';
import { Box, Grid, TextField, Typography } from '@material-ui/core';
import LoadingButton from './LoadingButton';


const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        margin: {
            margin: theme.spacing(1),
        },
    }),
);

type Props = {
    getDataFromRange: (days: number, hours: number, minutes: number) => Promise<void>;
};

const DurationInputBar: React.FC<Props> = ({ getDataFromRange }) => {
    const classes = useStyles();
    const [loading, setLoading] = React.useState<boolean>(false);
    const [minutes, setMinutes] = React.useState<number>(10);
    const [hours, setHours] = React.useState<number>(0);
    const [days, setDays] = React.useState<number>(0);

    const handleChange = (event: React.ChangeEvent<{ value: string }>, setState: (value: number) => void, min: number, max: number) => {
        let value = event.target.value;
        if (value.startsWith("0")) {
            value = value.substring(1);
        }
        var intVaule = parseInt(value);
        if (isNaN(intVaule)) {
            if (value == "") {
                setState(0)
            }
        } else if (intVaule >= min && intVaule <= max) {
            setState(intVaule)
        }
        //changeRangeOptions(days, hours, minutes);
    };

    const getData = async () => {
        setLoading(true);
        await getDataFromRange(days, hours, minutes);
        setLoading(false);
    }

    const verified = (): boolean => days != 0 || hours != 0 || minutes != 0;

    return <>
        <Box mb={2}>
            <Grid container direction="column" spacing={1}>
                <Grid item>
                    <Typography>Velg tidsintervall</Typography>
                </Grid>
                <Grid item>
                    <Grid container direction="row" spacing={1}>
                        <Grid item>
                            <TextField
                                label="Dager"
                                variant="outlined"
                                InputProps={{ inputProps: { min: 0, max: 1000 } }}
                                fullWidth
                                type="number"
                                value={days}
                                onChange={(e) => handleChange(e, setDays, 0, 1000)}
                            />
                        </Grid>
                        <Grid item>
                            <TextField
                                label="Timer"
                                variant="outlined"
                                InputProps={{ inputProps: { min: 0, max: 60 } }}
                                fullWidth
                                type="number"
                                value={hours}
                                onChange={(e) => handleChange(e, setHours, 0, 60)}
                            />
                        </Grid>
                        <Grid item>
                            <TextField
                                label="Minutt"
                                variant="outlined"
                                InputProps={{ inputProps: { min: 0, max: 60 } }}
                                fullWidth
                                type="number"
                                value={minutes}
                                onChange={(e) => handleChange(e, setMinutes, 0, 60)}
                            />
                        </Grid>
                        <Grid item>
                            <LoadingButton
                                disabled={loading || !verified()}
                                loading={loading}
                                width="120px"
                                onClick={getData}
                                label="Hent Data"
                            />
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Box>
    </>
}
export default DurationInputBar;