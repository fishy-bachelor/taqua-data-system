import {
  makeStyles,
  Theme,
  createStyles,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Slide,
  TextField
} from '@material-ui/core';
import { TransitionProps } from '@material-ui/core/transitions';
import { Autocomplete } from '@material-ui/lab';
import { Transition } from 'framer-motion';
import MaterialTable, { Column } from 'material-table';
import { DialogProps } from 'material-ui';
import moment from 'moment';
import useTranslation from 'next-translate/useTranslation';
import React, { useEffect, useRef, useState } from 'react';
import { useToasts } from 'react-toast-notifications';
import useAsyncEffect from 'use-async-effect';
import useErrorHandler from '../../../hooks/errorHook';
import { useStoreActions, useStoreState } from '../../../hooks/storeHooks';
import { localization } from '../../../locales/no/tableLocalization';
import { Period } from '../../../types/dbModels/period';
import { Pool } from '../../../types/dbModels/pool';
import { PoolPeriod } from '../../../types/dbModels/poolPeriod';
import { PoolPeriodRequest } from '../../../types/request/PoolPeriodRequest';
import PeriodController from '../../controllers/PeriodController';
import PoolPeriodController from '../../controllers/PoolPeriodController';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    container: {
      padding: '10px'
    }
  })
);

type Props = {
  periodId: number;
};

type OpenDialogProps = {
  message: string;
  fn: Function;
  title: string;
  actionName: string;
};

function useDidUpdateEffect(fn, inputs) {
  const didMountRef = useRef(false);
  useEffect(() => {
    if (didMountRef.current) fn();
    else didMountRef.current = true;
  }, [inputs]);
}

const PoolPeriodsTable: React.FC<Props> = ({ periodId }) => {
  const { t } = useTranslation('common');
  const periods = useStoreState((state) => state.periods);
  const setPeriods = useStoreActions((action) => action.setPeriods);
  const [poolPeriods, setPoolPeriods] = useState<PoolPeriod[]>([]);
  const [selectedPoolPeriod, setSelectedPoolPeriod] = useState<PoolPeriod | null>();
  const [moveToPools, setMoveToPools] = useState<Pool[]>([]);
  const [endDatesFlag, setEndDatesFlag] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [openDialog, setOpenDialog] = useState<OpenDialogProps>(null);
  const pools = useStoreState((state) => state.pools);
  const [moveDialog, setMoveDialog] = useState<boolean>(false);
  const classes = useStyles();
  const [columns, setColumns] = useState<Column<any>[]>([
    { title: 'Hall', field: 'pool.hall.name', editable: 'never' },
    { title: 'Kar', field: 'pool.name', editable: 'never' },
    { title: 'Flyttet fra', field: 'parent.pool.name', editable: 'never' },
    {
      title: 'Start tid',
      field: 'startDate',
      type: 'datetime',
      validate: (data) => (data.startDate ? '' : 'Insettet på ha en startdato')
    },
    { title: 'Slutt tid', field: 'endDate', type: 'datetime' }
  ]);

  const { addToast } = useToasts();
  const handleError = useErrorHandler();
  useEffect(() => {
    const rawPeriod = periods.find((p) => p.id == periodId);
    setPoolPeriods(rawPeriod.poolPeriods);
  }, []);

  const endPeriod = () => {
    // Ask to end period when all poolPeriods is finished
    const endDates = poolPeriods
      .map((pp) => {
        if (pp.endDate === null || pp.endDate === undefined) {
          setEndDatesFlag(true);
          return;
        }
        return pp.endDate;
      })
      .filter((d) => d != undefined);

    if (endDates.length == poolPeriods.length && endDatesFlag) {
      let lastEndDate = moment(endDates[0]);
      endDates.forEach((ed) => {
        if (lastEndDate.isBefore(ed)) {
          lastEndDate = moment(ed);
        }
      });
      setOpenDialog({
        title: 'Slutt perioden?',
        message:
          'Alle karperioder er avsluttet. Vil du sette sluttdato for perioden til det samme som den siste sluttdatoen for karperioder?',
        fn: () => {
          try {
            periods.find((p) => p.id === periodId).endDate = lastEndDate.toDate();
            setPeriods(periods);
            let newData: Period = periods.find((p) => p.id === periodId);
            PeriodController.update(newData);
            addToast('Periode ble avsluttet', { appearance: 'success', autoDismiss: true });
            setOpenDialog(null);
          } catch (err) {
            handleError(err);
          }
        },
        actionName: 'Slutt periode'
      });
    }
  };

  useDidUpdateEffect(endPeriod, poolPeriods);

  useEffect(() => {
    // Update global periods when poolPeriods change
    const currentPeriods = [...periods];
    currentPeriods.map((p) => {
      if (p.id === periodId) {
        p.poolPeriods = poolPeriods;
        return p;
      }
      return p;
    });
    setPeriods(currentPeriods);
  }, [poolPeriods]);

  const onRowUpdate = async (newData: PoolPeriod, oldData: any) => {
    if (newData != oldData) {
      try {
        const dataUpdate = [...poolPeriods];
        const index = oldData.tableData.id;
        dataUpdate[index] = newData;
        const request: PoolPeriodRequest = newData as PoolPeriodRequest;
        request.parentId = newData.parent.id;
        request.poolId = newData.pool.id;
        await PoolPeriodController.update(request);
        setPoolPeriods(dataUpdate);
        addToast('Karperiode ble oppdatert', { appearance: 'success', autoDismiss: true });
      } catch (err) {
        handleError(err);
      }
    }
  };
  const handleCloseMoveDialog = () => {
    setMoveToPools([]);
    setMoveDialog(false);
    setSelectedPoolPeriod(null);
  };
  const onRowDelete = async (oldData: any) => {
    try {
      await PoolPeriodController.delete(oldData);
      const dataDelete = [...poolPeriods];
      const index = oldData.tableData.id;
      dataDelete.splice(index, 1);
      setPoolPeriods([...dataDelete]);
      addToast('Karperiode ble slettet', { appearance: 'success', autoDismiss: true });
    } catch (error) {
      handleError(error);
    }
  };

  return (
    <div className={classes.container}>
      <MaterialTable
        key={poolPeriods.map((e) => e.id).join('-')}
        title="Kar perioder"
        columns={columns}
        isLoading={loading}
        data={poolPeriods}
        editable={{
          isDeletable: (rowData: PoolPeriod) =>
            rowData.endDate === null && !poolPeriods.some((pp) => pp.parent.id == rowData.id),
          onRowUpdate: onRowUpdate,
          onRowDelete: onRowDelete
        }}
        actions={[
          (rowData) => ({
            icon: 'pan_tool',
            tooltip: 'Stop',
            disabled: rowData.endDate != null,
            onClick: (event, rowData: any) => {
              try {
                rowData.endDate = new Date();
                const request: PoolPeriodRequest = rowData as PoolPeriodRequest;
                request.parentId = rowData.parent.id;
                request.poolId = rowData.pool.id;
                PoolPeriodController.update(request);

                const dataUpdate = [...poolPeriods];
                const index = rowData.tableData.id;
                dataUpdate[index] = rowData;
                setPoolPeriods(dataUpdate);
                addToast('Karperiode ble stoppet', { appearance: 'success', autoDismiss: true });
              } catch (err) {
                handleError(err);
              }
            }
          }),
          (rowData) => ({
            icon: 'transfer_within_a_station',
            tooltip: 'Flytt',
            disabled: rowData.endDate != null,
            onClick: (event, rowData) => {
              setMoveDialog(true);
              setSelectedPoolPeriod(rowData);
            }
          })
        ]}
        localization={localization}
        components={{
          Pagination: () => null
        }}
        options={{
          actionsColumnIndex: -1,
          exportButton: true,
          pageSize: poolPeriods?.length,
          pageSizeOptions: [5, 10, 25, 50, 100],
          addRowPosition: 'first',
          search: false
        }}
      />
      <Dialog
        open={moveDialog}
        keepMounted
        onClose={handleCloseMoveDialog}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">Flytt fisk</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Flytt fisk i "{selectedPoolPeriod?.pool?.name}" (kar) i "{selectedPoolPeriod?.period?.name}" (innsett) til
            <Autocomplete
              multiple
              options={pools}
              getOptionLabel={(option) => {
                return option.hall.name + ', ' + option.name;
              }}
              getOptionSelected={(option, value) => option.id === value.id}
              onChange={(_, newList: Pool[]) => {
                setMoveToPools(newList);
              }}
              value={moveToPools}
              renderInput={(params) => <TextField {...params} />}
            />
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseMoveDialog} color="primary">
            {t('cancle')}
          </Button>
          <Button
            onClick={async () => {
              if (moveToPools.length == 0) {
                addToast('Må velge kar for å flytte', { appearance: 'error', autoDismiss: true });
                return;
              }
              setLoading(true);
              try {
                handleCloseMoveDialog();
                let currentPoolPeriods = [...poolPeriods];
                for (let index = 0; index < moveToPools.length; index++) {
                  const pool = moveToPools[index];

                  let endDate = selectedPoolPeriod.endDate;
                  if (endDate === null) {
                    endDate = new Date();
                  }

                  const newPoolPeriod = await PoolPeriodController.create({
                    startDate: endDate,
                    endDate: null,
                    parentId: selectedPoolPeriod.id,
                    poolId: pool.id
                  } as PoolPeriodRequest);

                  // Add PoolPeriod to UI
                  newPoolPeriod.parent.pool = selectedPoolPeriod.pool;
                  currentPoolPeriods.push(newPoolPeriod);

                  // Update endDate UI
                  selectedPoolPeriod.endDate = endDate;

                  // Save endDate to DB
                  const request: PoolPeriodRequest = selectedPoolPeriod as PoolPeriodRequest;
                  request.parentId = selectedPoolPeriod.parent.id;
                  request.poolId = selectedPoolPeriod.pool.id;
                  await PoolPeriodController.update(request);
                }
                setPoolPeriods(currentPoolPeriods);
                addToast('Flyttet fisk til nytt/nye kar', { appearance: 'success', autoDismiss: true });
                setLoading(false);
              } catch (error) {
                handleError(error);
                setLoading(false);
              }
            }}
            color="primary"
            autoFocus>
            Flytt
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={openDialog != null}
        keepMounted
        onClose={handleCloseMoveDialog}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">{openDialog?.title}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">{openDialog?.message}</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(null)} color="primary">
            {t('cancle')}
          </Button>
          <Button onClick={() => openDialog?.fn()} color="primary" autoFocus>
            {openDialog?.actionName}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default PoolPeriodsTable;
