import { makeStyles, Theme, createStyles } from '@material-ui/core';
import MaterialTable, { Column } from 'material-table';
import React, { useEffect, useState } from 'react';
import { useToasts } from 'react-toast-notifications';
import useAsyncEffect from 'use-async-effect';
import useErrorHandler from '../../../hooks/errorHook';
import { localization } from '../../../locales/no/tableLocalization';
import { Pool } from '../../../types/dbModels/pool';
import { PoolRequest } from '../../../types/request/poolRequest';
import PoolController from '../../controllers/PoolController';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    container: {
      padding: '10px'
    }
  })
);

interface Props {
  pools: Array<Pool>;
  hallId: number;
  hallname: string;
  updatePools: (hallId: number, pools: Array<Pool>) => void;
}

const PoolTable: React.FC<Props> = ({ pools, hallId, hallname, updatePools }) => {
  const classes = useStyles();
  const [columns, setColumns] = useState<Column<any>[]>([
    { title: 'Navn', field: 'name' },
    { title: 'Kar nummer', field: 'poolNrInHall', type: 'numeric', align: "center", validate: (data: Pool) => (data.poolNrInHall < 1 || data.poolNrInHall > 4 ? 'Kar nummer må være mellom 1 og 4' : true) },
    { title: 'Kommentar', field: 'comment', type: 'string' }
  ]);
  const [loading, setLoading] = useState<boolean>(false);
  const { addToast } = useToasts();
  const handleError = useErrorHandler();

  const onRowAdd = async (newData: PoolRequest) => {
    newData.hallId = hallId;
    try {
      const res = await PoolController.create(newData);

      newData.id = res.id;
      updatePools(hallId, [newData, ...pools]);
      addToast('Basenget ble lagt til.', { appearance: 'success', autoDismiss: true });
    } catch (error) {
      console.log(error);
      handleError(error);
    }
  };

  const onRowUpdate = async (newData: Pool, oldData: Pool) => {
    if (oldData.name != newData.name || oldData.comment != newData.comment || oldData.poolNrInHall != newData.poolNrInHall) {
      try {
        await PoolController.update({
          name: newData.name,
          comment: newData.comment,
          poolNrInHall: newData.poolNrInHall,
          id: newData.id,
          hallId: hallId
        });
        pools = pools.map((pool) => {
          if (pool.id == newData.id) {
            return newData;
          }
          return pool;
        });
        updatePools(hallId, pools);
        addToast('Basenget ble oppdatert.', { appearance: 'success', autoDismiss: true });
      } catch (error) {
        console.log(error);
        handleError(error);
      }
    }
  };

  const onRowDelete = async (oldData: Pool) => {
    try {
      await PoolController.delete(oldData);
      pools = pools.filter((pool) => pool.id != oldData.id);
      updatePools(hallId, pools);
      addToast('Hall ble slettet', { appearance: 'success', autoDismiss: true });
    } catch (error) {
      handleError(error);
    }
  };

  return (
    <div className={classes.container}>
      <MaterialTable
        key={`pools${pools?.length}`}
        title={`Kar - ${hallname}`}
        columns={columns}
        isLoading={loading}
        data={pools}
        components={{
          Pagination: () => null
        }}
        editable={{
          onRowAdd: onRowAdd,
          onRowUpdate: onRowUpdate,
          onRowDelete: onRowDelete
        }}
        localization={localization}
        options={{
          actionsColumnIndex: -1,
          //    exportButton: true,
          pageSize: pools?.length,
          pageSizeOptions: [5, 10, 25, 50, 100],
          addRowPosition: 'first',
          search: false
        }}
      />
    </div>
  );
};

export default PoolTable;
