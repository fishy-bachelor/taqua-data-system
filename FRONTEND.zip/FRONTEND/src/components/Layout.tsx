import React, { useEffect, useState } from 'react';
import clsx from 'clsx';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import SettingsIcon from '@material-ui/icons/Settings';
import PeopleIcon from '@material-ui/icons/People';
import TimelineOutlinedIcon from '@material-ui/icons/TimelineOutlined';
import PlaylistAddOutlinedIcon from '@material-ui/icons/PlaylistAddOutlined';
import Apps from '@material-ui/icons/Apps';
import { useRouter } from 'next/router';
import { useStoreActions, useStoreState } from '../../hooks/storeHooks';
import { motion } from 'framer-motion';
import { ROLE } from '../../constants/role';
import useTranslation from 'next-translate/useTranslation';
import AppbarDropdownMenu from './AppbarDropdownMenu';
import { Grid } from '@material-ui/core';
import EventIcon from '@material-ui/icons/Event';
import ApartmentIcon from '@material-ui/icons/Apartment';
import VpnKey from '@material-ui/icons/VpnKey';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';

const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    width: '100%',
    height: '100%'
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    })
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  menuButton: {
    marginRight: 36
  },
  hide: {
    display: 'none'
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap'
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    overflowX: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9) + 1
    }
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3)
  }
}));

const routeKeys = {
  '/login': {
    hide: true,
    title: 'Login'
  },
  '/': {
    title: 'Dashboard'
  },
  '/visualization': {
    title: 'Visualisering'
  },
  '/register-data': {
    title: 'Registrer Data'
  },
  '/periods': {
    title: 'Innsett'
  },
  '/halls': {
    title: 'Haller'
  },
  '/settings': {
    title: 'Innstillinger'
  },
  '/users': {
    title: 'Brukere'
  },
  '/field-mapper': {
    title: 'Felter'
  },
  '/automatic-data': {
    title: 'RAS-logg opplaster'
  }
};

export default function Layout(props) {
  const classes = useStyles();
  const theme = useTheme();
  const toggleOpen = useStoreActions((actions) => actions.toggleDrawer);
  const open = useStoreState((state) => state.drawerOpen);
  const currentUser = useStoreState((actions) => actions.userStore.currentUser);
  const router = useRouter();
  const [title, setTitle] = useState<string>('');
  const [hideLayout, setHideLayout] = useState<boolean>();

  const { t } = useTranslation('common');

  const handleDrawerOpen = () => {
    toggleOpen(true);
  };

  const handleDrawerClose = () => {
    toggleOpen(false);
  };

  useEffect(() => {
    setHideLayout(routeKeys[router.pathname]?.hide);
    setTitle(routeKeys[router.pathname]?.title);
  }, [router]);

  if (hideLayout) {
    return <>{props.children}</>;
  }

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar
        position="fixed"
        className={clsx(classes.appBar, {
          [classes.appBarShift]: open
        })}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            className={clsx(classes.menuButton, {
              [classes.hide]: open
            })}>
            <MenuIcon />
          </IconButton>
          <Grid container direction="row" justify="space-between" alignItems="center">
            <Typography variant="h6" noWrap>
              {title}
            </Typography>
            <AppbarDropdownMenu />
          </Grid>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open
        })}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open
          })
        }}>
        <div className={classes.toolbar}>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
          </IconButton>
        </div>
        <Divider />
        <List>
          {[
            { title: t('dashboard'), path: '/', icon: <Apps />, role: ROLE.READER },
            { title: t('visualization'), path: '/visualization', icon: <TimelineOutlinedIcon />, role: ROLE.READER },
            { title: t('register-data'), path: '/register-data', icon: <PlaylistAddOutlinedIcon />, role: ROLE.READER },
            { title: t('insert'), path: '/periods', icon: <EventIcon />, role: ROLE.READER },
            { title: t('halls'), path: '/halls', icon: <ApartmentIcon />, role: ROLE.READER },
            { title: 'Automatisk Data', path: '/automatic-data', icon: <CloudUploadIcon />, role: ROLE.WRITER }
          ].map((object, index) => {
            if (object.role <= currentUser?.role) {
              return (
                <ListItem
                  button
                  key={object.title}
                  onClick={() => {
                    router.push(object.path);
                  }}
                  selected={router.pathname == object.path}>
                  <ListItemIcon>{object.icon}</ListItemIcon>
                  <ListItemText primary={object.title} />
                </ListItem>
              );
            }
          })}
          <Divider />

          <ListItem button onClick={() => router.push('settings')} selected={router.pathname == '/settings'}>
            <ListItemIcon>
              <SettingsIcon />
            </ListItemIcon>
            <ListItemText primary={t('settings')} />
          </ListItem>

          {currentUser?.role == ROLE.ADMIN && (
            <ListItem button onClick={() => router.push('users')} selected={router.pathname == '/users'}>
              <ListItemIcon>
                <PeopleIcon />
              </ListItemIcon>
              <ListItemText primary={t('users')} />
            </ListItem>
          )}

          {currentUser?.role == ROLE.ADMIN && (
            <ListItem button onClick={() => router.push('field-mapper')} selected={router.pathname == '/field-mapper'}>
              <ListItemIcon>
                <VpnKey />
              </ListItemIcon>
              <ListItemText primary={'Felter'} />
            </ListItem>
          )}

          <Divider />
        </List>
      </Drawer>
      <motion.main
        initial="pageInitial"
        animate="pageAnimate"
        variants={{
          pageInitial: {
            opacity: 0,
            translateY: 20
          },
          pageAnimate: {
            opacity: 1,
            translateY: 0
          }
        }}
        transition={{ duration: 0.7 }}
        className={classes.content}>
        {props.children}
      </motion.main>
    </div>
  );
}
