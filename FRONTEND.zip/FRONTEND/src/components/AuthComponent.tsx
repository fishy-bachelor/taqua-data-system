import React from 'react';
import { useRouter } from 'next/router';
import { useStoreActions } from '../../hooks/storeHooks';
import { useEffect } from 'react';

type Props = {
  user: User;
};
import { useToasts } from 'react-toast-notifications';
import { User } from '../../types/dbModels/user';

const AuthComponent: React.FC<Props> = ({ user, children }) => {
  const setCurrentUser = useStoreActions((actions) => actions.userStore.setCurrentUser);

  const router = useRouter();
  const { removeAllToasts } = useToasts();

  useEffect(() => {
    removeAllToasts();
  }, [router]);

  useEffect(() => {
    setCurrentUser(user);
  }, [user]);

  return <>{children}</>;
};

export default AuthComponent;
