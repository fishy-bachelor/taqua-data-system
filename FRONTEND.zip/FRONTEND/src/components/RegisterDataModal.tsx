import React, { useState } from 'react';
import TextField from '@material-ui/core/TextField';
import { Dialog, Theme, useTheme } from '@material-ui/core';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Grid from '@material-ui/core/Grid';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Autocomplete from '@material-ui/lab/Autocomplete';
import createStyles from '@material-ui/styles/createStyles';
import makeStyles from '@material-ui/core/styles/makeStyles';
import useErrorHandler from '../../hooks/errorHook';
import ManualInputController from '../controllers/ManualInputController';
import { Hall } from '../../types/dbModels/hall';
import { ManualInput } from '../../types/dbModels/ManualInput';
import { ManualInputRequest } from '../../types/request/manualInputRequest';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    inputWidth: {
      width: '250px'
    }
  })
);

type Props = {
  visible: boolean;
  closeModal: () => void;
  halls: Hall[];
  editing: ManualInput;
  onUpdate: (data: ManualInput) => void;
  onCreate: (data: ManualInput) => void;
};

const RegisterDataModal: React.FC<Props> = ({ visible, closeModal, halls, editing, onCreate, onUpdate }) => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const classes = useStyles();
  const handleError = useErrorHandler();

  const [isEdit] = useState<boolean>(editing ? true : false);
  const [loading, setLoading] = useState<boolean>();
  const [manualData, setManualData] = useState<ManualInputRequest>(
    (editing
      ? editing
      : {
        dateRecorded: new Date().toISOString().slice(0, 16),
        tgp: null,
        oxygen: null,
        res: null,
        redox: null,
        ammonium: null,
        nitritt: null,
        nitrat: null,
        alkalitet: null,
        turbiditet: null,
        speedWater: null,
        hallId: null,
        id: null,
        comment: ''
      }) as ManualInputRequest
  );

  const updateOrCreate = async () => {
    setLoading(true);
    try {
      const payload = { ...manualData };
      delete payload.hall;
      delete payload.userCreatedBy;
      if (isEdit) {
        const res = await ManualInputController.update(payload as ManualInputRequest);
        //res.hall = (res.hall as Hall).id;
        onUpdate(res);
      } else {
        payload.id ?? delete payload.id;
        const res = await ManualInputController.create(payload as ManualInputRequest);
        //res.hall = (res.hall as Hall).id;
        onCreate(res);
      }
      closeModal();
    } catch (error) {
      handleError(error);
    }
    setLoading(false);
  };

  return (
    <Dialog open={visible} onClose={closeModal} fullScreen={fullScreen} fullWidth maxWidth={'lg'}>
      <DialogTitle disableTypography>
        <Typography variant="h4" align="center">
          Registrer data
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Grid container direction="row" justify="center" alignItems="flex-start" spacing={1}>
          <Grid item className={classes.inputWidth}>
            <TextField
              fullWidth
              label="Tidspunkt"
              type="datetime-local"
              InputLabelProps={{
                shrink: true
              }}
              onChange={(e) => setManualData({ ...manualData, dateRecorded: e.target.value })}
              defaultValue={isEdit ? manualData.dateRecorded : new Date().toISOString().slice(0, 16)}
            />
          </Grid>

          <Grid item>
            <Autocomplete
              options={halls}
              getOptionLabel={(option: Hall) => option.name}
              getOptionSelected={(option: Hall, value: Hall) => option?.id === value?.id}
              onChange={(_, newValue: Hall) => {
                setManualData({ ...manualData, hallId: newValue?.id });
              }}
              renderInput={(params) => (
                <TextField
                  error={!manualData.hallId}
                  helperText={!manualData.hallId ? 'Dataen må knyttes til en hall' : ''}
                  label="Hall"
                  className={classes.inputWidth}
                  {...params}
                />
              )}
              value={manualData ? halls.find((hall) => hall.id == manualData?.hallId) : null}
            />
          </Grid>
        </Grid>
        <Grid container direction="row" justify="center" alignItems="flex-start" spacing={1}>
          <Grid item>
            <TextField
              label="TGP (%)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, tgp: Number(e.target.value) })}
              value={manualData.tgp ? manualData.tgp : ''}
            />
          </Grid>
          <Grid item>
            <TextField
              label="Oxygen (%)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, oxygen: Number(e.target.value) })}
              value={manualData.oxygen ? manualData.oxygen : ''}
            />
          </Grid>
          <Grid item>
            <TextField
              label="RES (%)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, res: Number(e.target.value) })}
              value={manualData.res ? manualData.res : ''}
            />
          </Grid>
        </Grid>

        <Grid container direction="row" justify="center" alignItems="flex-start" spacing={1}>
          <Grid item>
            <TextField
              label="Redox (mV)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, redox: Number(e.target.value) })}
              value={manualData.redox ? manualData.redox : ''}
            />
          </Grid>
          <Grid item>
            <TextField
              label="Ammonium (mg/l)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, ammonium: Number(e.target.value) })}
              value={manualData.ammonium ? manualData.ammonium : ''}
            />
          </Grid>
          <Grid item>
            <TextField
              label="Nitritt (mg/l)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, nitritt: Number(e.target.value) })}
              value={manualData.nitritt ? manualData.nitritt : ''}
            />
          </Grid>
        </Grid>

        <Grid container direction="row" justify="center" alignItems="flex-start" spacing={1}>
          <Grid item>
            <TextField
              label="Nitrat (ml/l)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, nitrat: Number(e.target.value) })}
              value={manualData.nitrat ? manualData.nitrat : ''}
            />
          </Grid>
          <Grid item>
            <TextField
              label="Alkalitet (mmol/l)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, alkalitet: Number(e.target.value) })}
              value={manualData.alkalitet ? manualData.alkalitet : ''}
            />
          </Grid>
          <Grid item>
            <TextField
              label="Turbiditet (FAU)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, turbiditet: Number(e.target.value) })}
              value={manualData.turbiditet ? manualData.turbiditet : ''}
            />
          </Grid>
        </Grid>

        <Grid container direction="row" justify="center" alignItems="flex-start" spacing={1}>
          <Grid item>
            <TextField
              label="Speedvann (m3/t)"
              type="number"
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, speedWater: Number(e.target.value) })}
              value={manualData.speedWater ? manualData.speedWater : ''}
            />
          </Grid>

          <Grid item>
            <TextField
              label="Kommentar"
              multiline
              className={classes.inputWidth}
              onChange={(e) => setManualData({ ...manualData, comment: e.target.value })}
              value={manualData.comment}
            />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Grid container justify="center">
          <Button disabled={loading} style={{ color: 'red', fontWeight: 'bold' }} onClick={closeModal}>
            Avbryt
          </Button>
          <Button disabled={loading} style={{ color: 'green', fontWeight: 'bold' }} autoFocus onClick={updateOrCreate}>
            {isEdit ? 'Oppdater' : 'Opprett'}
          </Button>
        </Grid>
      </DialogActions>
    </Dialog>
  );
};
export default RegisterDataModal;
