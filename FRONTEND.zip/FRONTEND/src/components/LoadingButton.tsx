import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import React from 'react';

type Props = {
  label: string;
  loading?: boolean;
  width?: string;
  disabled?: boolean;
  onClick?: () => void;
};

const LoadingButton: React.FC<Props> = ({
  label,
  loading = false,
  width = '300px',
  disabled = false,
  onClick = undefined
}) => {
  return (
    <Button
      type="submit"
      variant="contained"
      color="primary"
      style={{ width: width }}
      disabled={disabled}
      onClick={onClick}>
      {loading ? <CircularProgress size={24} color="secondary" /> : label}
    </Button>
  );
};
export default LoadingButton;
