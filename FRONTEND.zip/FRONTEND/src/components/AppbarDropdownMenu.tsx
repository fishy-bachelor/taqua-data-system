import React, { useContext } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Menu, { MenuProps } from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';

import WbSunnyIcon from '@material-ui/icons/WbSunny';
import NightsStayIcon from '@material-ui/icons/NightsStay';
import { useStoreState } from '../../hooks/storeHooks';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import AuthenticationService from '../services/AuthenticationService';
import { useRouter } from 'next/router';
import { ToggleThemeContext } from '../theme';
import useTranslation from 'next-translate/useTranslation';

const StyledMenu = withStyles({
    paper: {
        border: '1px solid #d3d4d5',
    },
})((props: MenuProps) => (
    <Menu
        elevation={0}
        getContentAnchorEl={null}
        anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'center',
        }}
        transformOrigin={{
            vertical: 'top',
            horizontal: 'center',
        }}
        {...props}
    />
));

export default function AppbarDropdownMenu() {
    const router = useRouter();
    const { t } = useTranslation('common');
    const currentUser = useStoreState((actions) => actions.userStore.currentUser);
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const { toggleTheme, isDark } = useContext(ToggleThemeContext);

    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const changeTheme = () => {
        toggleTheme();
        handleClose();
    };

    const logout = () => {
        AuthenticationService.logout();
        router.push('/login');
    };

    return (
        <div>
            <Button
                aria-controls="customized-menu"
                aria-haspopup="true"
                variant="contained"
                disableElevation
                color="primary"
                onClick={handleClick}
            >
                {
                    currentUser ? currentUser.name : "Ukjent Bruker"}
                <ArrowDropDownIcon />

            </Button>
            <StyledMenu
                id="customized-menu"
                anchorEl={anchorEl}
                keepMounted
                open={Boolean(anchorEl)}
                onClose={handleClose}
            >
                <MenuItem onClick={changeTheme}>
                    <ListItemIcon>{isDark ? <WbSunnyIcon /> : <NightsStayIcon />}</ListItemIcon>
                    <ListItemText primary={`${isDark ? t('light') : t('dark')} ${'mode'}`} />
                </MenuItem>
                <MenuItem onClick={logout}>
                    <ListItemIcon>
                        <ExitToAppIcon />
                    </ListItemIcon>
                    <ListItemText primary={t('logout')} />
                </MenuItem>
            </StyledMenu>
        </div>
    );
}
