import React, { useState } from 'react';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import { FormControlLabel, Switch } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import { DataPeriod, ManualData } from '../../../types/types';
import ManualInputController from '../../controllers/ManualInputController';
import RASLogController from '../../controllers/RASLogController';
import FeedLogController from '../../controllers/FeedLogController';
import LoadingButton from '../LoadingButton';
import { Period } from '../../../types/dbModels/period';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { Hall } from '../../../types/dbModels/hall';

type Props = {
  halls: Hall[];
  periods: Period[];
  addNewDataPeriod: (data: DataPeriod) => void;
};

const PeriodAdder: React.FC<Props> = ({ halls, periods, addNewDataPeriod }) => {
  const [selectedHallId, setSelectedHallId] = useState<number>(1);
  const [fromTimestamp, setFromTimestamp] = useState<string>();
  const [toTimestamp, setToTimestamp] = useState<string>();
  const [loading, setLoading] = useState<boolean>();
  const [searchByPeriod, setSearchByPeriod] = useState<boolean>(false);
  const [hallsInperiod, setHallsInPeriod] = useState<Hall[]>([]);
  const [selectedHallInPeriod, setSelectedHallInPeriod] = useState<Hall>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<Period>(null);

  const searchByIdAndDate = async () => {
    try {
      setLoading(true);

      let manualDataRes = [];
      let rasDataRes = [];
      let feedingDataRes = [];

      if (searchByPeriod) {
        manualDataRes = await ManualInputController.getByDataAndHallID(selectedHallId, fromTimestamp, toTimestamp);
        rasDataRes = await RASLogController.getByDateAndHallID(selectedHallId, fromTimestamp, toTimestamp);
        feedingDataRes = await FeedLogController.getByDateAndHallID(selectedHallId, fromTimestamp, toTimestamp);
      } else {
        manualDataRes = await ManualInputController.getByPeroodIDAndHallID(selectedPeriod.id, selectedHallInPeriod.id);
        rasDataRes = await RASLogController.getByPeroodIDAndHallID(selectedPeriod.id, selectedHallInPeriod.id);
        feedingDataRes = await FeedLogController.getByPeroodIDAndHallID(selectedPeriod.id, selectedHallInPeriod.id);
      }

      addNewDataPeriod({
        hall: searchByPeriod ? halls.find((hall) => hall.id == selectedHallId) : selectedHallInPeriod,
        period: searchByPeriod ? null : selectedPeriod,
        rasData: rasDataRes,
        feedData: feedingDataRes,
        manualData: manualDataRes,
        from: new Date(fromTimestamp),
        to: new Date(toTimestamp)
      });
    } catch {
      // Some error handling maybe?
    } finally {
      setLoading(false);
    }
  };

  const getHallsFromPeriod = (_, newValue: Period) => {
    const uniqueHallsInPeriod: Hall[] = [];
    if (newValue) {
      newValue.poolPeriods.forEach((e) => {
        if (!uniqueHallsInPeriod.find((hall) => hall.id === e.pool.hall.id)) {
          uniqueHallsInPeriod.push(e.pool.hall);
        }
      });
      if (uniqueHallsInPeriod.length === 1) {
        setSelectedHallInPeriod(uniqueHallsInPeriod[0]);
      }
    } else {
      setSelectedHallInPeriod(null);
    }
    setHallsInPeriod(uniqueHallsInPeriod);
    setSelectedPeriod(newValue);
  };

  const verified = (): boolean => {
    if (searchByPeriod) {
      if (!selectedHallId || !fromTimestamp || !toTimestamp) {
        return false;
      }
    } else {
      if (!selectedPeriod || !selectedHallInPeriod) {
        return false;
      }
    }

    return true;
  };

  return (
    <Box mb={2}>
      <Grid container direction="row" spacing={1}>
        <FormControlLabel
          control={
            <Switch
              checked={searchByPeriod}
              color="primary"
              onChange={(e) => {
                setSearchByPeriod(e.target.checked);
              }}
            />
          }
          label="Søk på tidsperiode"
        />

        {!searchByPeriod ? (
          <>
            <Grid item>
              <Autocomplete
                noOptionsText="Ingen insett "
                options={periods}
                getOptionLabel={(p) => p.name}
                renderInput={(params) => (
                  <TextField {...params} label="Innsett" placeholder="Innsett" style={{ width: '150px' }} />
                )}
                onChange={getHallsFromPeriod}
                value={selectedPeriod}
              />
            </Grid>

            {hallsInperiod.length > 0 && (
              <Grid item>
                <Autocomplete
                  noOptionsText="Ingen haller"
                  options={hallsInperiod}
                  getOptionLabel={(p) => p.name}
                  renderInput={(params) => (
                    <TextField {...params} label="Haller" placeholder="Haller" style={{ width: '150px' }} />
                  )}
                  onChange={(_, newValue: Hall) => setSelectedHallInPeriod(newValue)}
                  value={selectedHallInPeriod}
                  disabled={hallsInperiod.length <= 1}
                />
              </Grid>
            )}
          </>
        ) : (
          <>
            <Grid item>
              <FormControl style={{ width: '150px' }}>
                <InputLabel>Hall</InputLabel>
                <Select onChange={(e) => setSelectedHallId(e.target.value as number)} value={selectedHallId}>
                  {halls.map((hall) => (
                    <MenuItem key={hall.id} value={hall.id}>
                      {hall.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item>
              <TextField
                style={{ width: '150px' }}
                label="Fra"
                type="date"
                placeholder="åååå.mm.dd"
                InputLabelProps={{
                  shrink: true
                }}
                onChange={(e) => setFromTimestamp(e.target.value + 'T00:00')}
              />
            </Grid>
            <Grid item>
              <TextField
                style={{ width: '150px' }}
                placeholder="åååå-mm-dd"
                label="Til"
                type="date"
                InputLabelProps={{
                  shrink: true
                }}
                onChange={(e) => setToTimestamp(e.target.value + 'T23:59')}
              />
            </Grid>
          </>
        )}
        <Grid item>
          <LoadingButton
            disabled={loading || !verified()}
            loading={loading}
            width="120px"
            onClick={() => searchByIdAndDate()}
            label="Legg til"
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export default PeriodAdder;
