import { TextField } from '@material-ui/core';
import Box from '@material-ui/core/Box';
import React, { useState } from 'react';
import { useToasts } from 'react-toast-notifications';
import useErrorHandler from '../../../hooks/errorHook';
import { useStoreState } from '../../../hooks/storeHooks';
import UserController from '../../controllers/UserController';
import LoadingButton from '../LoadingButton';

const ChangePassword: React.FC = () => {
  const user = useStoreState((state) => state.userStore.currentUser);
  const handleError = useErrorHandler();
  const { addToast } = useToasts();

  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [loading, setLoading] = useState<boolean>();

  const changePassword = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      setLoading(true);
      await UserController.changeUser({ id: user.id, name: '', newPassword: confirmPassword, email: '' });
      addToast(`Ditt passord ble endret.`, { appearance: 'success', autoDismiss: true });
    } catch (error) {
      handleError(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form style={{ width: '250px' }} onSubmit={changePassword}>
      <h3>Endre passord</h3>
      <Box>
        <TextField
          error={password.length < 6 && password.length != 0}
          helperText={password.length < 6 && password.length != 0 ? 'Passordet må være minst 6 tegn' : ''}
          label="Nytt passord"
          variant="outlined"
          fullWidth
          type="password"
          onChange={(e) => setPassword(e.target.value)}
        />
      </Box>
      <Box mt={1}>
        <TextField
          label="Gjenta passord"
          error={confirmPassword.length !== 0 && password !== confirmPassword}
          helperText={confirmPassword.length !== 0 && password !== confirmPassword ? 'Passordene er ikke like' : ''}
          variant="outlined"
          fullWidth
          type="password"
          onChange={(e) => setConfirmPassword(e.target.value)}
        />
      </Box>
      <Box mt={1}>
        <LoadingButton
          label="Endre passord"
          width="250px"
          disabled={loading || password.length < 6 || confirmPassword.length < 6 || password !== confirmPassword}
          loading={loading}
        />
      </Box>
    </form>
  );
};
export default ChangePassword;
