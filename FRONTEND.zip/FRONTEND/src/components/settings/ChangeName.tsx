import { Box, TextField } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import useErrorHandler from '../../../hooks/errorHook';
import { useStoreActions, useStoreState } from '../../../hooks/storeHooks';
import LoadingButton from '../LoadingButton';
import { useToasts } from 'react-toast-notifications';
import UserController from '../../controllers/UserController';

const ChangeName: React.FC = () => {
  const user = useStoreState((state) => state.userStore.currentUser);
  const setUser = useStoreActions((action) => action.userStore.setCurrentUser);
  const [name, setName] = useState<string>(user?.name ? user.name : '');
  const [loading, setLoading] = useState<boolean>();
  const handleError = useErrorHandler();
  const { addToast } = useToasts();

  useEffect(() => {
    setName(user?.name ? user.name : '');
  }, [user]);

  const changeUserName = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      setLoading(true);
      await UserController.changeUser({ id: user.id, name, newPassword: '', email: '' });
      setUser({ ...user, name });
      addToast(`Ditt navn ble endret til ${name}`, { appearance: 'success', autoDismiss: true });
    } catch (error) {
      handleError(error);
      addToast('Det skjedd en feil, navnet ble ikke endret', { appearance: 'warning', autoDismiss: true });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form style={{ width: '250px' }} onSubmit={changeUserName}>
      <h3>Endre navn</h3>
      <TextField
        error={!name}
        helperText={name ? '' : 'Feltet kan ikke være tomt'}
        label="Navn"
        variant="outlined"
        value={name}
        onChange={(e) => setName(e.target.value)}
        fullWidth
      />
      <Box mt={1}>
        <LoadingButton
          label="Endre navn"
          width="250px"
          disabled={!name || loading || user.name == name}
          loading={loading}
        />
      </Box>
    </form>
  );
};
export default ChangeName;
