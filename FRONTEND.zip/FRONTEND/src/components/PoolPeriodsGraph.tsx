import { CommitOptions, Gitgraph, Mode, Orientation, templateExtend, TemplateName } from '@gitgraph/react';
import { colors } from '@material-ui/core';
import { ro } from 'date-fns/locale';
import { spacing } from 'material-ui/styles';
import React, { ReactSVGElement, useState } from 'react';
import { useEffect } from 'react';
import { useStoreState } from '../../hooks/storeHooks';
import { Hall } from '../../types/dbModels/hall';
import { Period } from '../../types/dbModels/period';
import { paletteColorsDark } from '../theme';

type PoolPeriodNode = { name: string; children: PoolPeriodNode[]; branch: any; id: number; hall: Hall };
const PoolPeriodsGraph: React.FC<any> = (prop: { periodId: number }) => {
  const [count, setCount] = useState<number>(0);
  const periods = useStoreState((state) => state.periods);
  const [rootNode, setRootNode] = useState<PoolPeriodNode>({
    name: 'Levrandør',
    children: [],
    branch: null,
    id: -1,
    hall: null
  });
  // let rootNode = {
  //   name: 'Levrandør',
  //   children: [],
  //   branch: null,
  //   id: -1,
  //   hall: null
  // };
  let period = periods.find((p) => p.id === prop.periodId);
  // {
  //   name: 'levrandør',
  //   children: [
  //     {
  //       name: 'Kar 1',
  //       children: [],
  //       branch: null,
  //       id: 1
  //     },
  //     {
  //       name: 'Kar 2',
  //       children: [],
  //       branch: null,
  //       id: 3
  //     },
  //     {
  //       name: 'Kar 1',
  //       children: [],
  //       branch: null,
  //       id: 2
  //     },
  //     {
  //       name: 'Kar 1',
  //       children: [],
  //       branch: null,
  //       id: 4
  //     },
  //     {
  //       name: 'Kar 1',
  //       children: [],
  //       branch: null,
  //       id: 5
  //     }
  //   ],
  //   branch: null,
  //   id: 6
  // };

  const searchTreeForId = (rNode: PoolPeriodNode, id: number): PoolPeriodNode => {
    let node = null;
    for (let index = 0; index < rNode.children.length; index++) {
      const n = rNode.children[index];
      if (n.id == id) {
        node = n;
        break;
      } else {
        node = searchTreeForId(n, id);
      }
    }
    return node;
  };
  useEffect(() => {
    let newRootNode: PoolPeriodNode = {
      name: 'Levrandør',
      children: [],
      branch: null,
      id: -1,
      hall: null
    };

    period.poolPeriods.forEach((pp) => {
      // RootPoolPeriod
      if (pp.parent.id == 0) {
        newRootNode.children.push({ name: pp.pool.name, branch: null, children: [], id: pp.id, hall: pp.pool.hall });
      } else {
        // loop esisting nodes in tree and add if id of node is equal to parent id of current pp
        let parentNode: PoolPeriodNode = searchTreeForId(newRootNode, pp.parent.id);

        if (parentNode != null) {
          parentNode.children.push({ name: pp.pool.name, branch: null, children: [], id: pp.id, hall: pp.pool.hall });
        }
      }
    });
    setRootNode(newRootNode);
    setCount(count + 1);
  }, [periods]);

  const customTemplate = templateExtend(TemplateName.Metro, {
    branch: { label: { display: false }, color: paletteColorsDark.secondary, spacing: 60 },

    commit: {
      color: paletteColorsDark.error,
      dot: { color: paletteColorsDark.primary, size: 20 },
      message: {
        displayAuthor: false,
        // Not working when orientation is horizontal
        displayHash: false
      }
    }
  });
  const options = {
    template: customTemplate,
    orientation: Orientation.Horizontal,
    mode: Mode.Compact
  };

  const itterateChildren = (node: PoolPeriodNode) => {
    // Looping children of node
    node.children.forEach((ppn, idx) => {
      if (node.children.length > 1 && idx != node.children.length - 1) {
        let newBranch = node.branch.branch(ppn.id.toString());
        newBranch.commit({
          subject: ppn.hall.name + ', ' + ppn.name,
          renderTooltip: renderTooltip,
          onClick: onClickCommit,
          dotText: ppn.hall.name[ppn.hall.name.length - 1] + ', ' + ppn.name[ppn.name.length - 1]
        });
        ppn.branch = newBranch;
        itterateChildren(ppn);
      } else {
        node.branch.commit({
          subject: ppn.hall.name + ', ' + ppn.name,
          renderTooltip: renderTooltip,
          onClick: onClickCommit,
          dotText: ppn.hall.name[ppn.hall.name.length - 1] + ', ' + ppn.name[ppn.name.length - 1]
        });
        ppn.branch = node.branch;
        itterateChildren(ppn);
      }
    });
  };

  const onClickCommit = () => {
    //TODO: set current poolperiod and open dialog to move
    // alert('Not implemented, should open move dialog');
  };

  const renderTooltip: any = (commit: any) => {
    return React.createElement(
      'text',
      { x: 0, y: 0, fill: commit.style.dot.color, fontWeight: 'bold', fontSize: '20' },
      commit.subject
    );
  };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', margin: 40 }}>
      <Gitgraph key={`Count${count}`} options={options}>
        {(gitgraph) => {
          // INITIAL ROOT NODE
          const main = gitgraph.branch(rootNode.id.toString());
          main.commit({
            subject: rootNode.name,
            renderTooltip: renderTooltip,
            onClick: onClickCommit
          });

          rootNode.branch = main;
          // Looping children of rootnode
          rootNode.children.forEach((ppn, idx) => {
            if (rootNode.children.length > 1 && idx != rootNode.children.length - 1) {
              let newBranch = rootNode.branch.branch(ppn.id.toString());
              ppn.branch = newBranch;
              newBranch.commit({
                subject: ppn.hall.name + ', ' + ppn.name,
                renderTooltip: renderTooltip,
                onClick: onClickCommit,
                dotText: ppn.hall.name[ppn.hall.name.length - 1] + ', ' + ppn.name[ppn.name.length - 1]
              });
              itterateChildren(ppn);
            } else {
              ppn.branch = rootNode.branch;
              rootNode.branch.commit({
                subject: ppn.hall.name + ', ' + ppn.name,
                renderTooltip: renderTooltip,
                onClick: onClickCommit,
                dotText: ppn.hall.name[ppn.hall.name.length - 1] + ', ' + ppn.name[ppn.name.length - 1]
              });
              itterateChildren(ppn);
            }
          });
        }}
      </Gitgraph>
    </div>
  );
};

export default PoolPeriodsGraph;
