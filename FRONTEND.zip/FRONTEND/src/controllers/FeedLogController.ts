import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { FeedingLog } from '../../types/dbModels/feedLog';

class FeedLogController {
  getByDateAndHallID = async (hallId: number, startDate: string | Date, endDate: string | Date): Promise<FeedingLog[]> => {
    try {
      let response = await BaseApiService.get(
        `FeedingLog/filter?hallId=${hallId}&fromDate=${startDate}&toDate=${endDate}`
      );
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  getByPeroodIDAndHallID = async (periodId: number, hallId: number): Promise<FeedingLog[]> => {
    try {
      let response = await BaseApiService.get(`FeedingLog/filter?hallId=${hallId}&periodId=${periodId}`);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
}
export default new FeedLogController();
