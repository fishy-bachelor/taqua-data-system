import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { HallRequest } from '../../types/request/hallRequest';
import { DataKey } from '../assets/dataKeys';

class DataKeyController {
  getAll = async (): Promise<DataKey[]> => {
    try {
      let response = await BaseApiService.get('DataKey');
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  create = async (payload: DataKey) => {
    try {
      let response = await BaseApiService.post('DataKey', payload);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  update = async (payload: DataKey) => {
    try {
      let response = await BaseApiService.put(`DataKey/${payload.id}`, payload);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  deleteById = async (id: number) => {
    try {
      let response = await BaseApiService.delete(`DataKey/${id}`, {});
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
}
export default new DataKeyController();
