import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { HallRequest } from '../../types/request/hallRequest';
import { Hall } from '../../types/dbModels/hall';

class HallController {
  getAll = async (): Promise<Hall[]> => {
    try {
      let response = await BaseApiService.get('Hall');
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  create = async (payload: HallRequest) => {
    try {
      let response = await BaseApiService.post('Hall', payload);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  update = async (payload: HallRequest) => {
    try {
      let response = await BaseApiService.put(`Hall/${payload.id}`, payload);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  deleteById = async (id: number) => {
    try {
      let response = await BaseApiService.delete(`Hall/${id}`, {});
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
}
export default new HallController();
