import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { PoolRequest } from '../../types/request/poolRequest';
import { Pool } from '../../types/dbModels/pool';

class PoolController {
    getAll = async (): Promise<Array<Pool>> => {
        try {
            let response = await BaseApiService.get("Pool")
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
    create = async (payload: PoolRequest): Promise<Pool> => {
        try {
            let response = await BaseApiService.post("Pool", payload)
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
    update = async (payload: any): Promise<Pool> => {
        console.log("Inn");
        
        try {
            let response = await BaseApiService.put(`Pool/${payload.id}`, payload)
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
    delete = async (payload: Pool): Promise<Pool> => {
        try {
            let response = await BaseApiService.delete(`Pool/${payload.id}`, payload)
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
}
export default new PoolController();


