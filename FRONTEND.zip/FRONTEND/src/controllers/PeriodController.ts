import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { Period } from '../../types/dbModels/period';
import { PeriodRequest } from '../../types/request/periodRequest';
import { PeriodPutRequest } from '../../types/request/periodPutRequest';

class PeriodController {
    getAll = async (): Promise<Period[]> => {
        try {
            let response = await BaseApiService.get("Period")
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
    create = async (payload: PeriodRequest) => {
        try {

            let response = await BaseApiService.post("Period", payload)
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
    update = async (payload: PeriodPutRequest) => {
        try {

            let response = await BaseApiService.put(`Period/${payload.id}`, {startDate: payload.startDate, endDate: payload.endDate, comment: payload.comment, name: payload.name})
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
    delete = async (payload) => {
        try {
            let response = await BaseApiService.delete(`Period/${payload.id}`, payload)
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
}
export default new PeriodController();


