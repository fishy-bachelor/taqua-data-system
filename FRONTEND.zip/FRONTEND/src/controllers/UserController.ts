import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { setCookie, deleteCookie } from '../services/Cookies';
import { useCookie } from 'next-cookie';
import { ChangeUserRequest } from '../../types/request/changeUserRequest';
import { ChangeUserRoleRequest } from '../../types/request/changeUserRoleRequest';
import { User } from '../../types/dbModels/user';
import { DeleteUserRequest } from '../../types/request/deleteUserRequest';

class UserController {
    getUpdatedUser = async (ctx: any = null): Promise<User> => {
        try {
            let response = await BaseApiService.get(
                "user/",
                ctx
            );
            if (response.status === 401) {
                if (ctx) {
                    const cookie = useCookie(ctx);
                    cookie.remove("APIToken");
                } else {
                    deleteCookie("APIToken");
                }
                throw new CustomError("User not authorized", response.status);
            } else if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data;
        } catch (error) {
            throw error;
        }
    }

    listUsers = async (): Promise<User[]> => {
        try {
            let response = await BaseApiService.get("User/listUsers");
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data;
        } catch (error) {
            throw error;
        }
    }
    changeUserRole = async (payload: ChangeUserRoleRequest) => {

        try {
            let response = await BaseApiService.patch("User/changeUserRole", payload);
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data;
        } catch (error) {
            throw error;
        }
    }
    changeUser = async (payload: ChangeUserRequest) => {

        try {
            let response = await BaseApiService.patch("User/changeUser", payload);
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data;
        } catch (error) {
            throw error;
        }
    }

    deleteUser = async (payload: DeleteUserRequest) => {

        try {
            let response = await BaseApiService.delete("User/deleteUser", payload);
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data;
        } catch (error) {
            throw error;
        }
    }

}
export default new UserController();
