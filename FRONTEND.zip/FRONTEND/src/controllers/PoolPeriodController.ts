import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { PoolPeriodRequest } from '../../types/request/PoolPeriodRequest';
import { PoolPeriod } from '../../types/dbModels/poolPeriod';
class PoolPeriodController {

    create = async (payload: PoolPeriodRequest): Promise<PoolPeriod> => {
        try {
            let response = await BaseApiService.post("poolPeriod", payload)
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
    update = async (payload: PoolPeriodRequest): Promise<PoolPeriod> => {
        try {
            let newPayload = {startDate: payload.startDate, endDate: payload.endDate, poolId: payload.poolId, parentId: payload.parentId}
            let response = await BaseApiService.put(`poolPeriod/${payload.id}`, newPayload)
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
    patch = async (payload: PoolPeriodRequest): Promise<PoolPeriod> => {
        try {
            let response = await BaseApiService.patch(`poolPeriod/${payload.id}`, payload)
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }
    delete = async (payload: PoolPeriodRequest): Promise<PoolPeriod> => {
        try {
            let response = await BaseApiService.delete(`poolPeriod/${payload.id}`, payload)
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data
        } catch (error) {
            throw error
        }
    }

}
export default new PoolPeriodController();


