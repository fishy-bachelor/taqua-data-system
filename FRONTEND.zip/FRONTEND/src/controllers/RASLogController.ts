import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { RasLog } from '../../types/dbModels/rasLog';
import axios from 'axios';

class RASLogController {
  getByDateAndHallID = async (hallId: number, startDate: string | Date, endDate: string | Date): Promise<RasLog[]> => {
    try {
      let response = await BaseApiService.get(`RasLog/filter?hallId=${hallId}&fromDate=${startDate}&toDate=${endDate}`);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  getByPeroodIDAndHallID = async (periodId: number, hallId: number): Promise<RasLog[]> => {
    try {
      let response = await BaseApiService.get(`RasLog/filter?hallId=${hallId}&periodId=${periodId}`);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };

  processLogfile = async (files): Promise<void> => {
    try {
      var formData = new FormData();
      for (let file of files) {
        formData.append('files', file);
      }
      let response = await BaseApiService.uploadFile('RasLog/processLogfile', formData);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
}
export default new RASLogController();
