import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { ManualInputRequest } from '../../types/request/manualInputRequest';
import { ManualInput } from '../../types/dbModels/ManualInput';
import { ManualData } from '../../types/types';

class ManualInputController {
  getAll = async () => {
    try {
      let response = await BaseApiService.get('ManualInput');
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  getByDataAndHallID = async (hallId: number, startDate: string, endDate: string): Promise<ManualInput[]> => {
    try {
      let response = await BaseApiService.get(
        `ManualInput/byHallId?hallId=${hallId}&startDate=${startDate}&endDate=${endDate}`
      );
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  getByPeroodIDAndHallID = async (periodID: number, hallID: number): Promise<ManualData[]> => {
    try {
      let response = await BaseApiService.get(`ManualInput/byPeriod?hallId=${hallID}&periodId=${periodID}`);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  create = async (payload: ManualInputRequest): Promise<ManualInput> => {
    try {
      let response = await BaseApiService.post('ManualInput', payload);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  update = async (payload: ManualInputRequest): Promise<ManualInput> => {
    try {
      let response = await BaseApiService.put(`ManualInput/${payload.id}`, payload);
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  delete = async (payload: ManualInput) => {
    try {
      let response = await BaseApiService.delete(`ManualInput/${payload.id}`, {});
      if (response.status !== 200) {
        throw new CustomError('Api error', response.status);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  };
}
export default new ManualInputController();
