import { CustomError } from '../utils/CustomError';
import BaseApiService from '../services/BaseApiService';
import { setCookie, deleteCookie } from '../services/Cookies';
import { AuthenticateRequest } from '../../types/request/authenticateRequest';
import { AuthenticateResponse } from '../../types/response/authenticateResponse';
import { User } from '../../types/dbModels/user';
import { ROLE } from '../../constants/role';
import { SignUpRequest } from '../../types/request/signUpRequest';

class AuthController {
    login = async (payload: AuthenticateRequest): Promise<AuthenticateResponse> => {
        try {
            let response = await BaseApiService.post(
                "Auth/signIn",
                payload,
            );
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data;
        } catch (error) {
            throw error;
        }
    }


    createUser = async (payload: SignUpRequest): Promise<User> => {
        try {
            let response = await BaseApiService.post("Auth/signUp", payload);
            if (response.status !== 200) {
                throw new CustomError("Api error", response.status);
            }
            return response.data;
        } catch (error) {
            throw error;
        }
    }
}
export default new AuthController();
