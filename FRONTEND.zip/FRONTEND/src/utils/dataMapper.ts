import { Source } from '../../types/source';
import { DataPeriod } from '../../types/types';
import { DataKey } from '../assets/dataKeys';

export const initialOptions = {
  xaxis: {
    type: 'datetime',
    show: false,
    labels: {
      formatter: undefined
    }
  },
  yaxis: [],
  chart: {
    animations: {
      enabled: false
    },
    defaultLocale: 'no',
    locales: [
      {
        name: 'no',
        options: {
          months: [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
          ],
          shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Des'],
          days: ['Søndag', 'Mandag', 'Tirsdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lørdag'],
          shortDays: ['Søn', 'Man', 'Tir', 'Ons', 'Tor', 'Fre', 'Lør'],
          toolbar: {
            menu: 'Meny',
            exportToSVG: 'Last ned SVG',
            exportToPNG: 'Last ned PNG',
            exportToCSV: 'Last ned CSV',
            selection: 'Valg',
            selectionZoom: 'Valg Zoom',
            zoomIn: 'Zoom inn',
            zoomOut: 'Zoom ut',
            pan: 'Panning',
            reset: 'Tilbakestill Zoom'
          }
        }
      }
    ]
  },
  stroke: {
    curve: 'smooth',
    lineCap: 'butt',
    width: 2,
    dashArray: []
  },
  colors: [],
  tooltip: {
    followCursor: true,
    enabled: true
  }
};

export default async function dataMapper(dataPeriods: DataPeriod[], collectAxis: boolean, selectedKeys: DataKey[]) {
  // Create options
  const newOptions = { ...initialOptions };
  const newSeries = [];
  newOptions.yaxis = [];
  newOptions.colors = [];
  let numAxis = 0;

  // Set formatter when multiple dates to show number of days from start
  if (dataPeriods.length > 1) {
    newOptions.xaxis.labels.formatter = (e) => {
      return Math.round(e / (1000 * 3600 * 24)) - 1 + ' dager';
    };
  } else {
    newOptions.xaxis.labels.formatter = undefined;
  }

  dataPeriods.forEach((_, dpIndex) => {
    const periodPrefix = dataPeriods.length > 1 ? '- Periode ' + (dpIndex + 1) : '';
    selectedKeys.forEach((datakey, index) => {
      try {
        newSeries.push({
          type: datakey.type,
          data: [],
          name: datakey.name + periodPrefix
        });

        newOptions.colors.push(datakey.color ? datakey.color : 'black');
        newOptions.stroke.dashArray.push(dpIndex);

        if (collectAxis) {
          const showAxis = newOptions.yaxis.find((y) => y?.seriesName === datakey.unit) ? false : true;

          newOptions.yaxis.push({
            decimalsInFloat: 3,
            seriesName: datakey.unit,
            title: {
              text: datakey.unit
            },
            min: Infinity,
            max: -Infinity,
            opposite: numAxis % 2 == 1,
            show: showAxis
          });
          if (showAxis) {
            numAxis++;
          }
        } else {
          newOptions.yaxis.push({
            seriesName: datakey.unit,
            title: {
              text: datakey.name + periodPrefix
            },
            min: Infinity,
            opposite: index % 2 == 1
          });
        }
      } catch {
        // pass...
      }
    });
  });

  const indexMap = {};
  newOptions.yaxis.forEach((value, index) => {
    if (indexMap[value.seriesName] === undefined) {
      indexMap[value.seriesName] = [index];
    } else {
      indexMap[value.seriesName].push(index);
    }
  });

  dataPeriods.forEach((dataPeriod, dpIndex) => {
    let startDate = new Date();

    if (dataPeriod.manualData.length > 0 && new Date(dataPeriod.manualData[0]?.dateRecorded) < startDate) {
      startDate = new Date(dataPeriod.manualData[0]?.dateRecorded);
    } else if (dataPeriod.feedData.length > 0 && new Date(dataPeriod.feedData[0]?.dateRecorded) < startDate) {
      startDate = new Date(dataPeriod.feedData[0]?.dateRecorded);
    } else if (dataPeriod.rasData.length > 0 && new Date(dataPeriod.rasData[0]?.dateRecorded) < startDate) {
      startDate = new Date(dataPeriod.rasData[0]?.dateRecorded);
    }

    startDate.setDate(startDate.getDate() - 1);

    dataPeriod.manualData.forEach((d) => {
      try {
        const date =
          dataPeriods.length > 1 ? Math.abs(new Date(d.dateRecorded).getTime() - startDate.getTime()) : d.dateRecorded;
        selectedKeys.forEach((datakey, i) => {
          const yAxisIndex = i + dpIndex * selectedKeys.length;

          if (datakey.source === Source.Manual) {
            console.log(datakey);
            const fieldData = d[datakey.key];
            newSeries[yAxisIndex].data.push({ x: date, y: fieldData });

            if (collectAxis) {
              indexMap[datakey.unit].forEach((indexes) => {
                if (fieldData && fieldData < newOptions.yaxis[indexes].min) {
                  newOptions.yaxis[indexes].min = fieldData;
                }

                if (fieldData && fieldData > newOptions.yaxis[indexes].max) {
                  newOptions.yaxis[indexes].max = fieldData;
                }
              });
            } else {
              if (fieldData && fieldData < newOptions.yaxis[yAxisIndex].min) {
                newOptions.yaxis[yAxisIndex].min = fieldData;
              }
            }
          }
        });
      } catch (e) {
        // pass...
      }
    });

    dataPeriod.rasData.forEach((d) => {
      try {
        const date =
          dataPeriods.length > 1 ? Math.abs(new Date(d.dateRecorded).getTime() - startDate.getTime()) : d.dateRecorded;
        selectedKeys.forEach((datakey, i) => {
          const yAxisIndex = i + dpIndex * selectedKeys.length;

          if (datakey.source === Source.RAS) {
            const fieldData = d[datakey.key];
            newSeries[yAxisIndex].data.push({ x: date, y: fieldData });

            if (collectAxis) {
              indexMap[datakey.unit].forEach((indexes) => {
                if (fieldData && fieldData < newOptions.yaxis[indexes].min) {
                  newOptions.yaxis[indexes].min = fieldData;
                }

                if (fieldData && fieldData > newOptions.yaxis[indexes].max) {
                  newOptions.yaxis[indexes].max = fieldData;
                }
              });
            } else {
              if (fieldData && fieldData < newOptions.yaxis[yAxisIndex].min) {
                newOptions.yaxis[yAxisIndex].min = fieldData;
              }
            }
          }
        });
      } catch (e) {
        // pass...
      }
    });

    dataPeriod.feedData.forEach((d) => {
      try {
        const date =
          dataPeriods.length > 1 ? Math.abs(new Date(d.dateRecorded).getTime() - startDate.getTime()) : d.dateRecorded;

        selectedKeys.forEach((datakey, i) => {
          const yAxisIndex = i + dpIndex * selectedKeys.length;
          if (datakey.source === Source.Feeding && datakey.poolNrInHall === d.pool?.poolNrInHall) {
            const fieldData = d.amount; //datakey.key
            newSeries[yAxisIndex].data.push({ x: date, y: fieldData });

            if (collectAxis) {
              indexMap[datakey.unit].forEach((indexes) => {
                if (fieldData && fieldData < newOptions.yaxis[indexes].min) {
                  newOptions.yaxis[indexes].min = fieldData;
                }

                if (fieldData && fieldData > newOptions.yaxis[indexes].max) {
                  newOptions.yaxis[indexes].max = fieldData;
                }
              });
            } else {
              if (fieldData && fieldData < newOptions.yaxis[yAxisIndex].min) {
                newOptions.yaxis[yAxisIndex].min = fieldData;
              }
            }
          }
        });
      } catch (e) {
        // pass...
      }
    });
  });
  console.log(newOptions, newSeries);
  return { newOptions, newSeries };
}
