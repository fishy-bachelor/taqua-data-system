import * as signalR from '@microsoft/signalr';
import { FeedingLog } from '../../types/dbModels/feedLog';
import { RasLog } from '../../types/dbModels/rasLog';
import { Serie } from '../../types/types';
import { DataKey } from '../assets/dataKeys';
import Configs from '../_config/config';

export class LiveChartHandler {
    static series: Serie[] = [];
    static options: any = null;
    static connection: signalR.HubConnection | null = null;
    static interval: NodeJS.Timeout | null = null;

    static pushRasLogs: (newRasLog: RasLog[]) => void = (newRasLog: RasLog[]) => { };
    static pushFeedingLogs: (newFeedingLogList: FeedingLog[]) => void = (newFeedingLogList: FeedingLog[]) => { };

    // used so graph isnt laging when updating (eks range update with animation)
    static chartIsUpdating = false

    static listenAndUpdate = () => {
        const ApexCharts = require('apexcharts');

        // Setup connection
        let connection = new signalR.HubConnectionBuilder()
            .withUrl(`${Configs.serverAPI}datahub`, {
                skipNegotiation: true,
                transport: signalR.HttpTransportType.WebSockets,
                // TODO: fiks her..
                // accessTokenFactory: () => this.loginToken
            })
            .build();

        // listeners
        LiveChartHandler.listenOnRasLog(connection);
        LiveChartHandler.listenOnFeedingLog(connection);

        // setup interval that updates chart
        const interval = setInterval(() => {
            if (LiveChartHandler.chartIsUpdating) {
                LiveChartHandler.chartIsUpdating = false;
            } else {
                if (LiveChartHandler.series.length > 0) {
                    ApexCharts.exec('realtime', 'updateSeries', LiveChartHandler.series);
                }
            }
        }, 2000);

        connection.start();
        LiveChartHandler.connection = connection;
        LiveChartHandler.interval = interval;
    };

    static stopConnection = () => {
        if (LiveChartHandler.connection) {
            console.log("    LiveChartHandler.connection.stop();")
            LiveChartHandler.connection.stop();
        }
        if (LiveChartHandler.interval) {
            clearInterval(LiveChartHandler.interval);
        }
    }

    // Only for testing, can be deleted soon
    static listenOnTestData = (connection, series: any[], ApexCharts: any, i: number) => {
        connection.on('ReceiveData', (data) => {
            series[i].data.push({ x: data.date, y: data.value + i });
        });
    }

    static listenOnRasLog = (connection) => {
        connection.on('ReceiveRasLogs', (data: RasLog[]) => {
            console.log('ReceiveRasLogs')
            LiveChartHandler.pushRasLogs(data);
        });
    }

    static listenOnFeedingLog = (connection) => {
        connection.on('ReceiveFeedingLogs', (data: FeedingLog[]) => {
            console.log('ReceiveFeedingLogs')
            LiveChartHandler.pushFeedingLogs(data);
        });
    }

    static updateSeries = (series: any) => {
        const ApexCharts = require('apexcharts');
        ApexCharts.exec('realtime', 'updateSeries', series);
    }

    static updateOptions = (options: any) => {
        const ApexCharts = require('apexcharts');
        if (LiveChartHandler.chartIsUpdating) {
            setTimeout(function () {
                LiveChartHandler.chartIsUpdating = true;
                ApexCharts.exec('realtime', 'updateOptions', LiveChartHandler.options);
            }, 2000);
        } else {
            LiveChartHandler.chartIsUpdating = true;
            ApexCharts.exec('realtime', 'updateOptions', options);
        }
    }

    // Not is use per nå
    static dataMapper = (hallIds: number[], rasData: RasLog[], feedData: FeedingLog[], collectAxis: boolean, selectedKeys: DataKey[]) => { }

}
