import { FeedingLog, DataKeyMappedFeedingLog } from "../../types/dbModels/feedLog";
import { DataKey } from "../assets/dataKeys";

export class FeedingLogHelper {
    static getByDataKey = (feedinglogs: FeedingLog[], curretKey: DataKey): DataKeyMappedFeedingLog[] => {
        let dataKeyMappedFeedingLogs: DataKeyMappedFeedingLog[] = [];
        if (!curretKey.poolNrInHall) return [];

        feedinglogs.forEach(log => {
            if (curretKey.poolNrInHall === log.pool?.poolNrInHall) {
                dataKeyMappedFeedingLogs.push({
                    id: log.id,
                    dateRecorded: log.dateRecorded,
                    pool: log.pool,
                    type: log.type,
                    toEquipment: log.toEquipment,
                    materialName: log.materialName,
                    amount_p1: log.amount,
                    amount_p2: log.amount,
                    amount_p3: log.amount,
                    amount_p4: log.amount,
                })
            }
        });
        return dataKeyMappedFeedingLogs;
    }
}