export default class DateUtil {
    static subtractFromNow = (days: number, hours: number, minutes: number): Date => {
        var fromDate = new Date();
        fromDate.setHours(fromDate.getHours() - hours);
        fromDate.setMinutes(fromDate.getMinutes() - minutes);
        fromDate.setDate(fromDate.getDate() - days);
        return fromDate;
    }

    static localIsoString = (date: Date) => {
        return new Date(date.getTime() - (date.getTimezoneOffset() * 60000)).toISOString();;
    }
}