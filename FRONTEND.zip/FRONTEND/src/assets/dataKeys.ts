import { Source } from '../../types/source';

export type ChartTypes = 'line' | 'bar' | 'area';

export type DataKey = {
  id: number;
  name: string;
  key: string;
  color: string;
  unit: string;
  source: Source;
  idealValue?: number;
  comment: string;
  deleted: boolean;
  type?: string;
  poolNrInHall?: number,
};

/*
export const feedLogDataKeys: DataKey[] = [
  {
    key: 'amount_p1',
    name: 'Foringsgrad (kg/t), Kar 1',
    unit: 'kg/t',
    type: 'line',
    idealValue: 20,
    color: '#029300',
    source: Source.Feeding,
    poolNrInHall: 1,
  },
  {
    key: 'amount_p2',
    name: 'Foringsgrad (kg/t), Kar 2',
    unit: 'kg/t',
    type: 'line',
    idealValue: 20,
    color: '#FF0708',
    source: Source.Feeding,
    poolNrInHall: 2,
  },
  {
    key: 'amount_p3',
    name: 'Foringsgrad (kg/t), Kar 3',
    unit: 'kg/t',
    type: 'line',
    idealValue: 20,
    color: '#F29d00',
    source: Source.Feeding,
    poolNrInHall: 3,
  },
  {
    key: 'amount_p4',
    name: 'Foringsgrad (kg/t), Kar 4',
    unit: 'kg/t',
    type: 'line',
    idealValue: 20,
    color: '#0293F0',
    source: Source.Feeding,
    poolNrInHall: 4,
  },
];
*/