function setCookie(cname: string, cvalue: string, exdays: number = 999) {
    const d = new Date();
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
    const expires = 'expires=' + d.toUTCString();
    document.cookie = cname + '=' + cvalue + ';' + expires + ';path=/';
  }
  
  function getCookie(cname: string) {
    const cookies = Object.fromEntries(
      document.cookie.split(/; /).map(c => {
        const [key, v] = c.split('=', 2);
        return [key, decodeURIComponent(v)];
      }),
    );
    return cookies[cname] || '';
  }

  function deleteCookie(cname:string) {
    document.cookie = cname + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
  }

  export {
      setCookie, getCookie, deleteCookie
  }