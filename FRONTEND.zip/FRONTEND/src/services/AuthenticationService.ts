import { deleteCookie, getCookie, setCookie } from './Cookies';
import { AuthenticateRequest } from '../../types/request/authenticateRequest';
import AuthController from '../controllers/AuthController';
import { AuthenticateResponse } from '../../types/response/authenticateResponse';

class AuthenticationService {
  login = async (payload: AuthenticateRequest): Promise<AuthenticateResponse> => {
    try {
      let authRes = await AuthController.login(payload);
      setCookie("APIToken", authRes.token, 7);
      return authRes;
    } catch (error) {
      throw error;
    }
  }

  logout() {
    // remove user from local storage to log user out
    deleteCookie('APIToken');
  }
}
export default new AuthenticationService();
