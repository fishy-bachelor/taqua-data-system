import axios, { AxiosResponse } from "axios";
import Configs from "../_config/config";
import { getCookie } from "./Cookies";
import { useCookie } from 'next-cookie'

class BaseApiService {
    get(url: string, ctx: any = null,): Promise<AxiosResponse<any>> {

        return axios.get(Configs.serverAPI + url, {
            headers: {
                Authorization: this.headerConfig(ctx),
            },
        });
    }

    post(
        url: string,
        data: object,
        ctx: any = null,
    ): Promise<AxiosResponse<any>> {
        return axios.post(Configs.serverAPI + url, data, {
            headers: {
                ContentType: "application/json",
                Authorization: this.headerConfig(ctx),
            },
        });
    }

    put(
        url: string,
        data: object,
        ctx: any = null,
    ): Promise<AxiosResponse<any>> {

        return axios.put(Configs.serverAPI + url, data, {
            headers: {
                Authorization: this.headerConfig(ctx),
            },
        });
    }

    patch(
        url: string,
        data: object,
    ): Promise<AxiosResponse<any>> {

        return axios.patch(Configs.serverAPI + url, data, {
            headers: {
                Authorization: this.headerConfig(),
            },
        });
    }
    delete(
        url: string,
        data: object,
    ): Promise<AxiosResponse<any>> {

        return axios.delete(Configs.serverAPI + url, {
            headers: {
              Authorization: this.headerConfig()
            },
            data: data
          })
    }

    uploadFile(
        url: string,
        formData: any,
        ctx: any = null,
    ): Promise<AxiosResponse<any>> {

        return axios.post(Configs.serverAPI + url, formData, {
            headers: {
                Authorization: this.headerConfig(ctx),
                "content-type": "multipart/form-data",
            },
        });
    }

    headerConfig(ctx: any = null) {
        let apiToken = "null";
        if (ctx) {
            const cookie = useCookie(ctx);
            apiToken = cookie.get("APIToken") !== null ? "Bearer " + cookie.get("APIToken") : "null";
        } else {
            apiToken = getCookie("APIToken") !== null
                ? "Bearer " + getCookie("APIToken")
                : "null";
        }
        return apiToken
    }
}

export default new BaseApiService();
