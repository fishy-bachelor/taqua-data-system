const getConfigFileName = () => {
  if (process.env.REACT_APP_ENV === "local") {
    return "config.local.json";
  } else if (process.env.REACT_APP_ENV === "local_vscode") {
    return "config.local_vscode.json";
  } else if (process.env.REACT_APP_ENV === "dev") {
    return "config.development.json";
  } else if (process.env.NODE_ENV === "production" || process.env.REACT_APP_ENV === "prod") {
    return "config.production.json";
  } else {
    return "config.development.json";
  }
}

interface Config {
  serverAPI: string,
  env: string
}

export default (require("./" + getConfigFileName())) as Config;
