module.exports = {
  siteUrl: 'https://example.com',
  generateRobotsTxt: false // (optional)
  // ...other options
};
