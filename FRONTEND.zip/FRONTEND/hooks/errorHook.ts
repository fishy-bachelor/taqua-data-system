import { useState, useEffect } from 'react';
import useTranslation from "next-translate/useTranslation";
import { AppearanceTypes, useToasts } from 'react-toast-notifications';

export default function useErrorHandler() {
    const   {addToast} = useToasts();
    const { t } = useTranslation('common');
    const [error, setError] = useState(null);

    let handleError = (error) => setError(error);

    useEffect(() => {
        if(error){
            console.log("handelign Error");
            
            let errorMessage = '';
            let appearance:AppearanceTypes =  'error'

            // Unautherized
            if (error.response?.status === 401) {
            errorMessage = t('unauthorized');
            } 
            // Length Reqired
            if (error.response?.status === 411) {
            errorMessage = t('password-format-error');
            }
            // Conflict
            if (error.response?.status === 409) {
                errorMessage = error.response?.request.response
            // errorMessage = t('email-conflict');
            }

            // Bad Request (can display multiple toasts)
            if (error.response?.status === 400){
                const errors =JSON.parse(error.response?.request.response).errors
                if(errors){
                    let foundError = false
                    if (errors?.Email) {
                        errorMessage = t('email-format-error');
                        addToast(errorMessage, { appearance: appearance, autoDismiss: true });
                        foundError =true
                    }
                    if (errors?.Password) {
                        errorMessage = t('password-format-error');
                        addToast(errorMessage, { appearance: appearance, autoDismiss: true });
                        foundError =true
                    } 
                    if (errors?.NewPassword) {
                        errorMessage = t('password-format-error');
                        addToast(errorMessage, { appearance: appearance, autoDismiss: true });
                        foundError =true
                    } 
                    if(!foundError) {
                        errorMessage = 'BAD REQUEST: '+JSON.stringify(errors);
                        // errors.forEach((key,error) => {
                        //     errorMessage+= key + ': ' +error
                        // });
                        addToast(errorMessage, { appearance: appearance, autoDismiss: true });
                    }
                    return 
                }

            }

            // Error not handled by the checks above
            if (errorMessage == '') {
                errorMessage = t('horrible-wrong');
            }
            addToast(errorMessage, { appearance: appearance, autoDismiss: true });
        }
      }, [error]);

      return handleError
    
}