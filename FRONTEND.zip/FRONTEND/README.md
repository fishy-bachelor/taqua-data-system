# Frontend

## Local development

```bash
# Install dependencies
npm install

# Start with staging API
npm run dev

# Start with local API (running on visual studio)
npm run local

# Start with local API (running on visual code)
npm run local:vscode
```

## Run in docker

```bash
# Build docker image
docker build -t client .

# Run the image
docker run --name CLIENT_CONTAINER -p 0.0.0.0:5000:3000 client

# All in once :)
docker build -t client . && docker run --name CLIENT_CONTAINER -p 0.0.0.0:5000:3000 client
```

## Pre push hook:

Configured with husky pre push hook, must be built correctly before it can be pushed.

## Semantic Release 📦🚀

**semantic-release** automates the whole package release workflow including: determining the next version number, generating the release notes and publishing the package.

### Commit Type

Must be one of the following:

- **feat**: A new feature, Feature(Minor) release
- **fix**: A bug fix, Patch release
- **docs**: Documentation only changes
- **style**: Changes that do not affect the meaning of the code (white-space, formatting, missing
  semi-colons, etc)
- **refactor**: A code change that neither fixes a bug nor adds a feature
- **perf**: A code change that improves performance, Patch release
- **test**: Adding missing or correcting existing tests
- **chore**: Changes to the build process or auxiliary tools and libraries such as documentation
  generation

Commit messages containig "braking changes" will trigger release, Breaking (Major) release

### Release steps

After running the tests, the command `semantic-release` will execute the following steps:

| Step              | Description                                                                                                                     |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| Verify Conditions | Verify all the conditions to proceed with the release.                                                                          |
| Get last release  | Obtain the commit corresponding to the last release by analyzing [Git tags](https://git-scm.com/book/en/v2/Git-Basics-Tagging). |
| Analyze commits   | Determine the type of release based on the commits added since the last release.                                                |
| Verify release    | Verify the release conformity.                                                                                                  |
| Generate notes    | Generate release notes for the commits added since the last release.                                                            |
| Create Git tag    | Create a Git tag corresponding to the new release version.                                                                      |
| Prepare           | Prepare the release.                                                                                                            |
| Publish           | Publish the release on github and to npm registry if privat property is false (package.json)                                    |
| Notify            | Notify of new releases or errors. Add comments and lable `released` to issues on Github                                         |

### Pushing to a pre-release branch (Not in use yet)

if the last release published from `main` is `1.0.0` then:

- Pushing a `BREAKING CHANGE` commit on the `beta` branch will release the version `2.0.0-beta.1` on the beta distribution channel
- Pushing either a fix, feat or a `BREAKING CHANGE` commit on the `beta` branch will release the version `2.0.0-beta.2` (then `2.0.0-beta.3`, `2.0.0-beta.4`, etc...) on the beta distribution channel

### Merging into a pre-release branch (Not in use yet)

If the last release published from master is `1.0.0` and the last one published from beta is `2.0.0-beta.1` then:

- Pushing a fix commit on the `main` branch will release the version `1.0.1` on the default distribution channel
- Merging the branch master into `beta` will release the version `2.0.0-beta.2` on the beta distribution channel
