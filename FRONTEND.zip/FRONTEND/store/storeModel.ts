import { Action, Store } from 'easy-peasy';
import { Period } from '../types/dbModels/period';
import { Pool } from '../types/dbModels/pool';
import { UserStoreModel } from './userStoreModel';

export interface StoreModel {
    drawerOpen: boolean;
    toggleDrawer: Action<StoreModel, boolean>;
    userStore: UserStoreModel;
    setPeriods: Action<StoreModel, Period[]>;
    periods: Period[];
    pools: Pool[];
    setPools: Action<StoreModel, Pool[]>;
}
