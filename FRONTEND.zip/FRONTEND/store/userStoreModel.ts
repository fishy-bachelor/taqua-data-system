import { Action, Thunk } from 'easy-peasy';
import { User } from '../types/dbModels/user';

export interface UserStoreModel {
    currentUser: User | null;
    isAuthed: boolean;
    isLoading: boolean;
    setCurrentUser: Action<UserStoreModel, User>;
    checkIfUserIsAuthed: Thunk<UserStoreModel>
}
