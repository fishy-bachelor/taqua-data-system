import { createStore } from 'easy-peasy';
import { action } from 'easy-peasy';
import { StoreModel } from './storeModel';
import userStore from './userStore';

const storeModel: StoreModel = {
    drawerOpen: false,
    toggleDrawer: action((state, payload) => {
        state.drawerOpen = payload;
    }),
    userStore: userStore,
    periods: [],
    setPeriods: action((state, payload) => {
        state.periods = payload;
    }),
    pools: [],
    setPools: action((state, payload) => {
        state.pools = payload
    })
};

const store = createStore(storeModel);
export default store;
