import { createStore, thunk } from 'easy-peasy';
import { action } from 'easy-peasy';
import UserController from '../src/controllers/UserController';
import { UserStoreModel } from './userStoreModel';

const userStore: UserStoreModel = {
    currentUser: null,
    isAuthed: false,
    isLoading: true,
    setCurrentUser: action((state, user) => {
        state.currentUser = user;
        state.isLoading = false;
        if (user != null) {
            state.isAuthed = true;
        } else {
            state.isAuthed = false;
        }
    }),
    checkIfUserIsAuthed: thunk(async (actions) => {
        try {
            let currentUser = await UserController.getUpdatedUser();
            actions.setCurrentUser(currentUser);
        } catch (error) {
            actions.setCurrentUser(null);
        }
    }),
};

export default userStore;
