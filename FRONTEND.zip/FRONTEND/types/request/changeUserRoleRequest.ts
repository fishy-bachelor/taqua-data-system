import { ROLE } from "../../constants/role";

export interface ChangeUserRoleRequest {
    id: number;
    role: ROLE;
}