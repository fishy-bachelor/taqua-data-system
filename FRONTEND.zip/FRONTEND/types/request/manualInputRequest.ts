import { ManualInput } from "../dbModels/ManualInput";

export interface ManualInputRequest extends ManualInput {
    hallId: number;
}