import { ROLE } from "../../constants/role";

export interface SignUpRequest {
    name: string;
    email: string;
    password: string;
    role: ROLE;
}