export interface AuthenticateRequest {
    email: string;
    password: string;
}