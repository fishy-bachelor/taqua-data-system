export interface ChangeUserRequest {
    id: number;
    name: string;
    newPassword: string;
    email: string;
}