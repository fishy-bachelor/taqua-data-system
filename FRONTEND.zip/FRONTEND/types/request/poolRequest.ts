import { Pool } from "../dbModels/pool";

export interface PoolRequest extends Pool {
    hallId: number;
    name: string;
    comment: string;
    id: number;
}