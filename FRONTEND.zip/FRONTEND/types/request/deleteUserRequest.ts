export interface DeleteUserRequest {
    id: number;
}