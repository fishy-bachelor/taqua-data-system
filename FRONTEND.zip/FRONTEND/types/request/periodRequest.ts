import { Period } from "../dbModels/period";

export interface PeriodRequest extends Period {
    poolIds: number[];
}