import { Hall } from "../dbModels/hall";

export interface HallRequest {
    id: number;
    name: string;
    comment: string;
}