import { PoolPeriod } from "../dbModels/poolPeriod";

export interface PoolPeriodRequest extends PoolPeriod {
    poolId: number;
    parentId: number;
    
    // id: number;
//     startDate: Date;
//     endDate: Date
}