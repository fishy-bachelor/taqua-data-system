import { Period } from "../dbModels/period";

export interface PeriodPutRequest extends Period {

}