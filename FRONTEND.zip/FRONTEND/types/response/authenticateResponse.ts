import { ROLE } from "../../constants/role";

export interface AuthenticateResponse {
    id: number;
    email: string;
    token: string;
    role: ROLE;
}