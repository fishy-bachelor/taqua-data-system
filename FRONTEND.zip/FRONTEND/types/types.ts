import { Pool } from './dbModels';
import { RasLog } from './dbModels/rasLog';
import { FeedingLog } from './dbModels/feedLog';
import { Period } from './dbModels/period';
import { Hall as DbHall } from './dbModels/hall';

export type Hall = {
  name: string;
  id: number;
  pools: Array<Pool>;
};

export type ManualData = {
  id: number | null;
  dateRecorded: string | null;
  tgp: number | null;
  oxygen: number | null;
  res: number | null;
  redox: number | null;
  ammonium: number | null;
  nitritt: number | null;
  nitrat: number | null;
  alkalitet: number | null;
  turbiditet: number | null;
  speedWater: number | null;
  hallId: number | null;
  comment: string | null;
  userCreatedBy?: any | null;
  hall?:
  | {
    id: number;
  }
  | number;
};

export type DataPeriod = {
  from: Date;
  to: Date;
  hall: DbHall;
  rasData: RasLog[];
  feedData: FeedingLog[];
  manualData: ManualData[];
  period: Period;
};


export type Serie = {
  key: string,
  type: string,
  data: Array<any>,
  name: string
};