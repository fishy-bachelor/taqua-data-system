import { Hall } from './types';

export type Pool = {
  name: string;
  comment: string;
  id: number;
  hallId: number;
  hall?: Hall;
};
