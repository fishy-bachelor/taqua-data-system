import { Hall } from "./hall";
import { User } from "./user";

export interface ManualInput {
    id: number;
    dateRecorded: string;
    tgp: number | null;
    oxygen: number | null;
    res: number | null;
    redox: number | null;
    ammonium: number | null;
    nitritt: number | null;
    nitrat: number | null;
    alkalitet: number | null;
    turbiditet: number | null;
    speedWater: number | null;
    comment: string;
    userCreatedBy: User;
    hall: Hall;
}