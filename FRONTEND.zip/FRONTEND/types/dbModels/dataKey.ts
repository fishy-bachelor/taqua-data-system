export interface DataKey {
  id: number;
  name: string;
  key: string;
  color: string;
  unit: string;
  source: string;
  idealValue: number;
  comment: string;
  deleted: boolean;
}
