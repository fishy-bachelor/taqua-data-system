
import { Hall } from "./hall";
import { PoolPeriod } from "./poolPeriod";
import { User } from "./user";

export interface Pool {
    id: number;
    name: string;
    comment: string;
    deleted: boolean;
    userCreatedBy: User;
    hall: Hall;
    poolPeriods: PoolPeriod[];
    poolNrInHall?: number
}