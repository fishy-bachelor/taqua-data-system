import { ROLE } from "../../constants/role";

export interface User {
    id: number;
    name: string;
    email: string;
    role: ROLE;
    isDeleted: boolean;
}