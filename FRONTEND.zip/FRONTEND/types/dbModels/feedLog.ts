import { Pool } from "./pool";

export interface FeedingLog {
    id: number;
    dateRecorded: string;
    pool: Pool;
    type: number;
    toEquipment: string;
    amount: number;
    materialName: string;
}

// amount-p1-4 vil ha samme data, men pga datakeys logikk blir det lettest.
export interface DataKeyMappedFeedingLog {
    id: number;
    dateRecorded: string;
    pool: Pool;
    type: number;
    toEquipment: string;
    materialName: string;
    amount_p1: number;
    amount_p2: number;
    amount_p3: number;
    amount_p4: number;
}