import { Pool } from "./pool";
import { User } from "./user";

export interface Hall {
    id: number;
    name: string;
    comment: string;
    deleted: boolean;
    userCreatedBy: User;
    pools: Pool[];
}