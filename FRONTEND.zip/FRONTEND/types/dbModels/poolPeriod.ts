import { Period } from "./period";
import { Pool } from "./pool";

export interface PoolPeriod {
    id: number;
    pool: Pool;
    period: Period;
    startDate: string;
    parent: PoolPeriod;// | null //retuneres ikke fra db per nå, TODO: kan gjøre det ved kar historikk
    // parentId: number;
    children: PoolPeriod[]; // Per nå er denne bare tom ettersom self jin ikke funngerte som ønske..
    endDate: string | Date | null;
}