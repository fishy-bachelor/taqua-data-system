import { PoolPeriod } from "./poolPeriod";
import { User } from "./user";

export interface Period {
    id: number;
    startDate: string | Date;
    endDate: string | Date | null;
    name: string;
    comment: string;
    deleted: boolean;
    userCreatedBy: User;
    poolPeriods: PoolPeriod[];
}