export enum Source {
  Manual = 0,
  Feeding = 1,
  RAS = 2
}
