require('dotenv').config();
const webpack = require('webpack');
const nextTranslate = require('next-translate');

module.exports = nextTranslate({
  webpack: (config) => {
    // TODO: mulig denne må endres hvis vi har flere prod miljøer
    if (process.env.NODE_ENV !== "production") {
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    }
    config.plugins.push(
      new webpack.EnvironmentPlugin(process.env)
    )
    return config
  }
});
