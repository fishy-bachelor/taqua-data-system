import nnLocale from 'date-fns/locale/nn';
 export const localization={
    header: {
      actions: 'Rediger/Slett'
    },
    body: {
      emptyDataSourceMessage: "Ingen data",
      addTooltip: 'Legg til',
      deleteTooltip: 'Slett',
      editTooltip: 'Rediger',
      editRow: {
        deleteText: 'Er du sikker på at du vil slette denne raden?',
        cancelTooltip: 'Avbryt',
        saveTooltip: 'Lagre'
      },
      filterRow: {
        filterTooltip: 'Filtrer'
    },
      dateTimePickerLocalization: nnLocale
    },
    toolbar: {
      searchPlaceholder: 'Søk',
      searchTooltip: 'Søk',
      exportCSVName: 'Last end som CSV',
      exportPDFName: 'Last ned som PDF',
      exportAriaLabel: 'Eksporter',
      exportTitle: 'Eksporter'
    },
    pagination: {
      // labelDisplayedRows: '{from}-{to} de {count}',
      labelRowsSelect: 'Rader',
      labelRowsPerPage: 'linjer per side:',
      firstAriaLabel: 'Første side',
      firstTooltip: 'Første side',
      previousAriaLabel: 'Forrige side',
      previousTooltip: 'Forrige side',
      nextAriaLabel: 'Neste side',
      nextTooltip: 'Neste side',
      lastAriaLabel: 'Siste side',
      lastTooltip: 'Siste side'
  },
  }