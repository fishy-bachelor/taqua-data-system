import Head from 'next/head';
import styles from '../../styles/Common.module.css';
import React, { useState } from 'react';
import MaterialTable, { Column } from 'material-table';
import { resetServerContext } from 'react-beautiful-dnd';
import useAsyncEffect from 'use-async-effect';
import HallController from '../../src/controllers/HallController';
import useErrorHandler from '../../hooks/errorHook';
import { useToasts } from 'react-toast-notifications';
import PoolTable from '../../src/components/tables/PoolTable';
import { Hall } from '../../types/dbModels/hall';
import { Pool } from '../../types/dbModels/pool';
import { localization } from '../../locales/no/tableLocalization';

export default function Halls() {
  // To remove error: `data-rbd-draggable-context-id` did not match. Server: "1" Client: "0"
  resetServerContext();

  const [halls, setHalls] = useState<Array<Hall>>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const { addToast } = useToasts();
  const handleError = useErrorHandler();

  useAsyncEffect(async () => {
    try {
      setLoading(true);
      const halls = await HallController.getAll();
      setHalls(halls);
    } catch (error) {
      handleError(error);
    } finally {
      setLoading(false);
    }
  }, []);

  const updatePools = (hallId: number, pools: Array<Pool>) => {
    halls.forEach((hall) => {
      if (hallId == hall.id) {
        hall.pools = pools;
      }
    });
    setHalls(halls);
  };

  const [columns, setColumns] = useState<Column<any>[]>([
    { title: 'Navn', field: 'name', validate: (data) => (data.name === '' ? 'Hallen må ha et navn' : '') },
    { title: 'Kommentar', field: 'comment', type: 'string' }
  ]);

  return (
    <div className={styles.container}>
      <Head>
        <title>Haller</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <MaterialTable
        isLoading={loading}
        title="Haller"
        columns={columns}
        data={halls}
        detailPanel={(rowData) => {
          if (rowData.pools === undefined) {
            rowData.pools = [];
          }
          return (
            <PoolTable pools={rowData.pools} hallId={rowData.id} hallname={rowData.name} updatePools={updatePools} />
          );
        }}
        editable={{
          onRowAdd: (newData: Hall) =>
            new Promise(async (resolve, reject) => {
              try {
                const res = await HallController.create(newData);
                newData.id = res.id;
                setHalls([...halls, newData]);
                resolve({});
                addToast('Ny hall ble lagt til.', { appearance: 'success', autoDismiss: true });
              } catch (error) {
                handleError(error);
                reject();
              }
            }),
          onRowUpdate: (newData: Hall, oldData) =>
            new Promise(async (resolve, reject) => {
              try {
                await HallController.update({ id: newData.id, name: newData.name, comment: newData.comment });
                const dataUpdate = [...halls];
                const index = oldData.tableData.id;
                dataUpdate[index] = newData;
                setHalls([...dataUpdate]);
                addToast('Hall ble oppdatert.', { appearance: 'success', autoDismiss: true });
                resolve({});
              } catch (err) {
                handleError(err);
                reject({});
              }
            }),
          onRowDelete: (oldData: Hall | any) =>
            new Promise(async (resolve, reject) => {
              try {
                await HallController.deleteById(oldData.id);
                const dataDelete = [...halls];
                const index = oldData.tableData.id;
                dataDelete.splice(index, 1);
                setHalls([...dataDelete]);
                addToast('Hall ble slettet.', { appearance: 'success', autoDismiss: true });
                resolve({});
              } catch (error) {
                handleError(error);
                reject({});
              }
            })
        }}
        localization={localization}
        options={{
          actionsColumnIndex: -1,
          exportButton: true,
          pageSize: 10,
          pageSizeOptions: [10, 25, 50, 100],
          addRowPosition: 'first'
        }}
      />
    </div>
  );
}
