import Head from 'next/head';
import styles from '../../styles/Common.module.css';
import React, { useState } from 'react';
import MaterialTable, { Column } from 'material-table';
import { resetServerContext } from 'react-beautiful-dnd';
import useAsyncEffect from 'use-async-effect';
import HallController from '../../src/controllers/HallController';
import ManualInputController from '../../src/controllers/ManualInputController';
import useErrorHandler from '../../hooks/errorHook';
import { useToasts } from 'react-toast-notifications';
import RegisterDataModal from '../../src/components/RegisterDataModal';
import dynamic from 'next/dynamic';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import deepcopy from 'ts-deepcopy';
import { ManualInput } from '../../types/dbModels/ManualInput';
import { Hall } from '../../types/dbModels/hall';
import { localization } from '../../locales/no/tableLocalization';
import { DataKey } from '../../src/assets/dataKeys';
import DataKeyController from '../../src/controllers/DataKeyController';
import { Source } from '../../types/source';

const getColor = (value: number, controlValue: number) => {
  const percent = (value / controlValue) * 100;
  if (controlValue) {
    if (percent < 80 || percent > 120) {
      return 'red';
    }

    if (percent < 90 || percent > 110) {
      return 'orange';
    }

    if (percent < 99 || percent > 101) {
      return '#00A2FF';
    }
  }
  return 'black';
};

// Dynamic imports
const Chart = dynamic(() => import('react-apexcharts'), { ssr: false });

export default function RegisterData() {
  // To remove error: `data-rbd-draggable-context-id` did not match. Server: "1" Client: "0"
  resetServerContext();
  const { addToast } = useToasts();
  const handleError = useErrorHandler();

  const [halls, setHalls] = useState<Hall[]>([]);
  const [data, setData] = useState<ManualInput[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [modalVisible, setModalVisible] = useState<boolean>();
  const [editing, setEditing] = useState<ManualInput>();
  const [dataKeys, setDataKeys] = useState<DataKey[]>([]);

  var options = {
    series: [
      {
        data: []
      }
    ],
    chart: {
      type: 'bar',
      width: 100,
      height: 35,
      sparkline: {
        enabled: true
      }
    },
    plotOptions: {
      bar: {
        columnWidth: '80%',
        colors: {
          ranges: [
            {
              from: 0,
              to: 80,
              color: '#FF0000'
            },
            {
              from: 80,
              to: 90,
              color: '#FFA500'
            },
            {
              from: 90,
              to: 99,
              color: '#00A2FF'
            },
            {
              from: 99,
              to: 101,
              color: '#808080'
            },
            {
              from: 101,
              to: 110,
              color: '#00A2FF'
            },
            {
              from: 110,
              to: 120,
              color: '#FFA500'
            },
            {
              from: 120,
              to: 100000,
              color: '#FF0000'
            }
          ]
        }
      }
    },
    labels: dataKeys.map((key) => key.name),
    xaxis: {
      crosshairs: {
        width: 1
      }
    },
    tooltip: {
      custom: (e) => {
        const label = dataKeys[e.dataPointIndex].name;
        const actualValue = (e.series[e.seriesIndex][e.dataPointIndex] / 100) * dataKeys[e.dataPointIndex].idealValue;
        return `${label}: ${actualValue.toLocaleString('en-US', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 4
        })}`;
      }
    }
  };

  const columns: Column<any>[] = [
    {
      title: 'Tidspunkt',
      field: 'dateRecorded',
      type: 'datetime',
      defaultSort: 'desc',
      render: (e) => {
        const date = new Date(e.dateRecorded).toLocaleString().split(',');
        return date[0] + date[1].slice(0, 6);
      }
    },
    {
      title: 'Hall',
      field: 'hall',
      lookup:
        halls.length > 0
          ? halls.reduce((map, object) => {
              map[object.id] = object.name;
              return map;
            }, {})
          : {}
    },
    {
      title: '',
      render: (row: ManualInput) => {
        const newData = [];
        const optionsCopy = deepcopy(options);
        dataKeys
          .filter((key) => key.source === Source.Manual)
          .forEach((key) => {
            newData.push((row[key.key] / key.idealValue) * 100);
          });
        optionsCopy.series[0].data = newData;
        return <Chart width="90px" height="40px" options={optionsCopy} series={optionsCopy.series} type="bar" />;
      }
    },
    { title: 'Registrert av', field: 'userCreatedBy.name' },
    { title: 'Kommentar', field: 'comment' }
  ];

  const onUpdate = (manualInput: ManualInput) => {
    const index = data.findIndex((o) => o.id === manualInput.id);
    const newData = [...data];
    newData[index] = manualInput;
    setData(newData);
    addToast('Manuell ble ble oppdatert.', { appearance: 'success', autoDismiss: true });
  };

  const onCreate = (manualInput: ManualInput) => {
    setData([manualInput, ...data]);
    addToast('Manuell ble ble opprettet.', { appearance: 'success', autoDismiss: true });
  };

  useAsyncEffect(async () => {
    try {
      setLoading(true);
      const resHalls = await HallController.getAll();
      const resData = await ManualInputController.getAll();
      resData.map((o) => (o.hall = o.hall.id));
      const resDataKeys = await DataKeyController.getAll();
      setHalls(resHalls);
      setDataKeys(resDataKeys);
      setData(resData);
    } catch (error) {
      handleError(error);
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <div className={styles.container}>
      <Head>
        <title>Manuell Data</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      {modalVisible && (
        <RegisterDataModal
          halls={halls}
          visible={modalVisible}
          closeModal={() => setModalVisible(false)}
          editing={editing}
          onUpdate={onUpdate}
          onCreate={onCreate}
        />
      )}

      <div>
        <span style={{ color: 'gray' }}>Grå</span>: innenfor 1%, <span style={{ color: '#3EA1FC' }}>Blå</span>: innenfor
        10%, <span style={{ color: '#FFA500' }}>Orange</span>: innenfor 20%,
        <span style={{ color: '#FF0000' }}> Rød</span>: utenfor 20%
      </div>

      <MaterialTable
        title="Manuell Data"
        columns={columns}
        isLoading={loading}
        data={data}
        detailPanel={(rowData) => {
          return (
            <TableContainer component={Paper}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {dataKeys.map((key) => {
                      return key.source == Source.Manual && <TableCell key={key.name}>{key.name}</TableCell>;
                    })}
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    {dataKeys.map((key) => {
                      return (
                        key.source == Source.Manual && (
                          <TableCell
                            key={`value-${key.name}`}
                            style={{ color: getColor(rowData[key.key], key.idealValue) }}>
                            {rowData[key.key]}
                          </TableCell>
                        )
                      );
                    })}
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          );
        }}
        actions={[
          {
            icon: 'add_box',
            tooltip: 'Legg til',
            position: 'toolbar',
            onClick: () => {
              setEditing(null);
              setModalVisible(true);
            }
          },
          {
            icon: 'edit',
            tooltip: 'Rediger',
            onClick: (event, rowData) => {
              setEditing({ ...rowData, hallId: rowData.hall });
              setModalVisible(true);
            }
          }
        ]}
        editable={{
          onRowDelete: (oldData: ManualInput | any) =>
            new Promise(async (resolve, reject) => {
              try {
                await ManualInputController.delete(oldData);
                const dataDelete = [...data];
                const index = oldData.tableData.id;
                dataDelete.splice(index, 1);
                setData([...dataDelete]);
                addToast('Manuell data ble slettet.', { appearance: 'success', autoDismiss: true });
                resolve({});
              } catch (error) {
                handleError(error);
                reject({});
              }
            })
        }}
        localization={localization}
        options={{
          actionsColumnIndex: -1,
          exportButton: true,
          pageSize: 10,
          pageSizeOptions: [10, 25, 50, 100],
          addRowPosition: 'first',
          padding: 'dense'
        }}
      />
    </div>
  );
}
