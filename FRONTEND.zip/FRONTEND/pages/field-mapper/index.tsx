import Head from 'next/head';
import styles from '../../styles/Common.module.css';
import React, { useState } from 'react';
import MaterialTable, { Column } from 'material-table';
import { resetServerContext } from 'react-beautiful-dnd';
import useAsyncEffect from 'use-async-effect';
import DataKeyController from '../../src/controllers/DataKeyController';
import useErrorHandler from '../../hooks/errorHook';
import { useToasts } from 'react-toast-notifications';
import { localization } from '../../locales/no/tableLocalization';
import { HexColorPicker } from 'react-colorful';
import { DataKey } from '../../src/assets/dataKeys';

const FieldMapper: React.FC = () => {
  // To remove error: `data-rbd-draggable-context-id` did not match. Server: "1" Client: "0"
  resetServerContext();

  const [dataKeys, setHalls] = useState<Array<DataKey>>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const { addToast } = useToasts();
  const handleError = useErrorHandler();

  useAsyncEffect(async () => {
    try {
      setLoading(true);
      const dataKeys = await DataKeyController.getAll();
      setHalls(dataKeys);
    } catch (error) {
      handleError(error);
    } finally {
      setLoading(false);
    }
  }, []);

  const [columns, setColumns] = useState<Column<any>[]>([
    { title: 'Navn', field: 'name', validate: (data) => (data.name === '' ? 'Hallen må ha et navn' : '') },
    {
      title: 'Nøkkel',
      field: 'key',
      validate: (data) => (data.name === '' ? 'Feltet må ha en nøkkel' : ''),
      editable: 'onAdd'
    },
    {
      title: 'Farge',
      field: 'color',
      validate: (data) => (data.name === '' ? 'Feltet må ha en farge' : ''),
      editComponent: (props) => {
        return <HexColorPicker color={props.value} onChange={props.onChange} />;
      },
      render: (rowData) => <div style={{ color: rowData.color }}>{rowData.color}</div>
    },
    { title: 'Enhet', field: 'unit', validate: (data) => (data.name === '' ? 'Feltet må ha en enhet' : '') },
    { title: 'Kilde', field: 'source', lookup: { 2: 'Ras', 1: 'Foring', 0: 'Manuell' }, initialEditValue: 0 },
    { title: 'Idealverdi', field: 'idealValue' },
    { title: 'Kommentar', field: 'comment', type: 'string' }
  ]);

  return (
    <div className={styles.container}>
      <Head>
        <title>Felter</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <MaterialTable
        isLoading={loading}
        title="Felter"
        columns={columns}
        data={dataKeys}
        editable={{
          onRowAdd: (newData: DataKey) =>
            new Promise(async (resolve, reject) => {
              try {
                const res = await DataKeyController.create(newData);
                newData.id = res.id;
                setHalls([...dataKeys, newData]);
                resolve({});
                addToast('Nytt datafelt ble lagt til.', { appearance: 'success', autoDismiss: true });
              } catch (error) {
                handleError(error);
                reject();
              }
            }),
          onRowUpdate: (newData: DataKey, oldData) =>
            new Promise(async (resolve, reject) => {
              try {
                await DataKeyController.update(newData);
                const dataUpdate = [...dataKeys];
                const index = oldData.tableData.id;
                dataUpdate[index] = newData;
                setHalls([...dataUpdate]);
                addToast('Datafelt ble oppdatert.', { appearance: 'success', autoDismiss: true });
                resolve({});
              } catch (err) {
                handleError(err);
                reject({});
              }
            }),
          onRowDelete: (oldData: DataKey | any) =>
            new Promise(async (resolve, reject) => {
              try {
                await DataKeyController.deleteById(oldData.id);
                const dataDelete = [...dataKeys];
                const index = oldData.tableData.id;
                dataDelete.splice(index, 1);
                setHalls([...dataDelete]);
                addToast('Datafelt ble slettet.', { appearance: 'success', autoDismiss: true });
                resolve({});
              } catch (error) {
                handleError(error);
                reject({});
              }
            })
        }}
        localization={localization}
        options={{
          actionsColumnIndex: -1,
          exportButton: false,
          pageSize: 10,
          pageSizeOptions: [10, 25, 50, 100],
          addRowPosition: 'first'
        }}
      />
    </div>
  );
};

export default FieldMapper;
