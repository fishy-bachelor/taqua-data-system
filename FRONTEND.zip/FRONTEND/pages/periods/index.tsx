import Head from 'next/head';
import styles from '../../styles/Common.module.css';
import React, { useState } from 'react';
import MaterialTable, { Column } from 'material-table';
import { resetServerContext } from 'react-beautiful-dnd';
import useAsyncEffect from 'use-async-effect';
import PeriodController from '../../src/controllers/PeriodController';
import HallController from '../../src/controllers/HallController';
import Autocomplete from '@material-ui/lab/Autocomplete';
import TextField from '@material-ui/core/TextField';
import nnLocale from 'date-fns/locale/nn';
import useErrorHandler from '../../hooks/errorHook';
import { useToasts } from 'react-toast-notifications';
import dynamic from 'next/dynamic';
import PoolPeriodsTable from '../../src/components/tables/PoolPeriodsTable';
import { useStoreState, useStoreActions } from '../../hooks/storeHooks';
import { PoolPeriod } from '../../types/dbModels/poolPeriod';
import { Period } from '../../types/dbModels/period';
import { Hall } from '../../types/dbModels/hall';
import PoolPeriodsGraph from '../../src/components/PoolPeriodsGraph';
import {
  makeStyles,
  Theme,
  createStyles,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Slide
} from '@material-ui/core';
import useTranslation from 'next-translate/useTranslation';
import { localization } from '../../locales/no/tableLocalization';

type OpenDialogProps = {
  message: string;
  fn: Function;
  title: string;
  actionName: string;
};
export default function Periods() {
  // To remove error: `data-rbd-draggable-context-id` did not match. Server: "1" Client: "0"
  resetServerContext();
  const { t } = useTranslation('common');

  const periods = useStoreState((state) => state.periods);
  const pools = useStoreState((state) => state.pools);

  const setPeriods = useStoreActions((action) => action.setPeriods);
  const setPools = useStoreActions((action) => action.setPools);

  const { addToast } = useToasts();
  const handleError = useErrorHandler();

  const [halls, setHalls] = useState<Hall[]>([]);
  const [loading, setLoading] = useState<boolean>();
  const [openDialog, setOpenDialog] = useState<OpenDialogProps>(null);
  const columns: Column<any>[] = [
    { title: 'Navn', field: 'name', validate: (data) => (data.name === '' ? 'Insettet på ha et navn' : '') },
    {
      title: 'Start tid',
      field: 'startDate',
      type: 'datetime',
      validate: (data) => (data.startDate ? '' : 'Insettet på ha en startdato')
    },
    { title: 'Slutt tid', field: 'endDate', type: 'datetime' },
    {
      title: 'Kar (hall, kar)',
      field: 'pools',
      editable: 'onAdd',
      initialEditValue: [],
      render: (e) => {
        let inPools: string[] = [];
        e.poolPeriods.forEach((pp: PoolPeriod) => {
          if (pp.endDate == null || pp.endDate == undefined) {
            inPools.push(' (' + pp.pool.hall.name + ', ' + pp.pool.name + ')');
          }
        });
        return inPools ? inPools.join(',') : 'error';
      },
      editComponent: (e) => {
        const [value, setValue] = useState<any[]>(e.value);

        return (
          <Autocomplete
            multiple
            style={{ width: 200 }}
            options={pools}
            getOptionLabel={(option) => {
              return option.hall?.name + ', ' + option.name;
            }}
            getOptionSelected={(option, value) => option.id === value.id}
            onChange={(_, newValue) => {
              e.value.push(newValue);
              setValue(newValue);
            }}
            value={value}
            renderInput={(params) => <TextField {...params} />}
          />
        );
      }
    },
    { title: 'Kommentar', field: 'comment' }
  ];

  useAsyncEffect(async () => {
    try {
      setLoading(true);
      const resHalls = await HallController.getAll();
      const resPeriods = await PeriodController.getAll();
      const pools = resHalls.flatMap((hall) => {
        hall.pools.forEach((p) => {
          p.hall = { name: hall.name, id: hall.id } as Hall;
        });
        return hall.pools;
      });
      setPools(pools);
      setHalls(resHalls);
      setPeriods(resPeriods);
    } catch (error) {
      handleError(error);
    } finally {
      setLoading(false);
    }
  }, []);


  const onRowAdd = async (newData: any) => {
    if (newData.pools.length == 0) {
      addToast('Må ha kar', { appearance: 'error', autoDismiss: true });
      return;
    }

    let pools = newData.pools;
    const poolIds = pools[newData.pools.length - 1].map((pool) => pool.id);

    try {
      const res = await PeriodController.create({ ...newData, poolIds });
      newData.id = res.id;
      newData.poolPeriods = res.poolPeriods;
      setPeriods([...periods, newData]);
      addToast('Innsett ble lagt til.', { appearance: 'success', autoDismiss: true });
    } catch (error) {
      console.log('Fail', error);
      newData.pools = pools;
      handleError(error);
    }
  };

  const onRowUpdate = async (newData: Period, oldData: any) => {
    if (
      newData.name != oldData.name ||
      newData.startDate != oldData.startDate ||
      newData.endDate != oldData.endDate ||
      newData.comment != oldData.comment
    ) {
      delete newData.userCreatedBy;
      PeriodController.update(newData)
        .then(() => {
          // newData.userCreatedBy = userCreatedBy;
          const dataUpdate = [...periods];
          const index = oldData.tableData.id;
          dataUpdate[index] = newData;
          setPeriods([...dataUpdate]);
          // newData.userCreatedBy = userCreatedBy;
          addToast('Innsett ble oppdatert', { appearance: 'success', autoDismiss: true });
        })
        .catch((err) => {
          console.log(err);

          handleError(err);
        });
    }
  };

  const onRowDelete = async (oldData: any) => {
    try {
      await PeriodController.delete(oldData);
      const dataDelete = [...periods];
      const index = oldData.tableData.id;
      dataDelete.splice(index, 1);
      setPeriods([...dataDelete]);
      addToast('Innsett ble slettet', { appearance: 'success', autoDismiss: true });
    } catch (error) {
      handleError(error);
    }
  };

  const options = {
    chart: {
      height: 350,
      type: 'rangeBar'
    },
    plotOptions: {
      bar: {
        horizontal: true
      }
    },
    xaxis: {
      type: 'datetime'
    }
  };

  return (
    <div className={styles.container}>
      <Head>
        <title>Innsett</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <MaterialTable
        title="Innsett"
        detailPanel={(rowData: Period) => {
          //WIll only run on open detail panel,should subscrube to periods
          let data = [];
          let endDate = rowData.endDate ? new Date(rowData.endDate) : new Date().getTime();
          let startDate = new Date(rowData.startDate).getTime();

          let nameOfPeriod = rowData.poolPeriods
            .map((poolPeriod) => {
              return poolPeriod.pool.id;
            })
            .join(',');

          data.push({
            x: nameOfPeriod,
            y: [startDate, endDate]
          });
          let series = [{ data: data }];
          return (
            <>
              {/* <Chart options={options} series={series} type="rangeBar" height={350} /> */}
              <PoolPeriodsGraph periodId={rowData.id}></PoolPeriodsGraph>
              <PoolPeriodsTable periodId={rowData.id} />
            </>
          );
        }}
        columns={columns}
        data={periods}
        isLoading={loading}
        editable={{
          onRowAdd: onRowAdd,
          onRowUpdate: onRowUpdate,
          onRowDelete: onRowDelete
        }}
        localization={localization}
        options={{
          actionsColumnIndex: -1,
          exportButton: true,
          pageSize: 10,
          pageSizeOptions: [10, 25, 50, 100],
          addRowPosition: 'first'
        }}
        actions={[
          (rowData) => ({
            icon: 'pan_tool',
            tooltip: 'Avslutt hele insett',
            disabled: rowData.endDate != null,
            onClick: (event, rowData) => {
              setOpenDialog({
                title: 'Slutt innsett og alle karperioder',
                message: 'Alle karperioder som ikke er avsluttet og tilhører dette innsettet vil bli avsluttet.',
                fn: () => {
                  try {
                    rowData.endDate = new Date();
                    let newData: Period = rowData;
                    PeriodController.update(newData);

                    const dataUpdate = [...periods];
                    const index = rowData.tableData.id;
                    dataUpdate[index] = rowData;
                    setPeriods(dataUpdate);
                    addToast('Periode ble avsluttet', { appearance: 'success', autoDismiss: true });
                    setOpenDialog(null);
                  } catch (err) {
                    handleError(err);
                  }
                },
                actionName: 'Slutt periode'
              });
            }
          })
        ]}
      />

      <Dialog
        open={openDialog != null}
        keepMounted
        onClose={() => setOpenDialog(null)}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">{openDialog?.title}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">{openDialog?.message}</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(null)} color="primary">
            {t('cancle')}
          </Button>
          <Button onClick={() => openDialog?.fn()} color="primary" autoFocus>
            {openDialog?.actionName}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
