import React, { useState } from 'react';
import styles from '../../styles/Common.module.css';
import { DropzoneArea } from 'material-ui-dropzone';
import { createStyles, makeStyles } from '@material-ui/core/styles';
import LoadingButton from '../../src/components/LoadingButton';
import RASLogController from '../../src/controllers/RASLogController';
import Head from 'next/head';
import { LinearProgressWithLabel } from '../../src/components/LinearProgressWithLabel';

const useStyles = makeStyles((theme) =>
  createStyles({
    previewChip: {
      minWidth: 160,
      maxWidth: 210
    }
  })
);

const AutomaticData = () => {
  const [files, setFiles] = useState<any[]>([]);
  const [uploading, setUploading] = useState<boolean>();
  const [failedFiles, setFailedFiles] = useState<any[]>([]);
  const [progress, setProgress] = useState<number>(0);
  const [currentFile, setCurrentFile] = useState(null);

  const classes = useStyles();

  const uploadFiles = async () => {
    setFailedFiles([]);
    setProgress(0);
    setUploading(true);
    let filesProcessed = 0;
    for (let file of files) {
      try {
        setCurrentFile(file);
        await RASLogController.processLogfile([file]);
      } catch {
        setFailedFiles([...failedFiles, file]);
      } finally {
        filesProcessed++;
        setProgress((filesProcessed / files.length) * 100);
      }
    }
  };

  return (
    <>
      <Head>
        <title>RAS-logg opplaster</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className={styles.container}>
        {uploading ? (
          <div style={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', alignItems: 'center' }}>
            {progress == 100 ? (
              <h3>Prosesseringen er fullført</h3>
            ) : (
              <h3>Opplasting og prossesering av fil: {currentFile?.name} </h3>
            )}
            <div style={{ width: '100%' }}>
              <LinearProgressWithLabel value={progress} />
              {failedFiles.map((file) => {
                <div>{file.name}</div>;
              })}
            </div>

            {progress == 100 && (
              <div style={{ marginTop: '20px' }}>
                <LoadingButton onClick={() => setUploading(false)} label="Ny opplastning" />
              </div>
            )}
          </div>
        ) : (
          <>
            <p>
              Denne siden brukes for å laste opp logger fra RAS-anlegget. Du trenger KUN å legge inn Float filene her.
              Opplastningen kan ta litt tid ettersom prosessering skjer samtidig.
            </p>
            <DropzoneArea
              maxFileSize={1000000000}
              onChange={(files) => setFiles(files)}
              filesLimit={10000}
              showPreviews={true}
              showPreviewsInDropzone={false}
              useChipsForPreview
              previewGridProps={{ container: { spacing: 1, direction: 'row' } }}
              previewChipProps={{ classes: { root: classes.previewChip } }}
              previewText="Valgte filer"
              dropzoneText="Dra logg filene inn her"
            />

            <div style={{ width: '100%', display: 'flex', justifyContent: 'center', margin: '40px' }}>
              <LoadingButton label="Last opp" onClick={uploadFiles} />
            </div>
          </>
        )}
      </div>
    </>
  );
};
export default AutomaticData;
