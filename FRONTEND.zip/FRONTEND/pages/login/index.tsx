import React, { useState } from 'react';
import { useRouter } from 'next/router';
import AuthenticationService from '../../src/services/AuthenticationService';
import Head from 'next/head';
import TextField from '@material-ui/core/TextField';
import validator from 'validator';
import AccountCircle from '@material-ui/icons/AccountCircle';
import Lock from '@material-ui/icons/Lock';
import InputAdornment from '@material-ui/core/InputAdornment';
import Box from '@material-ui/core/Box';
import LoadingButton from '../../src/components/LoadingButton';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useToasts } from 'react-toast-notifications';
import { useStoreActions } from '../../hooks/storeHooks';
import useTranslation from 'next-translate/useTranslation';
import { User } from '../../types/dbModels/user';

const LoginPage: React.FC = () => {
  const setCurrentUser = useStoreActions((actions) => actions.userStore.setCurrentUser);
  const router = useRouter();
  const { addToast } = useToasts();

  const [email, setEmail] = useState<string>('');
  const [emailError, setEmailError] = useState<string>('');
  const [emailValidated, setEmailValidated] = useState<boolean>(false);

  const [password, setPassword] = useState<string>('');
  const [passwordError, setPasswordError] = useState<string>('');
  const [passwordValidated, setPasswordValidated] = useState<boolean>(false);

  const [loading, setLoading] = useState<boolean>(false);

  const { t } = useTranslation('common');

  const setAndValidateEmail = (event: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    let input = event.target.value;
    setEmail(input);
    if (validator.isEmail(input)) {
      setEmailError('');
      setEmailValidated(true);
    } else {
      setEmailError(t('email-format-error'));
      setEmailValidated(false);
    }
  };

  const setAndValidatePassword = (event: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    let input = event.target.value;
    setPassword(input);
    if (input.length >= 6) {
      setPasswordError('');
      setPasswordValidated(true);
    } else {
      setPasswordError(t('password-format-error'));
      setPasswordValidated(false);
    }
  };

  const login = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      let currentUser = await AuthenticationService.login({ email, password });
      // TODO: fiks dette
      // @ts-ignore
      setCurrentUser(currentUser as User);
      router.push('/');
    } catch (error) {
      let errorMessage = '';
      if (error.response.status === 400) {
        errorMessage = t('username-or-password-wrong');
      } else {
        errorMessage = t('horrible-wrong');
      }
      addToast(errorMessage, { appearance: 'warning', autoDismiss: true });
      setLoading(false);
    }
  };

  return (
    <motion.form
      onSubmit={login}
      style={{
        display: 'flex',
        width: '100%',
        height: '100vh',
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'column'
      }}
      initial="pageInitial"
      animate="pageAnimate"
      variants={{
        pageInitial: {
          opacity: 0,
          translateY: -30
        },
        pageAnimate: {
          opacity: 1,
          translateY: 0
        }
      }}
      transition={{ duration: 0.7 }}>
      <Head>
        <title>Innlogging</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Box mb={4}>
        <Image src="/images/logo.png" alt="Tytladsvik aqua logo" width="300px" height="110px" />
      </Box>

      <TextField
        style={{ width: '300px' }}
        error={emailError ? true : false}
        label={t('email')}
        helperText={emailError}
        variant="outlined"
        onChange={setAndValidateEmail}
        placeholder="email@taqua.no"
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <AccountCircle color={emailError ? 'error' : 'inherit'} />
            </InputAdornment>
          )
        }}
      />
      <Box mt={3}>
        <TextField
          style={{ width: '300px' }}
          error={passwordError ? true : false}
          label={t('password')}
          helperText={passwordError}
          variant="outlined"
          onChange={setAndValidatePassword}
          type="password"
          placeholder={t('supersecret')}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Lock color={passwordError ? 'error' : 'inherit'} />
              </InputAdornment>
            )
          }}
        />
      </Box>

      <Box mt={3}>
        <LoadingButton
          label={t('login').toUpperCase()}
          loading={loading}
          disabled={!emailValidated || !passwordValidated || loading}
        />
      </Box>
    </motion.form>
  );
};

export default LoginPage;
