import Head from 'next/head';
import styles from '../../styles/Common.module.css';
import React, { useState } from 'react';
import useAsyncEffect from 'use-async-effect';
import MaterialTable, { Column } from 'material-table';
import { resetServerContext } from 'react-beautiful-dnd';
import { useToasts } from 'react-toast-notifications';
import useTranslation from 'next-translate/useTranslation';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { Button } from '@material-ui/core';
import Slide from '@material-ui/core/Slide';
import { TransitionProps } from '@material-ui/core/transitions';
import { ROLE } from '../../constants/role';
import useErrorHandler from '../../hooks/errorHook';
import { rejects } from 'assert';
import UserController from '../../src/controllers/UserController';
import { User } from '../../types/dbModels/user';
import AuthController from '../../src/controllers/AuthController';
import { localization } from '../../locales/no/tableLocalization';

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & { children?: React.ReactElement<any, any> },
  ref: React.Ref<unknown>
) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [openDeleteDialog, setOpenDeleteDialog] = React.useState(false);
  const [userToDelete, setUserToDelete] = React.useState(null);
  const [loading, setLoading] = React.useState<boolean>();
  const { addToast } = useToasts();
  const handleError = useErrorHandler();

  const columns: Column<any>[] = [
    { title: 'Email', field: 'email' },
    { title: 'Name', field: 'name' },
    {
      title: 'Rolle',
      field: 'role',
      lookup: { 2: 'Admin', 1: 'Skriver', 0: 'Leser' },
      initialEditValue: 0
    },
    { title: 'Nytt passord', field: 'newPassword', emptyValue: 'Nytt passord' }
  ];

  const { t } = useTranslation('common');

  // To remove error: `data-rbd-draggable-context-id` did not match. Server: "1" Client: "0"
  resetServerContext();

  useAsyncEffect(async () => {
    try {
      setLoading(true);
      const res = await UserController.listUsers();
      setUsers(res);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleClickOpenDeleteDialog = (rowData) => {
    setUserToDelete(rowData);
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = (deleteUser) => {
    setOpenDeleteDialog(false);
    if (deleteUser) {
      UserController.deleteUser({ id: userToDelete.id })
        .then(() => {
          let _users = users.filter((u) => u.id != userToDelete.id);
          setUsers(_users);
          addToast('Bruker med email ' + userToDelete.email + 'er slettet', {
            appearance: 'success',
            autoDismiss: true
          });
        })
        .catch((error) => {
          handleError(error);
        });
    }
  };

  return (
    <div className={styles.container}>
      <Head>
        <title>Brukere</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <MaterialTable
        title="Brukere"
        columns={columns}
        data={users}
        isLoading={loading}
        editable={{
          onRowAdd: (newData) => {
            AuthController.createUser({
              name: newData.name,
              password: newData.newPassword,
              email: newData.email,
              role: +newData.role
            })
              .then((user) => {
                newData.id = user.id;
                newData.role = +newData.role;
                newData.newPassword = 'Nytt passord';
                setUsers([...users, newData]);
                addToast(`${newData.name} ble lagt til som bruker.`, {
                  appearance: 'success',
                  autoDismiss: true
                });
              })
              .catch((error) => {
                handleError(error);
              });
            return new Promise((resolve, reject) => {
              setTimeout(resolve, 1);
            });
          }
        }}
        cellEditable={{
          onCellEditApproved: (newValue, oldValue, rowData, columnDef) =>
            new Promise<any>((resolve, reject) => {
              if (newValue != '') {
                var changedUser = users.find((u) => u.id == rowData.id);
                switch (columnDef.field) {
                  case 'role':
                    return UserController.changeUserRole({ id: rowData.id, role: +newValue })
                      .then(() => {
                        changedUser.role = +newValue;
                        setUsers(users);
                        addToast(`Rollen til ${changedUser.name} ble oppdatert`, {
                          appearance: 'success',
                          autoDismiss: true
                        });
                        resolve({});
                      })
                      .catch((error) => {
                        handleError(error);
                        reject({});
                      });
                  case 'email':
                    return UserController.changeUser({ id: rowData.id, name: '', newPassword: '', email: newValue })
                      .then(() => {
                        changedUser.email = newValue;
                        setUsers(users);
                        addToast(`Eposten til ${changedUser.name} ble oppdatert`, {
                          appearance: 'success',
                          autoDismiss: true
                        });
                        resolve({});
                      })
                      .catch((error) => {
                        handleError(error);
                        reject({});
                      });
                  case 'name':
                    return UserController.changeUser({ id: rowData.id, name: newValue, newPassword: '', email: '' })
                      .then(() => {
                        changedUser.name = newValue;
                        setUsers(users);
                        addToast(`Navn til ${changedUser.name} ble oppdatert`, {
                          appearance: 'success',
                          autoDismiss: true
                        });
                        resolve({});
                      })
                      .catch((error) => {
                        handleError(error);
                        reject({});
                      });

                  case 'newPassword':
                    return UserController.changeUser({ id: rowData.id, name: '', newPassword: newValue, email: '' })
                      .then(() => {
                        addToast('Passord endret', {
                          appearance: 'success',
                          autoDismiss: true
                        });
                        resolve({});
                      })
                      .catch((error) => {
                        handleError(error);
                        reject({});
                      });
                  default:
                    break;
                }
              }
            })
        }}
        actions={[
          {
            icon: 'delete',
            tooltip: 'Slett bruker',
            onClick: (event, rowData) => {
              handleClickOpenDeleteDialog(rowData);
            }
          }
        ]}
        localization={localization}
        options={{
          actionsColumnIndex: -1,
          exportButton: true,
          pageSize: 10,
          pageSizeOptions: [10, 25, 50, 100],
          addRowPosition: 'first'
        }}
      />

      <Dialog
        open={openDeleteDialog}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleCloseDeleteDialog}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">{t('delete-question')}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">{userToDelete?.email}</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => handleCloseDeleteDialog(false)} color="primary">
            {t('cancle')}
          </Button>
          <Button onClick={() => handleCloseDeleteDialog(true)} color="primary" autoFocus>
            {t('delete')}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
