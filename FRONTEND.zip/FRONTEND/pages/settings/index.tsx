import Head from 'next/head';
import styles from '../../styles/Common.module.css';
import React from 'react';
import ChangeName from '../../src/components/settings/ChangeName';
import ChangePassword from '../../src/components/settings/ChangePassword';

export default function Settings() {
  return (
    <div className={styles.container}>
      <Head>
        <title>Innstillinger</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <ChangeName />
      <ChangePassword />
    </div>
  );
}
