import Head from 'next/head';
import styles from '../styles/Common.module.css';
import useTranslation from 'next-translate/useTranslation';
import React, { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { LiveChartHandler } from '../src/utils/LiveChartHandler';
import { Box, FormControl, Grid, InputLabel, MenuItem, Select, TextField, Typography } from '@material-ui/core';
import DurationInputBar from '../src/components/DurationInputBar';
import DateUtil from '../src/utils/DateUtil';
import { RasLog } from '../types/dbModels/rasLog';
import { FeedingLog } from '../types/dbModels/feedLog';
import useAsyncEffect from 'use-async-effect';
import RASLogController from '../src/controllers/RASLogController';
import FeedLogController from '../src/controllers/FeedLogController';
import { DataKey } from '../src/assets/dataKeys';
import useErrorHandler from '../hooks/errorHook';
import { Serie } from '../types/types';
import Autocomplete from '@material-ui/lab/Autocomplete';
import HallController from '../src/controllers/HallController';
import { Hall } from '../types/dbModels/hall';
import { FeedingLogHelper } from '../src/utils/FeedingLogHelper';
import { Source } from '../types/source';
import DataKeyController from '../src/controllers/DataKeyController';
// Dynamic imports
const Chart = dynamic(() => import('react-apexcharts'), { ssr: false });

const initMinuteDiff = 10;
const initialOptions = {
  chart: {
    id: 'realtime',
    type: 'line',
    animations: {
      enabled: true,
      easing: 'linear',
      dynamicAnimation: {
        speed: 2000
      },
      // TODO: test effekt av denne
      animateGradually: {
        enabled: true
      }
    },
    toolbar: {
      show: false
    },
    zoom: {
      enabled: false
    },
    width: '95%',
    height: '80%'
  },
  /*
  markers: {
    size: 0
  },
  dataLabels: {
    enabled: false
  },
  */
  stroke: {
    curve: 'smooth',
    lineCap: 'butt',
    width: 2
  },
  xaxis: {
    type: 'datetime',
    range: 1000 * 60 * initMinuteDiff
  },
  yaxis: [],
  colors: []
};

/*
const initialOptions = {
  xaxis: {
    type: 'datetime',
    range: 1000 * 6
  },
  yaxis: {
    max: 20,
    min: 0
  },
  chart: {
    id: 'realtime',
    animations: {
      enabled: false
    }
  },
  stroke: {
    curve: 'smooth',
    lineCap: 'butt',
    width: 2
  },
};
*/
export default function Home() {
  const errorHandler = useErrorHandler();
  const { t } = useTranslation('common');
  const [options, setOptions] = useState<any>(initialOptions);
  // Brukt for å finte apexcharts
  const [tempOptions, setTempOptions] = useState<any>(initialOptions);
  const [rasLogs, setRasLog] = useState<Array<RasLog>>([]);
  const [feedingLogs, setFeedingLogs] = useState<Array<FeedingLog>>([]);
  const [fromDate, setFromDate] = useState<Date>(DateUtil.subtractFromNow(0, 0, initMinuteDiff));
  const [series, setSeries] = useState<Serie[]>([]);
  const [selectedKeys, setSelectedKeys] = useState<DataKey[]>([]);
  const [collectAxis, setCollectAxis] = useState<boolean>(true);
  const [selectedHallId, setSelectedHallId] = useState<number>(1);
  const [halls, setHalls] = useState<Hall[]>([]);
  const [dataKeys, setDataKeys] = useState<DataKey[]>([]);

  useEffect(() => {
    LiveChartHandler.listenAndUpdate();
    return () => {
      LiveChartHandler.stopConnection();
    };
  }, []);

  useAsyncEffect(async () => {
    const hallsRes = await HallController.getAll();
    const keys = await DataKeyController.getAll();
    setHalls(hallsRes);
    setDataKeys(
      keys.sort((a, b) => {
        if (a.source < b.source) return -1;
      })
    );
  }, []);

  useEffect(() => {
    getNewData(fromDate, true);
  }, [selectedHallId]);

  useEffect(() => {
    rebuildSeries(feedingLogs, rasLogs, true, fromDate);
  }, [selectedKeys, collectAxis]);

  useEffect(() => {
    LiveChartHandler.chartIsUpdating = true;
    LiveChartHandler.series = series;
  }, [series]);

  useEffect(() => {
    LiveChartHandler.options = options;
  }, [options]);

  useEffect(() => {
    LiveChartHandler.pushRasLogs = pushRas;
  }, [rasLogs, series, options, fromDate, halls, selectedHallId]);

  useEffect(() => {
    LiveChartHandler.pushFeedingLogs = pushFeed;
  }, [feedingLogs, series, options, fromDate, halls, selectedHallId]);

  const rebuildSeries = (
    newFeedingLogs: FeedingLog[],
    newRasLogs: RasLog[],
    shouldUpdateOptions: boolean,
    newFromDate: Date
  ) => {
    // creates new series and options with data
    let newSeries = [];
    let newOptions = { ...options };
    newOptions.yaxis = [];
    newOptions.colors = [];
    let numAxis = 0;
    selectedKeys.forEach((datakey, keyIndex) => {
      if (newSeries.findIndex((serie) => serie.key === datakey.key) < 0) {
        let minVal = 0;
        let maxVal = 0;
        let data = [];
        if (datakey.source === Source.RAS) {
          let index = 0;
          data = newRasLogs.map((log, _) => {
            let value = log[datakey.key];
            if (value && new Date(log.dateRecorded) >= newFromDate) {
              if (index === 0) {
                minVal = value;
                maxVal = value;
              } else {
                if (value > maxVal) {
                  maxVal = value;
                }
                if (value < minVal) {
                  minVal = value;
                }
              }
              index++;
            }
            return { x: log.dateRecorded, y: log[datakey.key] };
          });
        } else if (datakey.source === Source.Feeding) {
          let index = 0;
          let mappedFeedingLogs = FeedingLogHelper.getByDataKey(newFeedingLogs, datakey);
          data = mappedFeedingLogs.map((log, _) => {
            let value = log[datakey.key]
            if (value && new Date(log.dateRecorded) >= newFromDate) {
              if (index === 0) {
                minVal = value;
                maxVal = value;
              } else {
                if (value > maxVal) {
                  maxVal = value;
                }
                if (value < minVal) {
                  minVal = value;
                }
              }
              index++;
            }
            return { x: log.dateRecorded, y: log[datakey.key] };
          });
        }
        newSeries.push({
          key: datakey.key,
          type: datakey.type,
          data: data,
          name: datakey.name
        });

        // create options
        newOptions.colors.push(datakey.color ? datakey.color : 'black');
        if (collectAxis) {
          const showAxis = newOptions.yaxis.find((y) => y.seriesName === datakey.unit) ? false : true;
          newOptions.yaxis.push({
            decimalsInFloat: 3,
            seriesName: datakey.unit,
            title: {
              text: datakey.unit
            },
            min: minVal,
            max: maxVal,
            opposite: numAxis % 2 == 1,
            show: showAxis
          });
          if (showAxis) {
            numAxis++;
          }
        } else {
          newOptions.yaxis.push({
            seriesName: datakey.unit,
            title: {
              text: datakey.name
            },
            min: minVal,
            opposite: keyIndex % 2 == 1
          });
        }
      }
    });
    setSeries(newSeries);
    setTempOptions(newOptions);

    // Vil av og til oppdatere denne senere etter ved mer manipulering av data
    if (shouldUpdateOptions) {
      setOptions(newOptions);
    }
    return newOptions;
  };

  const pushRas = (newRasLogList: RasLog[]) => {
    // Inserts element in a always sorted manner
    let newRasLogs = [...rasLogs];
    let newSeries = [...series];
    // TODO:
    let rasLogDataKeys = dataKeys.filter(key => key.source == Source.RAS);
    console.log("rasLogDataKeys")
    console.log(rasLogDataKeys)
    newRasLogList.forEach((newRasLog) => {
      if (selectedHallId === newRasLog.hall.id) {
        let insertIndex = newRasLogs.findIndex((log) => new Date(log.dateRecorded) > new Date(newRasLog.dateRecorded));
        if (insertIndex < 0) {
          newRasLogs.push(newRasLog);
        } else {
          newRasLogs.splice(insertIndex, 0, newRasLog);
        }

        // Updates the right series with the same index
        selectedKeys.forEach((key) => {
          if (rasLogDataKeys.includes(key)) {
            let currentSerie = newSeries.find((o) => o.key === key.key);
            if (currentSerie) {
              if (insertIndex < 0) {
                currentSerie.data.push({ x: newRasLog.dateRecorded, y: newRasLog[key.key] });
              } else {
                currentSerie.data.splice(insertIndex, 0, { x: newRasLog.dateRecorded, y: newRasLog[key.key] });
              }
            }
          }
        });
      }
    });
    updateMinAndMaxValues();
    setRasLog(newRasLogs);
    setSeries(newSeries);
  };

  const pushFeed = (newFeedingLogList: FeedingLog[]) => {
    let currentHall = halls.find(hall => hall.id == selectedHallId);
    // TODO:
    let feedLogDataKeys = dataKeys.filter(key => key.source == Source.Feeding);
    console.log("feedLogDataKeys")
    console.log(feedLogDataKeys)
    if (currentHall) {
      let poolIdsInSelectedHall = currentHall.pools.map(pool => pool.id)

      // Inserts element in a always sorted manner
      newFeedingLogList.forEach(newFeedingLog => {
        if (poolIdsInSelectedHall.includes(newFeedingLog.pool.id)) {
          let insertIndex = feedingLogs.findIndex(log => (new Date(log.dateRecorded)) > (new Date(newFeedingLog.dateRecorded)));
          if (insertIndex < 0) {
            feedingLogs.push(newFeedingLog);
          } else {
            feedingLogs.splice(insertIndex, 0, newFeedingLog);
          }

          // Updates the right series with the same index
          selectedKeys.forEach(key => {
            // TODO: poolNrInHall blir ikke retunert per nå i live data..
            if (feedLogDataKeys.includes(key) && key.poolNrInHall == newFeedingLog.pool?.poolNrInHall) {
              let currentSerie = series.find(o => o.key === key.key);
              if (currentSerie) {
                if (insertIndex < 0) {
                  currentSerie.data.push({ x: newFeedingLog.dateRecorded, y: newFeedingLog[key.key] })
                } else {
                  currentSerie.data.splice(insertIndex, 0, { x: newFeedingLog.dateRecorded, y: newFeedingLog[key.key] })
                }
              }
            }
          });
        }
      });
      updateMinAndMaxValues();
      setFeedingLogs(feedingLogs);
      setSeries(series);
    }
  }

  // This function also rerenders chart
  const updateMinAndMaxValues = (newFromDate: Date = fromDate, hackyOptions: any | null = null) => {
    let currentOptions = hackyOptions === null ? options : hackyOptions;
    selectedKeys.forEach((datakey) => {
      let currentSerie = series.find((o) => o.key === datakey.key);
      if (currentSerie) {
        let minVal = 0;
        let maxVal = 0;
        if (datakey.source === Source.RAS) {
          let index = 0;
          rasLogs.forEach((log, i) => {
            let value = log[datakey.key];
            if (value && new Date(log.dateRecorded) >= newFromDate) {
              if (index === 0) {
                minVal = value;
                maxVal = value;
              } else {
                if (value > maxVal) {
                  maxVal = value;
                }
                if (value < minVal) {
                  minVal = value;
                }
              }
              index++;
            }
          });
        } else if (datakey.source === Source.Feeding) {
          let index = 0;
          let mappedFeedingLogs = FeedingLogHelper.getByDataKey(feedingLogs, datakey);
          mappedFeedingLogs.forEach((log, i) => {
            let value = log[datakey.key]
            if (value && new Date(log.dateRecorded) >= newFromDate) {
              if (index === 0) {
                minVal = value;
                maxVal = value;
              } else {
                if (value > maxVal) {
                  maxVal = value;
                }
                if (value < minVal) {
                  minVal = value;
                }
              }
              index++;
            }
          });
        }
        let currentYaxis = currentOptions.yaxis.find((y) => y.seriesName === datakey.unit);
        if (currentYaxis) {
          currentYaxis.min = minVal;
          currentYaxis.max = maxVal;
        }
      }
    });

    if (!hackyOptions) {
      setOptions(options);
      LiveChartHandler.updateOptions(options);
    }
  };

  const getNewData = async (newFromDate: Date, shouldUpdateOptions: boolean) => {
    try {
      let newRasLogs = await RASLogController.getByDateAndHallID(
        selectedHallId,
        DateUtil.localIsoString(newFromDate),
        DateUtil.localIsoString(new Date())
      );
      let newFeedingLogs = await FeedLogController.getByDateAndHallID(
        selectedHallId,
        DateUtil.localIsoString(newFromDate),
        DateUtil.localIsoString(new Date())
      );
      setRasLog(newRasLogs);
      setFeedingLogs(newFeedingLogs);
      let newOptions = rebuildSeries(newFeedingLogs, newRasLogs, shouldUpdateOptions, newFromDate);
      return newOptions;
    } catch (error) {
      errorHandler(error);
    }
  };

  const getDataFromRange = async (days: number, hours: number, minutes: number) => {
    if (days === 0 && hours === 0 && minutes === 0) {
      return;
    }
    var newFromDate = DateUtil.subtractFromNow(days, hours, minutes);
    let newOptions = tempOptions;

    // vurder og hent uansett? slik bruker har "refresh" mulighet. skal egt ikke være vits
    // fordel:
    //    - Ny data er henter og vi er sikker på at signalR logikken ikke har "mistet" noe
    // ulempe:
    //    - Blir tregere og mindre responsivt (unødvendig mange api calls)
    //    - Ved rezising mister man data

    setFromDate(newFromDate);
    if (newFromDate < fromDate) {
      newOptions = await getNewData(newFromDate, false);
    } else {
      updateMinAndMaxValues(newFromDate, newOptions);
    }
    updateRangeOptions(days, hours, minutes, newOptions, newFromDate);
  };

  const updateRangeOptions = (days: number, hours: number, minute: number, newOptions: any, newFromDate: Date) => {
    let milliSeconds = 0;
    if (days > 0) milliSeconds += 86400000 * days;
    if (hours > 0) milliSeconds += 3600000 * hours;
    if (minute > 0) milliSeconds += 60000 * minute;
    newOptions.xaxis.range = milliSeconds;
    LiveChartHandler.chartIsUpdating = false;
    LiveChartHandler.options = options;
    //setOptions(newOptions);
    LiveChartHandler.updateOptions(newOptions);
  };

  return (
    <div className={styles.container}>
      <Head>
        <title>{t('dashboard')}</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Box mb={2}>
        <Grid container direction="column" spacing={1}>
          <Grid item>
            <DurationInputBar getDataFromRange={getDataFromRange} />
          </Grid>
          <Grid item>
            <FormControl style={{ width: '150px' }}>
              <InputLabel>Hall</InputLabel>
              <Select onChange={(e) => setSelectedHallId(e.target.value as number)} value={selectedHallId}>
                {halls.map((hall) => (
                  <MenuItem key={hall.id} value={hall.id}>
                    {hall.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item>
            <Typography>Velg filtreringsverdier</Typography>
            <Autocomplete
              noOptionsText="Ingen verdier"
              multiple
              options={dataKeys}
              groupBy={(option) => {
                if (option.source === Source.Manual) {
                  return 'Manuell';
                } else if (option.source === Source.RAS) {
                  return 'RAS';
                } else if (option.source === Source.Feeding) {
                  return 'Fôring';
                }
              }}
              onChange={(_, newValue: DataKey[]) => setSelectedKeys(newValue)}
              getOptionLabel={(option: DataKey) => option.name}
              filterSelectedOptions
              renderInput={(params) => <TextField {...params} variant="outlined" placeholder="Verdier" />}
            />
          </Grid>
        </Grid>
      </Box>

      <h1>{t('dashboard')}</h1>
      <div style={{ height: '70vh', width: '80vw' }}>
        <Chart options={options} series={series} width="95%" height="80%" />
      </div>
    </div>
  );
}
