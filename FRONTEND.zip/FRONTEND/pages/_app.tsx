import React, { useEffect } from 'react';
import { StoreProvider } from 'easy-peasy';
import store from '../store/store';
import '../styles/globals.css';
import { ToastProvider, DefaultToastContainer } from 'react-toast-notifications';
import { ThemeProvider } from '../src/theme/ThemeProvider';
import UserController from '../src/controllers/UserController';
import AuthComponent from '../src/components/AuthComponent';
import Layout from '../src/components/Layout';
import Configs from "../src/_config/config";

function MyApp({ Component, pageProps, currentUser }) {
  useEffect(() => {
    console.log(`Environment: ${process.env.NODE_ENV}`);
    console.log(`env: ${Configs.env}`);
    const jssStyles = document.querySelector('#jss-server-side');
    if (jssStyles) {
      jssStyles.parentElement.removeChild(jssStyles);
    }
  }, []);

  const ToastContainer = (props) => <DefaultToastContainer style={{ zIndex: 10000 }} {...props} />;

  return (
    <StoreProvider store={store}>
      <ToastProvider components={{ ToastContainer }}>
        <ThemeProvider>
          <AuthComponent user={currentUser}>
            <Layout>
              <Component {...pageProps} />
            </Layout>
          </AuthComponent>
        </ThemeProvider>
      </ToastProvider>
    </StoreProvider>
  );
}

MyApp.getInitialProps = async ({ ctx }) => {
  const isOnLogin = ctx.pathname === '/login';
  let currentUser = null;
  try {
    currentUser = await UserController.getUpdatedUser(ctx);

    if (isOnLogin && currentUser) {
      ctx.res.writeHead(302, {
        Location: '/'
      });
      ctx.res.end();
    } else if (!isOnLogin && !currentUser) {
      ctx.res.writeHead(302, {
        Location: '/login'
      });
      ctx.res.end();
    }
  } catch (error) {
    if (!isOnLogin) {
      ctx.res.writeHead(302, {
        Location: '/login'
      });
      ctx.res.end();
    }
  }
  return { currentUser };
};

export default MyApp;
