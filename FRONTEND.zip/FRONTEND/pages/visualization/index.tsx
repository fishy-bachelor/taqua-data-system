import Head from 'next/head';
import styles from '../../styles/Common.module.css';
import React, { useState } from 'react';
import dynamic from 'next/dynamic';
import useAsyncEffect from 'use-async-effect';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { ChartTypes, DataKey } from '../../src/assets/dataKeys';
import CircularProgress from '@material-ui/core/CircularProgress';
import { DataPeriod } from '../../types/types';
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import MenuItem from '@material-ui/core/MenuItem';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import HallController from '../../src/controllers/HallController';
import PeriodAdder from '../../src/components/visulization/PeriodAdder';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import dataMapper, { initialOptions } from '../../src/utils/dataMapper';
import { Period } from '../../types/dbModels/period';
import PeriodController from '../../src/controllers/PeriodController';
import useErrorHandler from '../../hooks/errorHook';
import { Hall } from '../../types/dbModels/hall';
import DataKeyController from '../../src/controllers/DataKeyController';
import { Source } from '../../types/source';
import { createStyles, makeStyles } from '@material-ui/core';


// Dynamic imports
const Chart = dynamic(() => import('react-apexcharts'), { ssr: false });

const useStyles = makeStyles((theme) =>
  createStyles({
    accordionSummaryContent: {
      flexGrow: 0,
    }
  })
);

export default function Visualization() {
  const [series, setSeries] = useState<any>([]);
  const [options, setOptions] = useState<any>(initialOptions);
  const [loading, setLoading] = useState<boolean>(false);
  const [selectedKeys, setSelectedKeys] = useState<DataKey[]>([]);
  const [collectAxis, setCollectAxis] = useState<boolean>(true);
  const [halls, setHalls] = useState<Hall[]>([]);
  const [periods, setPeriods] = useState<Period[]>([]);
  const [dataPeriods, setDataPeriods] = useState<DataPeriod[]>([]);
  const [dataKeys, setDataKeys] = useState<DataKey[]>([]);

  const classes = useStyles();

  const errorHandler = useErrorHandler();

  useAsyncEffect(async () => {
    try {
      if (selectedKeys.length > 0 && dataPeriods.length > 0) {
        const { newOptions, newSeries } = await dataMapper(dataPeriods, collectAxis, selectedKeys);
        setOptions(newOptions);
        setSeries(newSeries);
      } else {
        setSeries([]);
      }
    } catch (error) {
      errorHandler(error);
    }
  }, [selectedKeys, dataPeriods, collectAxis]);

  useAsyncEffect(async () => {
    try {
      setLoading(true);
      const hallsRes = await HallController.getAll();
      const periodsRes = await PeriodController.getAll();
      const keys = await DataKeyController.getAll();
      setHalls(hallsRes);
      setPeriods(periodsRes);
      setDataKeys(
        keys.sort((a, b) => {
          if (a.source < b.source) return -1;
        })
      );
    } catch (error) {
      errorHandler(error);
    } finally {
      setLoading(false);
    }
  }, []);

  const removeDataPeriod = (index: number) => {
    const temp = [...dataPeriods];
    temp.splice(index, 1);
    setDataPeriods(temp);
  };

  return (
    <div className={styles.container}>
      <Head>
        <title>Visualisering</title>
      </Head>

      <PeriodAdder
        periods={periods}
        halls={halls}
        addNewDataPeriod={(dataPeriod: DataPeriod) => setDataPeriods([...dataPeriods, dataPeriod])}
      />

      {dataPeriods.map((data, index) => (
        <p key={index} style={{ margin: '0px' }}>
          {!data.period
            ? `Periode ${index + 1} - ${data.hall.name} - Fra: ${data.from.toLocaleDateString()} - Til:
          ${data.to.toLocaleDateString()} - Antall datapunkter:
          ${data.manualData.length + data.rasData.length + data.feedData.length}`
            : `Periode ${index + 1} - ${data.period.name} - ${data.hall.name} - Antall datapunkter:
            ${data.manualData.length + data.rasData.length + data.feedData.length}`}

          <IconButton onClick={() => removeDataPeriod(index)} aria-label="delete">
            <DeleteIcon color="error" />
          </IconButton>
        </p>
      ))}

      {/* Filtering */}
      <Autocomplete
        noOptionsText="Ingen verdier"
        multiple
        options={dataKeys}
        groupBy={(option) => {
          if (option.source === Source.Manual) {
            return 'Manuell';
          } else if (option.source === Source.RAS) {
            return 'RAS';
          } else if (option.source === Source.Feeding) {
            return 'Fôring';
          }
        }}
        onChange={(_, newValue: DataKey[]) => setSelectedKeys(newValue)}
        getOptionLabel={(option: DataKey) => option.name}
        filterSelectedOptions
        renderInput={(params) => <TextField {...params} variant="outlined" placeholder="Verdier" />}
      />
      <Accordion elevation={0} style={{ background: 'transparent' }}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />} IconButtonProps={{ edge: "start" }} style={{ justifyContent: "flex-start" }}
          classes={{ content: classes.accordionSummaryContent }}>
          <Typography style={{ textDecoration: "underline" }}>Avansert</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Box>
            <FormControlLabel
              control={
                <Switch checked={collectAxis} onChange={(e) => setCollectAxis(e.target.checked)} color="primary" />
              }
              label="Samle y-akser med samme enhet"
            />
            <Grid container direction="row" justify="flex-start" alignItems="center">
              {selectedKeys.map((key, index) => {
                return (
                  <Box mt={2} ml={3} key={key.key}>
                    <Grid item>
                      <Typography>{key.name}</Typography>
                    </Grid>
                    <Grid item>
                      <FormControl style={{ width: '100px' }}>
                        <InputLabel>Graftype</InputLabel>
                        <Select
                          value={key.type}
                          onChange={(e) => {
                            const copy = [...selectedKeys];
                            copy[index].type = e.target.value as ChartTypes;
                            setSelectedKeys(copy);
                          }}>
                          <MenuItem value={'line'}>Linje</MenuItem>
                          <MenuItem value={'area'}>Område</MenuItem>
                          <MenuItem value={'bar'}>Bar</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                  </Box>
                );
              })}
            </Grid>
          </Box>
        </AccordionDetails>
      </Accordion>

      <div style={{ height: '70vh' }}>
        {loading ? (
          <div
            style={{
              display: 'flex',
              width: '100%',
              height: '100%',
              justifyContent: 'center',
              alignItems: 'center'
            }}>
            <CircularProgress />
          </div>
        ) : (
            <>
              <Chart options={options} series={series} width="95%" height="100%" />
            </>
          )}
      </div>
    </div>
  );
}
