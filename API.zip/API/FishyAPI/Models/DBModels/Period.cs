﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FishyAPI.Models.DBModels
{
    public class Period
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "StartDate required")]
        public DateTime StartDate { get; set; }

        public Nullable<DateTime> EndDate { get; set; }

        public string Name { get; set; }
        public string Comment { get; set; }

        [DefaultValue("false")]
        public bool Deleted { get; set; }

        public User UserCreatedBy { get; set; }

        // TODO: se hvordan dnene vil fungere i prakses...
        //[Required(ErrorMessage = "Pools is required")]
        public virtual ICollection<PoolPeriod> PoolPeriods { get; set; }
    }
}
