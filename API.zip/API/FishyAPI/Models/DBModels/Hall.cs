﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FishyAPI.Models.DBModels
{
    public class Hall
    {

        public int Id { get; set; }

        [Required(ErrorMessage = "Name required")]
        public string Name { get; set; }

        public string Comment { get; set; }

        [DefaultValue("false")]
        public bool Deleted { get; set; }

        public User UserCreatedBy { get; set; }
        /// TODO: får json serialixation cycle elns av denne, test ut igjen
        
       public virtual ICollection<Pool> Pools { get; set; }
    }
}
