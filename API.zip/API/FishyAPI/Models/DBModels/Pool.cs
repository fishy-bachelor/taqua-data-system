﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FishyAPI.Models.DBModels
{
    public class Pool
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name required")]
        public string Name { get; set; }

        public string Comment { get; set; }

        [Required(ErrorMessage = "poolNrInHall required")]
        public int PoolNrInHall { get; set; }

        [DefaultValue("false")]
        public bool Deleted { get; set; }

        public User UserCreatedBy { get; set; }

        public  Hall Hall { get; set; }


        public virtual ICollection<PoolPeriod> PoolPeriods { get; set; }
    }
}
