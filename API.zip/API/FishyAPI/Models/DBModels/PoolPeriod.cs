﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FishyAPI.Models.DBModels
{
    public class PoolPeriod
    {

        public int Id { get; set; }
        public Pool Pool { get; set; }
        public Period Period { get; set; }

        [Required(ErrorMessage = "StartDate required")]
        public DateTime StartDate { get; set; }

        // Self join parent child relation
        public PoolPeriod Parent { get; set; }
        public virtual ICollection<PoolPeriod> Children { get; set; }


        public Nullable<DateTime> EndDate { get; set; }

    }
}
