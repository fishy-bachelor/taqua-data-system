﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FishyAPI.Models.DBModels
{
    public class RasLog
    {
        public int Id { get; set; }
        public Hall Hall { get; set; }
        public DateTime DateRecorded { get; set; }
        public double smolt_co2sensor { get; set; }
        public double smolt_degaslevel { get; set; }
        public double smolt_degasvacflow { get; set; }
        public double smolt_degasvaclevel { get; set; }
        public double smolt_filterlevelafter { get; set; }
        public double smolt_filterlevelbefore { get; set; }
        public double smolt_flowfresh { get; set; }
        public double smolt_flowsea { get; set; }
        public double smolt_flowsensorout { get; set; }
        public double smolt_heatpumpcondctrl { get; set; }
        public double smolt_ozoneinair1 { get; set; }
        public double smolt_ozoneinair2 { get; set; }
        public double smolt_ozoneinair3 { get; set; }
        public double smolt_ozoneinjpump1_current { get; set; }
        public double smolt_ozoneinjpump2_current { get; set; }
        public double smolt_ozoneinwater1 { get; set; }
        public double smolt_ozoneinwater2 { get; set; }
        public double smolt_ozonepress1 { get; set; }
        public double smolt_ozonepress2 { get; set; }
        public double smolt_phousphsensor { get; set; }
        public double smolt_presssensor { get; set; }
        public double smolt_salinitybackup { get; set; }
        public double smolt_salinityctrl { get; set; }
        public double smolt_systemphbup { get; set; }
        public double smolt_systemphctrl { get; set; }
        public double smolt_temperaturebackup { get; set; }
        public double smolt_temperaturectrl { get; set; }
        public double smolt_t01_level { get; set; }
        public double smolt_t02_level { get; set; }
        public double smolt_t02_oxygen1 { get; set; }
        public double smolt_t02_oxygen2 { get; set; }
        public double smolt_t02_oxygen3 { get; set; }
        public double smolt_t02_oxygen4 { get; set; }
        public double smolt_t02_oxygen5 { get; set; }
        public double smolt_t03_oxygen1 { get; set; }
        public double smolt_t03_oxygen2 { get; set; }
        public double smolt_t03_level { get; set; }
        public double smolt_t03_oxygen3 { get; set; }
        public double smolt_t03_oxygen4 { get; set; }
        public double smolt_t03_oxygen5 { get; set; }
        public double smolt_t04_oxygen1 { get; set; }
        public double smolt_t04_oxygen2 { get; set; }
        public double smolt_t04_oxygen3 { get; set; }
        public double smolt_t04_oxygen4 { get; set; }
        public double smolt_t04_oxygen5 { get; set; }
        public double smolt_t04_level { get; set; }
        public double smolt_t01_oxygen1 { get; set; }
        public double smolt_t01_oxygen2 { get; set; }
        public double smolt_t01_oxygen3 { get; set; }
        public double smolt_t01_oxygen4 { get; set; }
        public double smolt_t01_oxygen5 { get; set; }
        public double ld_ld_ai_mixer_lt01 { get; set; }
        public double ld_ld_ai_mixer_wt01 { get; set; }
        public double ld_ld_ai_supply_ft01 { get; set; }
        public double ld_ld_ai_supply_pt01 { get; set; }
        public double mainprogram_pm500_current_l1 { get; set; }
        public double mainprogram_pm500_current_l2 { get; set; }
        public double mainprogram_pm500_current_l3 { get; set; }
        public double mainprogram_pm500_pf_l1 { get; set; }
        public double mainprogram_pm500_pf_l2 { get; set; }
        public double mainprogram_pm500_pf_l3 { get; set; }
        public double mainprogram_pm500_pf_total { get; set; }
        public double mainprogram_pm500_voltage_l1_l2 { get; set; }
        public double mainprogram_pm500_voltage_l1_l3 { get; set; }
        public double mainprogram_pm500_voltage_l1_n { get; set; }
        public double mainprogram_pm500_voltage_l2_l3 { get; set; }
        public double mainprogram_pm500_voltage_l2_n { get; set; }
        public double mainprogram_pm500_voltage_l3_n { get; set; }
        public double ld_ld_ai_silo_lt01 { get; set; }
        public double smolt_systemphctrl2 { get; set; }
        public double smolt_flowheatingsystem { get; set; }
        public double smolt_temperatureheatingsystem { get; set; }
        public double smolt_temperatureseawater { get; set; }
        public double oxygen_oxy_supply_pt01 { get; set; }
        public double oxygen_oxy_supply_pt02 { get; set; }
        public double oxygen_oxy_supply_wt01 { get; set; }
        public double oxygen_oxy_supply_wt02 { get; set; }
        public double oxygen_udt_chart_oxy_supply_wt01 { get; set; }
        public double oxygen_udt_chart_oxy_supply_wt02 { get; set; }
        public double oxygen_udt_chart_oxy_supply_total { get; set; }
    }
}