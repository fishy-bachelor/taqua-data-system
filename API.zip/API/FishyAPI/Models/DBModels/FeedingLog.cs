﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FishyAPI.Models.DBModels
{
    public class FeedingLog
    {
        public int Id { get; set; }

        public DateTime DateRecorded { get; set; }

        public Pool Pool { get; set; }
        public int Type { get; set; }

        public string ToEquipment { get; set; }

        public double Amount { get; set; }
    
        public string MaterialName { get; set; }
    }
}
