﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace FishyAPI.Models.DBModels
{
    public class User
    {

        public int Id { get; set; }

        [Required(ErrorMessage = "Name required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password required")]
        [JsonIgnore]
        public string Password { get; set; }
        public Roles Role { get; set; }
        public bool IsDeleted { get; set; }
    }
}