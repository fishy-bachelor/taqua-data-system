﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FishyAPI.Models.DBModels
{
    public class ManualInput
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "DateRecorded required")]
        // TODO se om det finnes noe default verdier til now..
        // se https://stackoverflow.com/questions/691035/setting-the-default-value-of-a-datetime-property-to-datetime-now-inside-the-syst
        //[DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime DateRecorded { get; set; }

        // Measured in %
        public Nullable<double> TGP { get; set; }

        // Measured in %
        public Nullable<double> Oxygen { get; set; }

        // Measured in %
        public Nullable<double> RES { get; set; }

        // Measured in mV
        public Nullable<double> Redox { get; set; }

        // Measured in mg/l
        public Nullable<double> Ammonium { get; set; }

        // Measured in mg/l
        public Nullable<double> Nitritt { get; set; }

        // Measured in mg/l
        public Nullable<double> Nitrat { get; set; }

        // Measured in mmol/l
        public Nullable<double> Alkalitet { get; set; }

        // Measured in FAU
        public Nullable<int> Turbiditet { get; set; }

        // Measured in m3/t
        public Nullable<double> SpeedWater { get; set; }

        public String Comment { get; set; }

        public User UserCreatedBy { get; set; }

        [Required(ErrorMessage = "Hall is required")]
        public Hall Hall { get; set; }
    }
}
