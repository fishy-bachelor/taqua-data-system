using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FishyAPI.Models.DBModels
{
    public class DataKey
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name required")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Key required")]
        public string Key {get; set;}
        [Required(ErrorMessage = "Color required")]
        public string Color {get; set;}
        [Required(ErrorMessage = "Unit required")]
        public string Unit {get; set;}
        [Required(ErrorMessage = "Source required")]
        public Source Source {get; set;}
        [Required(ErrorMessage = "IdealValue required")]
        public decimal IdealValue {get; set;}
        public string? Comment {get; set;}

        public int? PoolNrInHall { get; set; }

        public bool Deleted {get; set;} = false;

    }
}
