﻿using System;
using FishyAPI.Models.DBModels;
using Microsoft.EntityFrameworkCore;

namespace FishyAPI.Models
{
    public class DatabaseContext : DbContext
    {




        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {

        }

        public DbSet<User> Users { get; set; }

        public DbSet<Hall> Halls { get; set; }

        public DbSet<Period> Periods { get; set; }

        public DbSet<ManualInput> ManualInputs { get; set; }

        public DbSet<Pool> Pools { get; set; }

        public DbSet<PoolPeriod> PoolPeriods { get; set; }

        public DbSet<FeedingLog> FeedingLogs { get; set; }

        public DbSet<RasLog> RasLogs { get; set; }

        public DbSet<DataKey> DataKeys { get; set; }

    }

}
