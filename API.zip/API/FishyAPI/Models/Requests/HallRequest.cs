﻿using FishyAPI.Models.DBModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace FishyAPI.Models.Requests
{
    public class HallRequest: Hall
    {
        [JsonIgnore]
        public new int Id { get; set; }

        [DefaultValue("false")]
        [JsonIgnore]
        public new bool Deleted { get; set; }

        [JsonIgnore]
        public new User UserCreatedBy { get; set; }

       [JsonIgnore]
       public new virtual ICollection<Pool> Pools { get; set; }
    }
}
