﻿using FishyAPI.Models.DBModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace FishyAPI.Models.Requests
{
    public class PoolRequest : Pool
    {
        [JsonIgnore]
        public new int Id { get; set; }

        [DefaultValue("false")]
        [JsonIgnore]
        public new bool Deleted { get; set; }

        [JsonIgnore]
        public new User UserCreatedBy { get; set; }

        [JsonIgnore]
        public new virtual ICollection<PoolPeriod> PoolPeriods { get; set; }

        [JsonIgnore]
        public new Hall Hall { get; set; }

        [Required(ErrorMessage = "HallId is required")]
        public int HallId { get; set; }
    }
}
