﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace FishyAPI.Models
{
    public class ChangeUserRequest
    {

        [Required(ErrorMessage = "User id is required")]
        public int Id { get; set; }

        public string Name { get; set; }

        private string _NewPassword;
        [MinLength(6, ErrorMessage = "NewPassword should be 6 or longer")]
        public string NewPassword { get { return _NewPassword; } set { _NewPassword = string.IsNullOrWhiteSpace(value) ? null : value; } }

        private string _Email;
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get { return _Email; } set { _Email = string.IsNullOrWhiteSpace(value) ? null : value; } }
    }
}
