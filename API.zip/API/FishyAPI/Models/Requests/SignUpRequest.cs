﻿using System.ComponentModel.DataAnnotations;

namespace FishyAPI.Models
{
    public class SignUpRequest
    {
        [Required(ErrorMessage = "Name required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password required")]
        [MinLength(6)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Role is required")]
        [EnumDataTypeAttribute(typeof(Roles), ErrorMessage =("User role does not exist"))]
        public Roles Role {get; set;}
    }
}
