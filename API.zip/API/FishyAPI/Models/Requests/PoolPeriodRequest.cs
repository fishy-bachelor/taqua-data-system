﻿using FishyAPI.Models.DBModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace FishyAPI.Models.Requests
{
    public class PoolPeriodRequest: PoolPeriod
    {

        [JsonIgnore]
        public new int Id { get; set; }

        [Required(ErrorMessage = "PoolId required")]
        public  int PoolId { get; set; }
        [JsonIgnore]
        public new Pool Pool { get; set; }
        [JsonIgnore]
        public  int PeriodId { get; set; }
        [JsonIgnore]
        public new Period Period { get; set; }

        // Self join parent child relation
        [Required(ErrorMessage = "ParenId required")]
        public  int ParentId { get; set; }
        [JsonIgnore]
        public new PoolPeriod Parent { get; set; }
        [JsonIgnore]
        public new virtual ICollection<PoolPeriod> Children { get; set; }
    }
}
