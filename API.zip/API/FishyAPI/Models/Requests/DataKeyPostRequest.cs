using FishyAPI.Models.DBModels;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace FishyAPI.Models.Requests
{
    public class DataKeyPostRequest : DataKey
    {
        [JsonIgnore]
        public new int Id { get; set; }

        [JsonIgnore]
        public new bool Deleted { get; set; }
    }
}
