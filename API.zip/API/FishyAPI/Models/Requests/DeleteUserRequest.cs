﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace FishyAPI.Models
{
    public class DeleteUserRequest
    {
        [Required(ErrorMessage = "User id is required")]
        public int Id { get; set; }
    }
}
