﻿using System.ComponentModel.DataAnnotations;

namespace FishyAPI.Models
{
    public class AuthenticateRequest
    {


        [Required(ErrorMessage = "Email required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password required")]
        public string Password { get; set; }
    }
}