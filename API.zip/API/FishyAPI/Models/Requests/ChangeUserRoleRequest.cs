﻿using System.ComponentModel.DataAnnotations;

namespace FishyAPI.Models
{
    public class ChangeUserRoleRequest
    {

        [Required(ErrorMessage = "User id is required")]
        public int Id { get; set; }

        [Required(ErrorMessage = "Role is required")]
        [EnumDataTypeAttribute(typeof(Roles), ErrorMessage =("User role does not exist"))]
        public Roles Role { get; set; }

    }
}