﻿using System;
namespace FishyAPI.Models.Hub
{
    public class SendDataPayload
    {
        public DateTime Date { get; set; }
        public int Value { get; set; }
    }
}
