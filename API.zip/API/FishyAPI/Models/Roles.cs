﻿using System;
namespace FishyAPI.Models
{
    public enum Roles
    {
        Reader = 0,
        Writer = 1,
        Admin = 2,
        Scheduler = 3,
    }
}
