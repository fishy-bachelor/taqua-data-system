﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FishyAPI.Migrations
{
    public partial class added_poolNrinHall_pool_required : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
