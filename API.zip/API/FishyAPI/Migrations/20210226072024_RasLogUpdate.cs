﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FishyAPI.Migrations
{
    public partial class RasLogUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_current_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_current_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_current_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_pf_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_pf_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_pf_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_pf_total",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l1_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l1_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l1_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l2_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l2_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l3_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_current_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_current_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_current_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_pf_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_pf_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_pf_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_pf_total",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l1_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l1_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l1_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l2_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l2_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l3_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_oxy_supply_pt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_oxy_supply_pt02",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_oxy_supply_wt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_oxy_supply_wt02",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_udt_chart_oxy_supply_total",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_udt_chart_oxy_supply_wt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_udt_chart_oxy_supply_wt02",
                table: "RasLogs");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_current_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_current_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_current_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_pf_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_pf_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_pf_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_pf_total",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l1_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l1_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l1_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l2_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l2_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l3_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_current_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_current_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_current_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_pf_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_pf_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_pf_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_pf_total",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l1_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l1_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l1_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l2_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l2_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l3_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_oxy_supply_pt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_oxy_supply_pt02",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_oxy_supply_wt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_oxy_supply_wt02",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_udt_chart_oxy_supply_total",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_udt_chart_oxy_supply_wt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_udt_chart_oxy_supply_wt02",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }
    }
}
