﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FishyAPI.Migrations
{
    public partial class capital_letters : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "poolNrInHall",
                table: "Pools",
                newName: "PoolNrInHall");

            migrationBuilder.RenameColumn(
                name: "poolNrInHall",
                table: "DataKeys",
                newName: "PoolNrInHall");

            migrationBuilder.RenameColumn(
                name: "comment",
                table: "DataKeys",
                newName: "Comment");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "PoolNrInHall",
                table: "Pools",
                newName: "poolNrInHall");

            migrationBuilder.RenameColumn(
                name: "PoolNrInHall",
                table: "DataKeys",
                newName: "poolNrInHall");

            migrationBuilder.RenameColumn(
                name: "Comment",
                table: "DataKeys",
                newName: "comment");
        }
    }
}
