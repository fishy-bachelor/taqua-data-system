﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FishyAPI.Migrations
{
    public partial class new_ras_log_model : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Temperature",
                table: "RasLogs",
                newName: "smolt_temperatureseawater");

            migrationBuilder.RenameColumn(
                name: "Ph",
                table: "RasLogs",
                newName: "smolt_temperatureheatingsystem");

            migrationBuilder.AddColumn<double>(
                name: "ld_ld_ai_mixer_lt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "ld_ld_ai_mixer_wt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "ld_ld_ai_silo_lt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "ld_ld_ai_supply_ft01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "ld_ld_ai_supply_pt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_current_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_current_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_current_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_pf_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_pf_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_pf_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_pf_total",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_current_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_current_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_current_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_pf_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_pf_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_pf_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_pf_total",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l1_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l1_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l1_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l2_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l2_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sa2_voltage_l3_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_current_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_current_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_current_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_pf_l1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_pf_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_pf_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_pf_total",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l1_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l1_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l1_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l2_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l2_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_sb2_voltage_l3_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_voltage_l1_l2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_voltage_l1_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_voltage_l1_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_voltage_l2_l3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_voltage_l2_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "mainprogram_pm500_voltage_l3_n",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_co2sensor",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_degaslevel",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_degasvacflow",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_degasvaclevel",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_filterlevelafter",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_filterlevelbefore",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_flowfresh",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_flowheatingsystem",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_flowsea",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_flowsensorout",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_heatpumpcondctrl",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_ozoneinair1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_ozoneinair2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_ozoneinair3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_ozoneinjpump1_current",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_ozoneinjpump2_current",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_ozoneinwater1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_ozoneinwater2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_ozonepress1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_ozonepress2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_phousphsensor",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_presssensor",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_salinitybackup",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_salinityctrl",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_systemphbup",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_systemphctrl",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_systemphctrl2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t01_level",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t01_oxygen1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t01_oxygen2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t01_oxygen3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t01_oxygen4",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t01_oxygen5",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t02_level",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t02_oxygen1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t02_oxygen2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t02_oxygen3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t02_oxygen4",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t02_oxygen5",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t03_level",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t03_oxygen1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t03_oxygen2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t03_oxygen3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t03_oxygen4",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t03_oxygen5",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t04_level",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t04_oxygen1",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t04_oxygen2",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t04_oxygen3",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t04_oxygen4",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_t04_oxygen5",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_temperaturebackup",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "smolt_temperaturectrl",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ld_ld_ai_mixer_lt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "ld_ld_ai_mixer_wt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "ld_ld_ai_silo_lt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "ld_ld_ai_supply_ft01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "ld_ld_ai_supply_pt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_current_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_current_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_current_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_pf_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_pf_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_pf_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_pf_total",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_current_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_current_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_current_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_pf_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_pf_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_pf_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_pf_total",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l1_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l1_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l1_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l2_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l2_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sa2_voltage_l3_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_current_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_current_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_current_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_pf_l1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_pf_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_pf_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_pf_total",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l1_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l1_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l1_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l2_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l2_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_sb2_voltage_l3_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_voltage_l1_l2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_voltage_l1_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_voltage_l1_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_voltage_l2_l3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_voltage_l2_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "mainprogram_pm500_voltage_l3_n",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_co2sensor",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_degaslevel",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_degasvacflow",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_degasvaclevel",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_filterlevelafter",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_filterlevelbefore",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_flowfresh",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_flowheatingsystem",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_flowsea",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_flowsensorout",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_heatpumpcondctrl",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_ozoneinair1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_ozoneinair2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_ozoneinair3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_ozoneinjpump1_current",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_ozoneinjpump2_current",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_ozoneinwater1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_ozoneinwater2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_ozonepress1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_ozonepress2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_phousphsensor",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_presssensor",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_salinitybackup",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_salinityctrl",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_systemphbup",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_systemphctrl",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_systemphctrl2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t01_level",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t01_oxygen1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t01_oxygen2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t01_oxygen3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t01_oxygen4",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t01_oxygen5",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t02_level",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t02_oxygen1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t02_oxygen2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t02_oxygen3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t02_oxygen4",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t02_oxygen5",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t03_level",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t03_oxygen1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t03_oxygen2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t03_oxygen3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t03_oxygen4",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t03_oxygen5",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t04_level",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t04_oxygen1",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t04_oxygen2",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t04_oxygen3",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t04_oxygen4",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_t04_oxygen5",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_temperaturebackup",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "smolt_temperaturectrl",
                table: "RasLogs");

            migrationBuilder.RenameColumn(
                name: "smolt_temperatureseawater",
                table: "RasLogs",
                newName: "Temperature");

            migrationBuilder.RenameColumn(
                name: "smolt_temperatureheatingsystem",
                table: "RasLogs",
                newName: "Ph");
        }
    }
}
