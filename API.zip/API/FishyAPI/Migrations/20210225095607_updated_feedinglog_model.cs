﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FishyAPI.Migrations
{
    public partial class updated_feedinglog_model : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FeedingLogs_Halls_HallId",
                table: "FeedingLogs");

            migrationBuilder.DropColumn(
                name: "AverageFishWeight",
                table: "FeedingLogs");

            migrationBuilder.RenameColumn(
                name: "HallId",
                table: "FeedingLogs",
                newName: "PoolId");

            migrationBuilder.RenameColumn(
                name: "FeedWeight",
                table: "FeedingLogs",
                newName: "Amount");

            migrationBuilder.RenameIndex(
                name: "IX_FeedingLogs_HallId",
                table: "FeedingLogs",
                newName: "IX_FeedingLogs_PoolId");

            migrationBuilder.AddColumn<string>(
                name: "MaterialName",
                table: "FeedingLogs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ToEquipment",
                table: "FeedingLogs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Type",
                table: "FeedingLogs",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_FeedingLogs_Pools_PoolId",
                table: "FeedingLogs",
                column: "PoolId",
                principalTable: "Pools",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FeedingLogs_Pools_PoolId",
                table: "FeedingLogs");

            migrationBuilder.DropColumn(
                name: "MaterialName",
                table: "FeedingLogs");

            migrationBuilder.DropColumn(
                name: "ToEquipment",
                table: "FeedingLogs");

            migrationBuilder.DropColumn(
                name: "Type",
                table: "FeedingLogs");

            migrationBuilder.RenameColumn(
                name: "PoolId",
                table: "FeedingLogs",
                newName: "HallId");

            migrationBuilder.RenameColumn(
                name: "Amount",
                table: "FeedingLogs",
                newName: "FeedWeight");

            migrationBuilder.RenameIndex(
                name: "IX_FeedingLogs_PoolId",
                table: "FeedingLogs",
                newName: "IX_FeedingLogs_HallId");

            migrationBuilder.AddColumn<double>(
                name: "AverageFishWeight",
                table: "FeedingLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddForeignKey(
                name: "FK_FeedingLogs_Halls_HallId",
                table: "FeedingLogs",
                column: "HallId",
                principalTable: "Halls",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
