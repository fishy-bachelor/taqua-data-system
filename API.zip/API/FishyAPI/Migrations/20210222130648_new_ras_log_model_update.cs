﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FishyAPI.Migrations
{
    public partial class new_ras_log_model_update : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "oxygen_oxy_supply_pt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_oxy_supply_pt02",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_oxy_supply_wt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_oxy_supply_wt02",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_udt_chart_oxy_supply_total",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_udt_chart_oxy_supply_wt01",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "oxygen_udt_chart_oxy_supply_wt02",
                table: "RasLogs",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "oxygen_oxy_supply_pt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_oxy_supply_pt02",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_oxy_supply_wt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_oxy_supply_wt02",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_udt_chart_oxy_supply_total",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_udt_chart_oxy_supply_wt01",
                table: "RasLogs");

            migrationBuilder.DropColumn(
                name: "oxygen_udt_chart_oxy_supply_wt02",
                table: "RasLogs");
        }
    }
}
