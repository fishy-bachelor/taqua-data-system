﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FishyAPI.Migrations
{
    public partial class added_poolNrInHall_datakeys : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "poolNrInHall",
                table: "DataKeys",
                type: "int",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "poolNrInHall",
                table: "DataKeys");
        }
    }
}
