﻿using System;
using System.Threading.Tasks;
using FishyAPI.Models;
using FishyAPI.Models.Hub;
using Microsoft.AspNetCore.SignalR;

namespace FishyAPI.Hubs
{

    [Authorize(Roles.Scheduler)]
    public class DataHub : Hub
    {
        private readonly Random _random = new Random();

        public async Task SendTestData()
        {
            var payload = new SendDataPayload { Date = DateTime.Now, Value = _random.Next(1, 20) };
            await Clients.All.SendAsync("ReceiveData", payload);
        }
    }
}

