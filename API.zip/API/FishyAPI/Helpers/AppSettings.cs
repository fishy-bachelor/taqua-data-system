﻿namespace FishyAPI.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}