﻿using System;
using System.Collections.Generic;
using System.Linq;
using FishyAPI.Models.DBModels;

namespace FishyAPI.Helpers
{
    public class DataFormatter
    {
        public static IEnumerable<FeedingLog> AverageFeedingLog(List<FeedingLog> data)
        {
            try
            {
                if (data.Count() <= 2000)
                {
                    return data;
                }

                int interval = data.Count() / 1000;

                int index = 0;
                List<FeedingLog> result = new List<FeedingLog>();
                while (index <= data.Count())
                {
                    if (index + interval > data.Count())
                    {
                        break;
                    }

                    var slice = data.GetRange(index, interval);

                    result.Add(new FeedingLog
                    {
                        DateRecorded = data[(index * 2 + interval) / 2].DateRecorded,
                        //   AverageFishWeight = slice.Average(r => r.AverageFishWeight),
                        //  FeedWeight = slice.Average(r => r.FeedWeight),
                    });

                    index += interval;
                }

                return result;
            }
            catch (Exception e)
            {
                throw new Exception("Error finding average...", e);
            }
        }

        public static IEnumerable<RasLog> AverageRasLog(List<RasLog> data)
        {
            try
            {
                if (data.Count() <= 2000)
                {
                    return data;
                }
                int interval = data.Count() / 1000;

                int index = 0;
                List<RasLog> result = new List<RasLog>();
                while (index <= data.Count())
                {
                    if (index + interval > data.Count())
                    {
                        break;
                    }

                    var slice = data.GetRange(index, interval);

                    result.Add(new RasLog
                    {
                        DateRecorded = data[(index * 2 + interval) / 2].DateRecorded,
                        // TODO: ådi fiks
                        smolt_t02_oxygen1 = slice.Average(r => r.smolt_t02_oxygen1),
                        smolt_flowfresh = slice.Average(r => r.smolt_flowfresh),
                    });

                    index += interval;
                }

                return result;
            }
            catch (Exception e)
            {
                throw new Exception("Error finding average...");
            }
        }
    }
}
