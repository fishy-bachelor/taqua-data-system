﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace FishyAPI.Helpers
{
    public static class SqlHelper
    {
        public static List<T> RawSqlQuery<T>(DbContext context, string query, object[] parameters, Func<DbDataReader, T> map)
        {
            
                using (var command = context.Database.GetDbConnection().CreateCommand())
                {
                    command.CommandText = query;
                    command.CommandType = CommandType.Text;
                    
                    int i = 0;
                    foreach (object p in parameters) {
                        var sqlParam = "@p" + i.ToString();
                        var parameter = new SqlParameter(sqlParam, p);
                        command.Parameters.Add(parameter);
                        i++;
                    }

                    context.Database.OpenConnection();

                    using (var result = command.ExecuteReader())
                    {
                        var entities = new List<T>();

                        while (result.Read())
                        {
                            entities.Add(map(result));
                        }
                        context.Database.CloseConnection();
                        return entities;
                    }
                }
            
        }
    }
}
