﻿using FishyAPI.Models;
using FishyAPI.Models.DBModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
public class AuthorizeAttribute : Attribute, IAuthorizationFilter
{
    private Roles _minRole = Roles.Reader;

    public AuthorizeAttribute(Roles role = Roles.Reader)
    {
        _minRole = role;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var user = (User)context.HttpContext.Items["User"];
        if (user == null)
        {
            // not logged in
            context.Result = new JsonResult(new { message = "Unauthorized" }) { StatusCode = StatusCodes.Status401Unauthorized };
        }
        else if (user.Role == Roles.Scheduler && _minRole == Roles.Scheduler)
        {
            // this works
        }
        else if (user.Role < _minRole || user.Role == Roles.Scheduler)
        {
            // Not the correct role
            context.Result = new JsonResult(new { message = "Unauthorized, needs elevated privilege." }) { StatusCode = StatusCodes.Status401Unauthorized };
        }


    }
}