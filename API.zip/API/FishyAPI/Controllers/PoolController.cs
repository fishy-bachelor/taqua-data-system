﻿using FishyAPI.Models;
using FishyAPI.Models.DBModels;
using FishyAPI.Models.Requests;
using FishyAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FishyAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class PoolController : ControllerBase
    {

        private const string AllPoolsCacheKey = "get-all-pools-key";

        private readonly DatabaseContext _context;
        private IUserService _userService;
        private readonly IMemoryCache _cache;



        public PoolController(DatabaseContext context, IUserService userService, IMemoryCache cache)
        {
            _context = context;
            _userService = userService;
            _cache = cache;
        }

        // GET: api/<ValuesController>
        [HttpGet]
        public ActionResult<IEnumerable<Pool>> Get()
        {
            try
            {
                if (_cache.TryGetValue(AllPoolsCacheKey, out List<Pool> cachedPools))
                {
                    return Ok(cachedPools);
                }
                // TODO: legg til å hente ut perioder her
                var allPools = _context.Pools.Where((o) => !o.Deleted).Select(o => new
                {
                    o.Id,
                    o.Name,
                    o.Comment,
                    o.PoolNrInHall,
                    HallId = o.Hall.Id
                }).ToList();
                _cache.Set(AllPoolsCacheKey, allPools);
                return Ok(allPools);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public ActionResult<Pool> Get(int id)
        {
            try
            {
                if (_cache.TryGetValue($"pool-{id}", out Pool cachedPools))
                {
                    return Ok(cachedPools);
                }
                // TODO: legg til å hente ut perioder her
                var pool = _context.Pools.Where((o) => o.Id == id && !o.Deleted).Select(o => new
                {
                    o.Id,
                    o.Name,
                    o.Comment,
                    o.PoolNrInHall,
                    HallId = o.Hall.Id
                }).FirstOrDefault();
                _cache.Set($"pool-{id}", pool);
                return Ok(pool);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // POST api/<ValuesController>
        [HttpPost]
        [Authorize(Roles.Writer)]
        public ActionResult<Hall> Post(PoolRequest model)
        {
            try
            {
                // TODO: teste denne..
                if (_context.Pools.Any(o => (o.Name == model.Name || o.PoolNrInHall == model.PoolNrInHall) && o.Hall.Id == model.HallId && !o.Deleted))
                {
                    return StatusCode(409, "Pool already exists"); ;
                }

                var currentUser = _userService.GetCurrentUser(HttpContext);
                if (currentUser == null)
                {
                    return StatusCode(500);
                }

                var hall = _context.Halls.Where((o) => o.Id == model.HallId).FirstOrDefault();
                if (hall == null)
                {
                    return NotFound("Hall not found");
                }

                if (model.PoolNrInHall < 1 || model.PoolNrInHall > 4)
                {
                    return UnprocessableEntity("PoolNrInHall must be between 1 and 4");
                }

                var pool = _context.Pools.Add(model);
                pool.Entity.Hall = hall;
                pool.Entity.UserCreatedBy = currentUser;

                _context.SaveChanges();
                _cache.Remove(AllPoolsCacheKey);
                return Ok(pool.Entity);
            }
            catch
            {
                return StatusCode(500);
            }
        }


        // PUT api/<ValuesController>/5
        [HttpPut("{id}")]
        [Authorize(Roles.Writer)]
        public ActionResult<Hall> Put(int id, [FromBody] PoolRequest model)
        {
            try
            {
                var pool = _context.Pools.Where((o) => o.Id == id).FirstOrDefault();
                if (pool == null)
                {
                    return NotFound();
                }

                // Unique names
                // Se over denne, mulig vi bare trenger unik per hall..
                // TODO: teste denne..
                if (_context.Pools.Any(o => (o.Name == model.Name || o.PoolNrInHall == model.PoolNrInHall) && o.Hall.Id == model.HallId && o.Id != id && !o.Deleted))
                {
                    return StatusCode(409, "Name already exists"); ;
                }
                var hall = _context.Halls.Where((o) => o.Id == model.HallId).FirstOrDefault();
                if (hall == null)
                {
                    return NotFound("Hall not found");
                }

                if (model.PoolNrInHall < 1 || model.PoolNrInHall > 4)
                {
                    return UnprocessableEntity("PoolNrInHall must be between 1 and 4");
                }

                pool.Name = model.Name;
                pool.Comment = model.Comment;
                pool.PoolNrInHall = model.PoolNrInHall;
                pool.Hall = hall;
                _context.SaveChanges();
                _cache.Remove(AllPoolsCacheKey);
                _cache.Remove($"pool-{id}");
                return Ok(pool);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        [Authorize(Roles.Writer)]
        public IActionResult Delete(int id)
        {
            try
            {
                var pool = _context.Pools.Where((o) => o.Id == id).FirstOrDefault();
                if (pool == null)
                {
                    return NotFound();
                }
                if (pool.Deleted)
                {
                    StatusCode(409, "pool already Deleted");
                }
                pool.Deleted = true;
                _context.SaveChanges();
                _cache.Remove(AllPoolsCacheKey);
                _cache.Remove($"pool-{id}");
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
