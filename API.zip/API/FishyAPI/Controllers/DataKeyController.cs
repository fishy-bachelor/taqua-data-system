using FishyAPI.Models;
using FishyAPI.Models.DBModels;
using FishyAPI.Models.Requests;
using FishyAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860


namespace FishyAPI.Controllers
{


    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class DataKeyController : ControllerBase
    {
        private const string AllDataKeysCacheKey = "get-all-datakeys-key";

        private readonly DatabaseContext _context;
        private IUserService _userService;
        private readonly IMemoryCache _cache;

        public DataKeyController(DatabaseContext context, IUserService userService, IMemoryCache cache)
        {
            _context = context;
            _userService = userService;
            _cache = cache;
        }

        // GET: <DataKeyController>
        [HttpGet]
        public ActionResult<IEnumerable<DataKey>> Get()
        {
            try
            {
                if (_cache.TryGetValue(AllDataKeysCacheKey, out IEnumerable<Hall> cachedKeys))
                {
                    return Ok(cachedKeys);
                }
                var allDataKeys = _context.DataKeys.Where(key => !key.Deleted).ToList();
                _cache.Set(AllDataKeysCacheKey, allDataKeys);
                return Ok(allDataKeys);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // GET <DataKeyController>/5
        [HttpGet("{id}")]
        public ActionResult<DataKey> Get(int id)
        {
            try
            {
                if (_cache.TryGetValue($"datakey-{id}", out DataKey cachedKeys))
                {
                    return Ok(cachedKeys);
                }

                var datakey = _context.DataKeys.Where(datakey => datakey.Id == id && !datakey.Deleted).FirstOrDefault();

                if (datakey == null)
                {
                    return NotFound();
                }
                _cache.Set($"datakey-{id}", datakey);
                return Ok(datakey);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // POST <DataKeyController>
        [HttpPost]
        [Authorize(Roles.Admin)]
        public ActionResult<DataKey> Post(DataKeyPostRequest model)
        {
            try
            {
                if (_context.DataKeys.Where(o => o.Key == model.Key).FirstOrDefault() != null)
                {
                    return Conflict("Key already exist");
                }
                var dataKey = _context.DataKeys.Add(model);

                _context.SaveChanges();
                _cache.Remove(AllDataKeysCacheKey);
                return Ok(dataKey.Entity);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return StatusCode(500);
            }
        }

        // PUT <DataKeyController>/5
        [HttpPut("{id}")]
        [Authorize(Roles.Admin)]
        public ActionResult<DataKey> Put(int id, [FromBody] DataKeyPostRequest model)
        {
            try
            {
                var dataKey = _context.DataKeys.Where((o) => o.Id == id && !o.Deleted).FirstOrDefault();
                if (dataKey == null)
                {
                    return NotFound();
                }

                // Unique key
                if (_context.DataKeys.Any(o => o.Key == model.Key && o.Id != id))
                {
                    return StatusCode(409, "Key already exists"); ;
                }

                dataKey.Name = model.Name;
                dataKey.Color = model.Color;
                dataKey.Comment = model.Comment;
                dataKey.IdealValue = model.IdealValue;
                dataKey.Key = model.Key;
                dataKey.Source = model.Source;
                dataKey.Unit = model.Unit;

                dataKey.Deleted = false;

                _context.SaveChanges();
                _cache.Remove(AllDataKeysCacheKey);
                _cache.Remove($"datakey-{id}");
                return Ok(dataKey);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // DELETE <HallController>/5
        [HttpDelete("{id}")]
        [Authorize(Roles.Admin)]
        public IActionResult Delete(int id)
        {
            try
            {
                var dataKey = _context.DataKeys.Where((o) => o.Id == id).FirstOrDefault();
                if (dataKey == null)
                {
                    return NotFound();
                }
                if (dataKey.Deleted)
                {
                    StatusCode(409, "Datakey is already Deleted");
                }
                dataKey.Deleted = true;
                _context.SaveChanges();
                _cache.Remove(AllDataKeysCacheKey);
                _cache.Remove($"datakey-{id}");
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
