﻿using FishyAPI.Models;
using FishyAPI.Models.DBModels;
using FishyAPI.Models.Requests;
using FishyAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FishyAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class PoolPeriodController : ControllerBase
    {
        private const string AllPeriodsCacheKey = "get-all-periods-key";

        private readonly DatabaseContext _context;
        private IUserService _userService;
        private readonly IMemoryCache _cache;


        public PoolPeriodController(DatabaseContext context, IUserService userService, IMemoryCache cache)
        {
            _context = context;
            _userService = userService;
            _cache = cache;
        }


        /*
        // GET: api/<ValuesController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }
        */

        // POST api/<ValuesController>
        [HttpPost]
        [Authorize(Roles.Writer)]
        public ActionResult<PoolPeriod> Post([FromBody] PoolPeriodRequest model)
        {
            try
            {
                // TODOO: pool id bør egt være en list emed ider..
                // TODO: bør ha sjekk om poolPeriod som lages allerede finnes.. gir 500 nå pga db error
                var currentUser = _userService.GetCurrentUser(HttpContext);
                if (currentUser == null)
                {
                    return StatusCode(500);
                }

                var pool = _context.Pools.Where((o) => o.Id == model.PoolId).Include((o) => o.Hall).FirstOrDefault();
                if (pool == null)
                {
                    return NotFound("new pool not found");
                }

                var parentPoolPeriod = _context.PoolPeriods.Where((o) => o.Id == model.ParentId).Include(o => o.Period).FirstOrDefault();
                if (parentPoolPeriod == null)
                {
                    return NotFound("parentPoolPeriod not found. Check the parent ids");
                }
                var poolPeriod = _context.PoolPeriods.Add(new PoolPeriod
                {
                    StartDate = model.StartDate,
                    Pool = pool,
                    Period = parentPoolPeriod.Period,
                    Parent = parentPoolPeriod,
                    EndDate = model.EndDate,
                });


                _context.SaveChanges();
                _cache.Remove(AllPeriodsCacheKey);
                return Ok(poolPeriod.Entity);
            }
            catch
            {
                return StatusCode(500);
            }
        }


        // PUT api/<ValuesController>/5
        [HttpPut("{id}")]
        [Authorize(Roles.Writer)]
        public ActionResult<PoolPeriod> Put(int id, [FromBody] PoolPeriodRequest model)
        {
            try
            {
                var poolPeriod = _context.PoolPeriods.Where((o) => o.Id == id).FirstOrDefault();
                if (poolPeriod == null)
                {
                    return NotFound();
                }


                // Betyr ikke dette at man må flyttes hver gang den skal oppdateres? lager en patch endepunkt 
                var pool = _context.Pools.Where((o) => o.Id == model.PoolId).FirstOrDefault();
                if (pool == null)
                {
                    return NotFound("new pool not found");
                }

                var parentPoolPeriod = _context.PoolPeriods.Where((o) => o.Id == model.ParentId).Include(o => o.Period).FirstOrDefault();
                if (parentPoolPeriod == null && model.ParentId != 0)
                {
                    return NotFound("parentPoolPeriod not found. Check the parent ids");
                }


                if (parentPoolPeriod != null)
                {
                    poolPeriod.Parent = parentPoolPeriod;
                    poolPeriod.Period = parentPoolPeriod.Period;
                }
                poolPeriod.StartDate = model.StartDate;
                poolPeriod.Pool = pool;
                poolPeriod.EndDate = model.EndDate;

                _context.SaveChanges();
                _cache.Remove(AllPeriodsCacheKey);
                return Ok(poolPeriod);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Custom Error Text " + ex.Message);
                return StatusCode(500);
            }
        }




        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        [Authorize(Roles.Writer)]
        public IActionResult Delete(int id)
        {
            try
            {
                var poolPeriod = _context.PoolPeriods.Where((o) => o.Id == id).FirstOrDefault();
                if (poolPeriod == null)
                {
                    return NotFound();
                }
                var hasChild = _context.PoolPeriods.Where((pp) => pp.Parent.Id == poolPeriod.Id).FirstOrDefault();
                if (hasChild != null) {
                    return StatusCode(405);
                }
                

                _context.PoolPeriods.Remove(poolPeriod);
                _context.SaveChanges();
                _cache.Remove(AllPeriodsCacheKey);
                //_cache.Remove($"period-{id}");
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
