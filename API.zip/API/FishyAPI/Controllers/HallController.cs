﻿using FishyAPI.Models;
using FishyAPI.Models.DBModels;
using FishyAPI.Models.Requests;
using FishyAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860


namespace FishyAPI.Controllers
{


    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class HallController : ControllerBase
    {
        private const string AllHallsCacheKey = "get-all-halls-key";

        private readonly DatabaseContext _context;
        private IUserService _userService;
        private readonly IMemoryCache _cache;

        public HallController(DatabaseContext context, IUserService userService, IMemoryCache cache)
        {
            _context = context;
            _userService = userService;
            _cache = cache;
        }



        // GET: <HallController>
        [HttpGet]
        public ActionResult<IEnumerable<Hall>> Get()
        {
            try
            {
                // TODO: fiks cache ..
                //if (_cache.TryGetValue(AllHallsCacheKey, out List<Hall> cachedHalls))
                // {
                //     return Ok(cachedHalls);
                // }
                var allHalls = _context.Halls.Where((o) => !o.Deleted).Include(o => o.Pools.Where(p => !p.Deleted)).ToList();
                _cache.Set(AllHallsCacheKey, allHalls);
                return Ok(allHalls);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // GET <HallController>/5
        [HttpGet("{id}")]
        public ActionResult<Hall> Get(int id)
        {
            try
            {
                if (_cache.TryGetValue($"hall-{id}", out Hall cachedHalls))
                {
                    return Ok(cachedHalls);
                }
                var hall = _context.Halls.Where((o) => o.Id == id && !o.Deleted).Include(o => o.Pools.Where(p =>!p.Deleted)).FirstOrDefault();
                _cache.Set($"hall-{id}", hall);
                return Ok(hall);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // POST <HallController>
        [HttpPost]
        [Authorize(Roles.Writer)]
        public ActionResult<Hall> Post(HallRequest model)
        {
            try
            {
                if (_context.Halls.Any(o => o.Name == model.Name && !o.Deleted))
                {
                    return StatusCode(409, "Hall already exists"); ;
                }

                var currentUser = _userService.GetCurrentUser(HttpContext);
                if (currentUser == null)
                {
                    return StatusCode(500);
                }

                var hall = _context.Halls.Add(new Hall
                {
                    Name = model.Name,
                    Comment = model.Comment,
                    UserCreatedBy = currentUser,

                });
                _context.SaveChanges();
                _cache.Remove(AllHallsCacheKey);
                return Ok(hall.Entity);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // PUT <HallController>/5
        [HttpPut("{id}")]
        [Authorize(Roles.Writer)]
        public ActionResult<Hall> Put(int id, [FromBody] HallRequest model)
        {
            try
            {
                var hall = _context.Halls.Where((o) => o.Id == id).FirstOrDefault();
                if (hall == null)
                {
                    return NotFound();
                }

                // Unique names
                if (_context.Halls.Any(o => o.Name == model.Name && o.Id != id))
                {
                    return StatusCode(409, "Name already exists"); ;
                }

                hall.Name = model.Name;
                hall.Comment = model.Comment;
                _context.SaveChanges();
                _cache.Remove(AllHallsCacheKey);
                _cache.Remove($"hall-{id}");
                return Ok(hall);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // DELETE <HallController>/5
        [HttpDelete("{id}")]
        [Authorize(Roles.Writer)]
        public IActionResult Delete(int id)
        {
            try
            {
                var hall = _context.Halls.Where((o) => o.Id == id).FirstOrDefault();
                if (hall == null)
                {
                    return NotFound();
                }
                if (hall.Deleted)
                {
                    StatusCode(409, "hall already Deleted");
                }
                hall.Deleted = true;
                _context.SaveChanges();
                _cache.Remove(AllHallsCacheKey);
                _cache.Remove($"hall-{id}");
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
