﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FishyAPI.Models;
using FishyAPI.Services;
using FishyAPI.Models.DBModels;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FishyAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : ControllerBase
    {
        private IUserService _userService;
        private readonly DatabaseContext _context;
        private readonly IMemoryCache _cache;

        private readonly ILogger _logger;

        public AuthController(IUserService userService, DatabaseContext context, IMemoryCache cache, ILogger<AuthController> logger)
        {
            _userService = userService;
            _context = context;
            _cache = cache;
            _logger = logger;
        }

        [HttpPost("signIn")]
        public IActionResult SignIn(AuthenticateRequest model)
        {
            var response = _userService.Authenticate(model);

            if (response == null)
            {
                _logger.LogInformation($"Failed login attempt by {model.Email}");
                return BadRequest(new { message = "Username or password is incorrect" });
            }

            _logger.LogInformation($"User logged in: {model.Email}");
            return Ok(response);
        }

        [HttpPost("signUp")]
        [Authorize(Roles.Admin)]
        public IActionResult SignUp(SignUpRequest model)
        {
            var user = _userService.CreateUser(model);
            if (user != null)
            {
                _cache.Remove("get-all-users-key");
                return Ok(user);
            }
            else
            {
                return StatusCode(409, "User already exists");
            }
        }
    }
}
