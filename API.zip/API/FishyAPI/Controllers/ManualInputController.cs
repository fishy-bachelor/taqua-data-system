﻿using FishyAPI.Models;
using FishyAPI.Models.DBModels;
using FishyAPI.Models.Requests;
using FishyAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FishyAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class ManualInputController : ControllerBase
    {
        private const string AllManualInputCacheKey = "get-all-manual-input-key";

        private readonly DatabaseContext _context;
        private IUserService _userService;
        private readonly IMemoryCache _cache;


        public ManualInputController(DatabaseContext context, IUserService userService, IMemoryCache cache)
        {
            _context = context;
            _userService = userService;
            _cache = cache;
        }



        // GET: api/<ManualInputController>
        [HttpGet]
        public ActionResult<IEnumerable<ManualInput>> GetAll()
        {
            try
            {
                if (_cache.TryGetValue(AllManualInputCacheKey, out List<ManualInput> cachedPeriods))
                {
                    return Ok(cachedPeriods);
                }
                var allManualInputs = _context.ManualInputs.Include(x => x.Hall).Include(x => x.UserCreatedBy).ToList();
                _cache.Set(AllManualInputCacheKey, allManualInputs);
                return Ok(allManualInputs);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        [HttpGet("byHallId")]
        public ActionResult<IEnumerable<ManualInput>> GetAllByHallId(int hallId, DateTime startDate, DateTime endDate)
        {
            try
            {
                var allManualInputs = _context.ManualInputs.Where(x => x.Hall.Id == hallId && x.DateRecorded > startDate && x.DateRecorded < endDate).OrderBy(x => x.DateRecorded).ToList();
                return Ok(allManualInputs);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        [HttpGet("byPeriod")]
        public ActionResult<IEnumerable<ManualInput>> GetAllByPeriodAndHallId(int periodId, int hallId)
        {
            try
            {
                var period = _context.Periods.Where(p => p.Id == periodId).FirstOrDefault();
                if (period == null)
                {
                    return NotFound();
                }

                var endDate = period.EndDate;
                if (endDate == null)
                {
                    endDate = DateTime.Now;
                };

                var allManualInputs = _context.ManualInputs.Where(x => x.Hall.Id == hallId && x.DateRecorded >= period.StartDate && x.DateRecorded <= endDate).OrderBy(x => x.DateRecorded).ToList();
                return Ok(allManualInputs);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // GET api/<ManualInputController>/5
        [HttpGet("{id}")]
        public ActionResult<ManualInput> Get(int id)
        {
            try
            {
                if (_cache.TryGetValue($"manual-input-{id}", out ManualInput manualInputCached))
                {
                    return Ok(manualInputCached);
                }
                var manualInput = _context.ManualInputs.Include(x => x.Hall).Where((o) => o.Id == id).FirstOrDefault();
                _cache.Set($"period-{id}", manualInput);
                return Ok(manualInput);
            }
            catch
            {
                return StatusCode(500);
            }
        }


        // POST api/<ManualInputController>
        [HttpPost]
        [Authorize(Roles.Writer)]
        public ActionResult<ManualInput> Post(ManualInputRequest model)
        {
            try
            {
                var currentUser = _userService.GetCurrentUser(HttpContext);
                if (currentUser == null)
                {
                    return StatusCode(500);
                }

                if (model.DateRecorded == DateTime.MinValue)
                {
                    model.DateRecorded = DateTime.Now;
                }
                var hall = _context.Halls.Where((o) => o.Id == model.HallId).FirstOrDefault();
                if (hall == null)
                {
                    return NotFound("hall not found");
                }

                var manualInput = _context.ManualInputs.Add(new ManualInput
                {
                    Alkalitet = model.Alkalitet,
                    TGP = model.TGP,
                    Oxygen = model.Oxygen,
                    RES = model.RES,
                    Redox = model.Redox,
                    Ammonium = model.Ammonium,
                    Nitritt = model.Nitritt,
                    Nitrat = model.Nitrat,
                    Turbiditet = model.Turbiditet,
                    SpeedWater = model.SpeedWater,
                    Comment = model.Comment,
                    DateRecorded = model.DateRecorded,
                    UserCreatedBy = currentUser,
                    Hall = hall,
                });
                _context.SaveChanges();
                _cache.Remove(AllManualInputCacheKey);
                return Ok(manualInput.Entity);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // PUT api/<ManualInputController>/5
        [HttpPut("{id}")]
        [Authorize(Roles.Writer)]
        public ActionResult<Period> Put(int id, [FromBody] ManualInputRequest model)
        {
            try
            {
                var manualInput = _context.ManualInputs.Where((o) => o.Id == id).FirstOrDefault();
                if (manualInput == null)
                {
                    return NotFound("manualInput not found");
                }
                var hall = _context.Halls.Where((o) => o.Id == model.HallId).FirstOrDefault();
                if (hall == null)
                {
                    return NotFound("hall not found");
                }

                manualInput.Alkalitet = model.Alkalitet;
                manualInput.TGP = model.TGP;
                manualInput.Oxygen = model.Oxygen;
                manualInput.RES = model.RES;
                manualInput.Redox = model.Redox;
                manualInput.Ammonium = model.Ammonium;
                manualInput.Nitritt = model.Nitritt;
                manualInput.Nitrat = model.Nitrat;
                manualInput.Turbiditet = model.Turbiditet;
                manualInput.SpeedWater = model.SpeedWater;
                manualInput.Comment = model.Comment;
                manualInput.DateRecorded = model.DateRecorded;
                manualInput.Hall = hall;

                _context.SaveChanges();
                _cache.Remove(AllManualInputCacheKey);
                _cache.Remove($"manual-input-{id}");
                return Ok(manualInput);
            }
            catch
            {
                return StatusCode(500);
            }
        }


        // DELETE api/<ManualInputController>/5
        [HttpDelete("{id}")]
        [Authorize(Roles.Writer)]
        public IActionResult Delete(int id)
        {
            try
            {
                var manualInput = _context.ManualInputs.Where((o) => o.Id == id).FirstOrDefault();
                if (manualInput == null)
                {
                    return NotFound();
                }
                _context.ManualInputs.Remove(manualInput);
                _context.SaveChanges();
                _cache.Remove(AllManualInputCacheKey);
                _cache.Remove($"manual-input-{id}");
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
