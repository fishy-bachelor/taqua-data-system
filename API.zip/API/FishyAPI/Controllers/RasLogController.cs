using FishyAPI.Helpers;
using FishyAPI.Hubs;
using FishyAPI.Models;
using FishyAPI.Models.DBModels;
using FishyAPI.Models.Requests;
using FishyAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using System.IO;
using Microsoft.AspNetCore.NodeServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FishyAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class RasLogController : ControllerBase
    {
        private const string rasLogCacheKey = "RasLogControllerController-key";

        private readonly DatabaseContext _context;
        private IUserService _userService;
        private readonly IMemoryCache _cache;
        private readonly IHubContext<DataHub> _hubcontext;
        private readonly INodeServices _nodeServices;

        public RasLogController(DatabaseContext context, IUserService userService, IMemoryCache cache, IHubContext<DataHub> hubcontext, INodeServices nodeServices)
        {
            _context = context;
            _userService = userService;
            _cache = cache;
            _hubcontext = hubcontext;
            _nodeServices = nodeServices;
        }


        /// <summary>
        /// Retrieves average from all logs, one record every day.
        /// </summary>
        [HttpGet]
        [Authorize]
        public ActionResult<IEnumerable<RasLog>> Get()
        {
            try
            {
                return StatusCode(501, "NotImplemented");
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // GET: <FeedingSystemController>
        [HttpGet("filter")]
        [Authorize]
        public ActionResult Get(DateTime FromDate, DateTime ToDate, int HallId, int PeriodId)
        {
            try
            {
                DateTime? endDate = null;
                var fromDate = FromDate;
                var startSqlString = @"SELECT
                           DateRecorded = Min(DateRecorded),
                           {0} as HallId,
                           ChunkStart = Min(DateRecorded),
                           ChunkEnd = Max(DateRecorded)";

                var valuesString = "";
                PropertyInfo[] properties = typeof(RasLog).GetProperties();
                foreach (PropertyInfo property in properties)
                {
                    if (property.Name == "Hall" || property.Name == "DateRecorded")
                    {
                    }
                    else if (property.Name == "Id")
                    {
                        valuesString += "," + property.Name + " = Cast(AVG( Cast(" + property.Name + " as float)) as int)";
                    }
                    else
                    {
                        valuesString += "," + property.Name + " = AVG(" + property.Name + ")";
                    }
                }

                var endSqlString = @"FROM
                                           (
                                              SELECT
                                                 Chunk = NTILE(1000) OVER(ORDER BY DateRecorded),
                                                 *
                                              FROM
                                                 [dbo].[RasLogs] as Raslog
                                                Where HallId = {0} AND DateRecorded >= {1} AND DateRecorded <= {2}
                                           ) AS T

                                        GROUP BY
                                           Chunk
                                        ORDER BY
                                           ChunkStart; ";

                if (PeriodId != 0)
                {
                    var period = _context.Periods.Where(p => p.Id == PeriodId).FirstOrDefault();

                    if (period == null)
                    {
                        return NotFound();
                    }

                    endDate = period.EndDate;
                    if (endDate == null)
                    {
                        endDate = DateTime.Now;
                    }
                    fromDate = period.StartDate;



                }

                if (endDate == null)
                {
                    endDate = ToDate;
                }

                var filteredRasLogs = _context.RasLogs.FromSqlRaw(startSqlString + valuesString + endSqlString, HallId, fromDate, endDate)
                    .ToList();
                return Ok(filteredRasLogs);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return StatusCode(500);
            }
        }


        // GET: <FeedingSystemController>
        [HttpGet("filter/withcustomsqlhelper")]
        [Authorize]
        public ActionResult<IEnumerable<RasLog>> GetWithCustomHelper(DateTime FromDate, DateTime ToDate, int HallId, int PeriodId)
        {
            try
            {
                var query = @"
                SELECT
                   ChunkStart = Min(DateRecorded),
                   ChunkEnd = Max(DateRecorded),
                   smolt_ozoneinair1 = Avg(smolt_ozoneinair1)
                FROM
                   (
                      SELECT
                         Chunk = NTILE(5) OVER (ORDER BY DateRecorded),
                         *
                      FROM
                         [dbo].[RasLogs] as Raslog
                        Where HallId = @p0 AND DateRecorded >= @p1 AND DateRecorded <= @p2
                   ) AS T
                GROUP BY
                   Chunk
                ORDER BY
                   ChunkStart;
                   ";

                object[] parameters = { HallId, FromDate, ToDate };
                var result = SqlHelper.RawSqlQuery(_context, query, parameters, x => new
                {
                    ChunkStart = (DateTime)x[0],
                    ChunkEnd = (DateTime)x[1],
                    smolt_ozoneinair1 = (double)x[2]
                });

                return Ok(result);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return StatusCode(500);
            }
        }


        // GET api/<FeedingSystemController>/5
        [HttpGet("{id}")]
        [Authorize]
        public ActionResult<RasLog> Get(int id)
        {
            try
            {
                var rasLog = _context.RasLogs.Where((o) => o.Id == id).FirstOrDefault();
                return Ok(rasLog);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // POST /FeedingSystemController>
        [HttpPost]
        [Authorize(Roles.Scheduler)]
        public ActionResult Post(List<RasLogRequest> models)
        {
            try
            {
                List<RasLog> newRasLogs = new List<RasLog>();
                // TODO ta høyde for at listen kan inneholde duplikate dateRecorded??
                foreach (RasLogRequest model in models)
                {
                    // only record new logs
                    if (_context.RasLogs.Where(o => o.DateRecorded == model.DateRecorded && o.Hall.Id == model.HallId).FirstOrDefault() == null)
                    {
                        var hall = _context.Halls.Where((o) => o.Id == model.HallId).FirstOrDefault();
                        if (hall == null)
                        {
                            return NotFound("Hall was not found!");
                        }
                        var newRasLog = _context.RasLogs.Add(model);
                        newRasLog.Entity.Hall = hall;
                        newRasLogs.Add(newRasLog.Entity);
                    }
                }
                if (newRasLogs.Count() > 0)
                {
                    // TODO: needs auth
                    this._hubcontext.Clients.All.SendAsync("ReceiveRasLogs", newRasLogs);
                }
                _context.SaveChanges();
                _cache.Remove(rasLogCacheKey);
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // POST /RasLogController/processLogfile>
        [HttpPost("processLogfile")]
        [Authorize(Roles.Writer)]
        public async Task<ActionResult<int>> PostFormDataAsync(List<IFormFile> files)
        {
            try
            {
                var totalAdded = 0;
                foreach (var file in files)
                {
                    if(!file.FileName.Contains("Tagsname") && !file.FileName.Contains("String"))
                    {
                        var filePath = Path.GetTempFileName();
                        using (var stream = System.IO.File.Create(filePath))
                        {
                            await file.CopyToAsync(stream);
                        }
                        var result = await _nodeServices.InvokeAsync<List<RasLogRequest>>("wwwroot/NodeScripts/RasLogProcessor.js", filePath);
                        Post(result);
                        totalAdded += result.Count();
                        System.IO.File.Delete(filePath);
                    }
                }
                return Ok(totalAdded);
            }catch (Exception e)
            {
                return StatusCode(500, e.ToString());
            }

        }
    }
}
