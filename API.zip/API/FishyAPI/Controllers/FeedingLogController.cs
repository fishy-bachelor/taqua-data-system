using FishyAPI.Hubs;
using FishyAPI.Helpers;
using FishyAPI.Models;
using FishyAPI.Models.DBModels;
using FishyAPI.Models.Requests;
using FishyAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FishyAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class FeedingLogController : ControllerBase
    {

        private const string feedingLogCacheKey = "FeedingSystemController-key";

        private readonly DatabaseContext _context;
        private IUserService _userService;
        private readonly IMemoryCache _cache;
        private readonly IHubContext<DataHub> _hubcontext;


        public FeedingLogController(DatabaseContext context, IUserService userService, IMemoryCache cache, IHubContext<DataHub> hubcontext)
        {
            _context = context;
            _userService = userService;
            _cache = cache;
            _cache = cache;
            _hubcontext = hubcontext;
        }



        // GET: <FeedingSystemController>
        [HttpGet]
        [Authorize]
        public ActionResult<IEnumerable<FeedingLog>> Get()
        {
            try
            {
                if (_cache.TryGetValue(feedingLogCacheKey, out List<Hall> cachedFeedingLogs))
                {
                    return Ok(cachedFeedingLogs);
                }
                var allFeedingLogs = _context.FeedingLogs.ToList();
                _cache.Set(feedingLogCacheKey, allFeedingLogs);
                return Ok(allFeedingLogs);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // GET: <FeedingSystemController>
        [HttpGet("filter")]
        [Authorize]
        public ActionResult<IEnumerable<FeedingLog>> Get(DateTime FromDate, DateTime ToDate, int HallId, int PeriodId)
        {
            try
            {

                DateTime? endDate = null;
                var fromDate = FromDate;

                if (PeriodId != 0)
                {
                    var period = _context.Periods.Where(p => p.Id == PeriodId).FirstOrDefault();

                    if (period == null)
                    {
                        return NotFound();
                    }

                    endDate = period.EndDate;
                    if (endDate == null)
                    {
                        endDate = DateTime.Now;
                    }
                    fromDate = period.StartDate;
                }

                if (endDate == null)
                {
                    endDate = ToDate;
                }

                var query = @" SELECT
                    DateRecorded = Min(DateRecorded),
                    ChunkStart = Min(DateRecorded),
                    ChunkEnd = Max(DateRecorded),
                    Amount = AVG([Amount])
                    FROM
                        (
                            SELECT
                                Chunk = NTILE(200) OVER(ORDER BY DateRecorded),
                                *
                            FROM
                                [dbo].[FeedingLogs]
                            Where PoolId = @p0 AND DateRecorded >= @p1 AND DateRecorded <= @p2
                        ) AS T

                    GROUP BY
                        Chunk
                    ORDER BY
                        ChunkStart; ";


                var pools = _context.Pools.Where(p => p.Hall.Id == HallId).ToList();

                var results = new List<Object>();
                foreach (Pool p in pools)
                {

                    //var filteredRasLogs = _context.FeedingLogs.FromSqlRaw(query, p.Id, fromDate, endDate)
                    //.ToList();

                    object[] parameters = { p.Id, fromDate, endDate };

                    var poolResult = SqlHelper.RawSqlQuery(_context, query, parameters, x => new
                    {
                        DateRecorded = (DateTime)x[0],
                        //ChunkStart = (DateTime)x[1],
                        //ChunkEnd = (DateTime)x[2],
                        Amount = (double)x[3],
                        Pool = new
                        {
                            Id = p.Id,
                            Name = p.Name,
                            PoolNrInHall = p.PoolNrInHall,
                        },

                    });
                    results.AddRange(poolResult);

                }
                return Ok(results);


            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return StatusCode(500);
            }
        }

        // GET api/<FeedingSystemController>/5
        [HttpGet("{id}")]
        [Authorize]
        public ActionResult<FeedingLog> Get(int id)
        {
            try
            {
                var feedingLog = _context.FeedingLogs.Where((o) => o.Id == id).FirstOrDefault();
                return Ok(feedingLog);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // POST /FeedingSystemController>
        [HttpPost]
        [Authorize(Roles.Scheduler)]
        public ActionResult Post(List<FeedingLogRequest> models)
        {
            try
            {
                List<FeedingLog> newFeedingLogs = new List<FeedingLog>();
                foreach (FeedingLogRequest model in models)
                {
                    // only record new logs
                    // TODO: ny og bedre sjekk her!
                    if (!_context.FeedingLogs.Any(o => o.DateRecorded == model.DateRecorded && o.Pool.Id == model.PoolId))
                    {
                        var pool = _context.Pools.Where((o) => o.Id == model.PoolId).FirstOrDefault();
                        if (pool == null)
                        {
                            // TODO: gjøre noe her?
                        }
                        var newFeedingLog = _context.FeedingLogs.Add(model);
                        newFeedingLog.Entity.Pool = pool;
                        newFeedingLogs.Add(newFeedingLog.Entity);
                    }
                }
                if (newFeedingLogs.Count() > 0)
                {
                    // TODO: needs auth
                    this._hubcontext.Clients.All.SendAsync("ReceiveFeedingLogs", newFeedingLogs);
                }
                _context.SaveChanges();
                _cache.Remove(feedingLogCacheKey);
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
