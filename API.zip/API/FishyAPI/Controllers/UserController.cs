﻿using System.Collections.Generic;
using System.Linq;
using FishyAPI.Models;
using Microsoft.AspNetCore.Mvc;
using FishyAPI.Services;
using FishyAPI.Models.DBModels;
using Microsoft.Extensions.Caching.Memory;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FishyAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private const string AllUsersCacheKey = "get-all-users-key";

        private readonly DatabaseContext _context;
        private IUserService _userService;
        private readonly IMemoryCache _cache;

        public UserController(DatabaseContext context, IUserService userService, IMemoryCache cache)
        {
            _context = context;
            _userService = userService;
            _cache = cache;
        }

        [Authorize(Roles.Admin)]
        [HttpGet("listUsers")]
        public IActionResult GetAll()
        {
            try
            {
                if (_cache.TryGetValue(AllUsersCacheKey, out IEnumerable<User> chachedUsers))
                {
                    return Ok(chachedUsers);
                }
                var users = _userService.GetAll();
                _cache.Set(AllUsersCacheKey, users);
                return Ok(users);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        [Authorize(Roles.Admin)]
        [HttpPatch("changeUserRole")]
        public IActionResult ChangeUserRole(ChangeUserRoleRequest model)
        {
            try
            {
                var currentUser = _userService.GetCurrentUser(HttpContext);
                _cache.Remove(AllUsersCacheKey);
                _cache.Remove($"user-{model.Id}");
                if (currentUser.Id != model.Id)
                {
                    _userService.ChangeUserRole(model);
                    return Ok();
                }
                return Unauthorized();
            }
            catch
            {
                return StatusCode(500);
            }
        }

        [Authorize]
        [HttpPatch("changeUser")]
        public IActionResult ChangeUser(ChangeUserRequest model)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    if (!string.IsNullOrEmpty(model.Email))
                    {
                        if (_context.Users.Any(o => o.Email == model.Email)) return StatusCode(409, "User already exists"); ;

                    }

                    var currentUser = _userService.GetCurrentUser(HttpContext);
                    

                        if (currentUser.Id == model.Id || currentUser.Role == Roles.Admin)
                        {

                            _cache.Remove(AllUsersCacheKey);
                            _cache.Remove($"user-{model.Id}");
                            _userService.ChangeUser(model);
                            return Ok();
                        }
                        return Unauthorized();
                   
                }
                catch
                {
                    return StatusCode(500);
                }
            }
            return BadRequest(ModelState.ToDictionary(
              kvp => kvp.Key,
              kvp => kvp.Value.Errors.Select(e => e.ErrorMessage).ToArray()
            ));
        }

        [Authorize(Roles.Admin)]
        [HttpDelete("deleteUser")]
        public IActionResult DeleteUser(DeleteUserRequest model)
        {
            try
            {
                var currentUser = _userService.GetCurrentUser(HttpContext);
                if (currentUser.Id != model.Id)
                {
                    _cache.Remove(AllUsersCacheKey);
                    _cache.Remove($"user-{model.Id}");
                    _userService.DeleteUser(model);
                    return Ok();
                }
                return Unauthorized();
            }
            catch
            {
                return StatusCode(500);
            }
        }

        [Authorize]
        [HttpGet]
        public ActionResult<User> GetCurrentUser()
        {
            try
            {
                var userInContext = (User)HttpContext.Items["User"];
                if (userInContext == null)
                {
                    return NotFound();
                }
                if (_cache.TryGetValue($"user-{userInContext.Id}", out User chachedUsers))
                {
                    return Ok(chachedUsers);
                }
                var currentUser = _userService.GetCurrentUser(HttpContext);
                _cache.Set($"user-{currentUser.Id}", currentUser);
                return Ok(currentUser);
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
