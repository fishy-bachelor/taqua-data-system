﻿using FishyAPI.Models;
using FishyAPI.Models.DBModels;
using FishyAPI.Models.Requests;
using FishyAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FishyAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class PeriodController : ControllerBase
    {
        private const string AllPeriodsCacheKey = "get-all-periods-key";

        private readonly DatabaseContext _context;
        private IUserService _userService;
        private readonly IMemoryCache _cache;

        public PeriodController(DatabaseContext context, IUserService userService, IMemoryCache cache)
        {
            _context = context;
            _userService = userService;
            _cache = cache;
        }

        // GET: <PeriodController>
        [HttpGet]
        public ActionResult<IEnumerable<Period>> Get()
        {
            try
            {
                /* TODO; se over cache om det fjernes oover alt og
                if (_cache.TryGetValue(AllPeriodsCacheKey, out List<Period> cachedPeriods))
                {
                    return Ok(cachedPeriods);
                }*/
                var allPeriods = FilterPoolPeriods(_context.Periods.Where((o) => !o.Deleted)).ToList();
                _cache.Set(AllPeriodsCacheKey, allPeriods);
                return Ok(allPeriods);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return StatusCode(500);
            }
        }


        private IQueryable<dynamic> FilterPoolPeriods(IQueryable<Period> periods)
        {
            return periods.Select(o => new
            {
                o.Id,
                o.StartDate,
                o.EndDate,
                o.Name,
                o.Comment,
                o.Deleted,
                o.UserCreatedBy,
                PoolPeriods = o.PoolPeriods
                        .Select(o => new
                        {
                            o.Id,
                            Pool = new
                            {
                                o.Pool.Id,
                                o.Pool.Name,
                                Hall = new
                                {
                                    o.Pool.Hall.Id,
                                    o.Pool.Hall.Name
                                }

                            },
                            Period = new
                            {
                                o.Period.Id,
                                o.Period.Name,
                            },
                            Parent = new
                            {
                                Id = o.Parent == null ? 0 : o.Parent.Id,
                                Pool = new
                                {
                                    Id = o.Parent == null ? 0 : o.Parent.Id,
                                    Name = o.Parent == null ? '-'.ToString() : o.Parent.Pool.Name,
                                }
                            },
                            // fjern denne evt fix
                            Children = new List<PoolPeriod>(),
                            o.StartDate,
                            o.EndDate,
                        })
                        .ToList()
            });
        }

        // GET <PeriodController>/5
        [HttpGet("{id}")]
        public ActionResult<Period> Get(int id)
        {
            try
            {
                /*TODO; se over cache om det fjernes oover alt og
                if (_cache.TryGetValue($"period-{id}", out Period cachedPeriod))
                {
                    return Ok(cachedPeriod);
                }*/
                var period = FilterPoolPeriods(_context.Periods.Where((o) => o.Id == id && !o.Deleted)).FirstOrDefault();

                //_cache.Set($"period-{id}", period);
                return Ok(period);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // POST <PeriodController>
        [HttpPost]
        [Authorize(Roles.Writer)]
        public ActionResult<Period> Post(PeriodRequest model)
        {
            try
            {
                var currentUser = _userService.GetCurrentUser(HttpContext);
                if (currentUser == null)
                {
                    return StatusCode(500);
                }

                var poolIds = model.PoolIds;
                var pools = _context.Pools.Where((o) => poolIds.Contains(o.Id)).ToList();
                if (pools.Count != poolIds.Count || pools.Count == 0)
                {
                    return NotFound("Some pools not found");
                }

                var period = _context.Periods.Add(new Period
                {
                    Name = model.Name,
                    Comment = model.Comment,
                    UserCreatedBy = currentUser,
                    StartDate = model.StartDate,
                    EndDate = model.EndDate,
                });

                foreach (Pool pool in pools)
                {
                    _context.PoolPeriods.Add(new PoolPeriod
                    {
                        StartDate = model.StartDate,
                        Pool = pool,
                        Period = period.Entity,
                    });
                }

                _context.SaveChanges();
                _cache.Remove(AllPeriodsCacheKey);
                var periodJustSaved = FilterPoolPeriods(_context.Periods.Where((o) => o.Id == period.Entity.Id)).FirstOrDefault();
                return Ok(periodJustSaved);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return StatusCode(500);
            }
        }

        // PUT <HallController>/5
        [HttpPut("{id}")]
        [Authorize(Roles.Writer)]
        public ActionResult<Period> Put(int id, [FromBody] PeriodPutRequest model)
        {
            try
            {   // .Include(o => o.Pools) // vurder noe her mtp å endre tidslinje..
                var period = _context.Periods.Where((o) => o.Id == id).FirstOrDefault();
                if (period == null)
                {
                    return NotFound();
                }

                period.Name = model.Name;
                period.Comment = model.Comment;
                period.StartDate = model.StartDate;
                period.EndDate = model.EndDate;

                if (model.EndDate != null)
                {
                    var poolPeriods = _context.PoolPeriods.Where((o) => o.Period.Id == period.Id && o.EndDate == null).ToList();
                    foreach (PoolPeriod poolPeriod in poolPeriods)
                    {
                        poolPeriod.EndDate = model.EndDate;
                    }
                 }

                // TODO: vurdere endre startdato på root PoolPeriond for denne perioden..

                _context.SaveChanges();
                _cache.Remove(AllPeriodsCacheKey);
                _cache.Remove($"period-{id}");
                return Ok(period);
            }
            catch
            {
                return StatusCode(500);
            }
        }

        // DELETE <HallController>/5
        [HttpDelete("{id}")]
        [Authorize(Roles.Writer)]
        public IActionResult Delete(int id)
        {
            try
            {
                var period = _context.Periods.Where((o) => o.Id == id).FirstOrDefault();
                if (period == null)
                {
                    return NotFound();
                }
                if (period.Deleted)
                {
                    StatusCode(409, "hall already Deleted");
                }
                period.Deleted = true;
                _context.SaveChanges();
                _cache.Remove(AllPeriodsCacheKey);
                _cache.Remove($"period-{id}");
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
