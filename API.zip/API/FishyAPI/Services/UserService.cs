﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using FishyAPI.Models;
using FishyAPI.Helpers;
using BC = BCrypt.Net.BCrypt;
using FishyAPI.Models.DBModels;
using Microsoft.AspNetCore.Http;

namespace FishyAPI.Services
{

    public interface IUserService
    {
        AuthenticateResponse Authenticate(AuthenticateRequest model);
        User CreateUser(SignUpRequest model);

        User GetById(int id);
        IEnumerable<User> GetAll();
        void ChangeUserRole(ChangeUserRoleRequest model);
        void ChangeUser(ChangeUserRequest model);
        void DeleteUser(DeleteUserRequest model);
        public User GetCurrentUser(HttpContext context);
        public User GetCurrentUserFromContext(HttpContext context);
    }

    public class UserService : IUserService
    {
        private readonly DatabaseContext _context;

        private readonly AppSettings _appSettings;

        public UserService(IOptions<AppSettings> appSettings, DatabaseContext context)
        {
            _appSettings = appSettings.Value;
            _context = context;
        }

        public AuthenticateResponse Authenticate(AuthenticateRequest model)
        {

            // get account from database
            var user = _context.Users.SingleOrDefault(x => x.Email == model.Email);

            // check account found and verify password
            if (user == null || !BC.Verify(model.Password, user.Password))
            {
                // authentication failed
                return null;
            }

            // authentication successful so generate jwt token
            var token = generateJwtToken(user);

            return new AuthenticateResponse(user, token);
        }

        public User CreateUser(SignUpRequest model)
        {
            var existingUser = _context.Users.Where(o => o.Email == model.Email).FirstOrDefault();

            // User exists
            if (existingUser?.IsDeleted == false) return null;

            string passwordHash = BC.HashPassword(model.Password);

            // Restoring a deleted user
            if (existingUser?.IsDeleted == true) {
                existingUser.Name = model.Name;
                existingUser.Password = passwordHash;
                existingUser.Role = model.Role;
                existingUser.IsDeleted = false;
                _context.SaveChanges();
                return existingUser;
            };


            // get account from database
            var user = _context.Users.Add(new User
            {
                Name = model.Name,
                Email = model.Email,
                Password = passwordHash,
                Role = model.Role,
                IsDeleted = false,

            });
            _context.SaveChanges();

            return user.Entity;
        }


        public void ChangeUserRole(ChangeUserRoleRequest model)
        {
            var user = GetById(model.Id);
            user.Role = model.Role;

            _context.SaveChanges();
        }

        public IEnumerable<User> GetAll()
        {
            return _context.Users.Where(o=> o.IsDeleted == false).ToList();
        }

        public void ChangeUser(ChangeUserRequest model)
        {
            var user = GetById(model.Id);
            if (model.Name != "")
            {
                user.Name = model.Name;
            }
            if (!string.IsNullOrWhiteSpace(model.Email))
            {
                user.Email = model.Email;
            }
            if (!string.IsNullOrWhiteSpace(model.NewPassword))
            {
                string passwordHash = BC.HashPassword(model.NewPassword);
                user.Password = passwordHash;
            }

            _context.SaveChanges();
        }

        public void DeleteUser(DeleteUserRequest model)
        {
            var user = GetById(model.Id);
            user.IsDeleted = true;
            _context.SaveChanges();
        }

        public User GetById(int id)
        {
            return _context.Users.Where((o) => o.Id == id).FirstOrDefault();
        }


        public User GetCurrentUser(HttpContext context)
        {
            var userInContext = context.Items["User"];
            if (userInContext != null)
            {
                var userCasted = (User)userInContext;
                return userCasted;
            }
            return null;
        }

        public User GetCurrentUserFromContext(HttpContext context)
        {
            var userInContext = context.Items["User"];
            if (userInContext != null)
            {
                var userCasted = (User)userInContext;
                return userCasted;
            }
            return null;
        }


        // helper methods

        private string generateJwtToken(User user)
        {
            // generate token that is valid for 1 days
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim("id", user.Id.ToString()) }),
                Expires = DateTime.UtcNow.AddDays(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }


    }
}