﻿// Maps index to correct key
let tagsTemplate = {
  0: "plc_a_program_smolt_a_aoi_co2sensor_hai_pv",
  1: "plc_a_program_smolt_a_aoi_degaslevel_hai_pv",
  2: "plc_a_program_smolt_a_aoi_degasvacflow_hai_pv",
  3: "plc_a_program_smolt_a_aoi_degasvaclevel_hai_pv",
  4: "plc_a_program_smolt_a_aoi_filterlevelafter_hai_pv",
  5: "plc_a_program_smolt_a_aoi_filterlevelbefore_hai_pv",
  6: "plc_a_program_smolt_a_aoi_flowfresh_hai_pv",
  7: "plc_a_program_smolt_a_aoi_flowsea_hai_pv",
  8: "plc_a_program_smolt_a_aoi_flowsensorout_hai_pv",
  9: "plc_a_program_smolt_a_aoi_heatpumpcondctrl_hai_pv",
  10: "plc_a_program_smolt_a_aoi_ozoneinair1_hai_pv",
  11: "plc_a_program_smolt_a_aoi_ozoneinair2_hai_pv",
  12: "plc_a_program_smolt_a_aoi_ozoneinair3_hai_pv",
  13: "plc_a_program_smolt_a_aoi_ozoneinjpump1_current_hai_pv",
  14: "plc_a_program_smolt_a_aoi_ozoneinjpump2_current_hai_pv",
  15: "plc_a_program_smolt_a_aoi_ozoneinwater1_hai_pv",
  16: "plc_a_program_smolt_a_aoi_ozoneinwater2_hai_pv",
  17: "plc_a_program_smolt_a_aoi_ozonepress1_hai_pv",
  18: "plc_a_program_smolt_a_aoi_ozonepress2_hai_pv",
  19: "plc_a_program_smolt_a_aoi_phousphsensor_hai_pv",
  20: "plc_a_program_smolt_a_aoi_presssensor_hai_pv",
  21: "plc_a_program_smolt_a_aoi_salinitybackup_hai_pv",
  22: "plc_a_program_smolt_a_aoi_salinityctrl_hai_pv",
  23: "plc_a_program_smolt_a_aoi_systemphbup_hai_pv",
  24: "plc_a_program_smolt_a_aoi_systemphctrl_hai_pv",
  25: "plc_a_program_smolt_a_aoi_temperaturebackup_hai_pv",
  26: "plc_a_program_smolt_a_aoi_temperaturectrl_hai_pv",
  27: "plc_a_program_smolt_a_t01_aoi_level_hai_pv",
  28: "plc_a_program_smolt_a_t02_aoi_level_hai_pv",
  29: "plc_a_program_smolt_a_t02_aoi_oxygen1_hai_pv",
  30: "plc_a_program_smolt_a_t02_aoi_oxygen2_hai_pv",
  31: "plc_a_program_smolt_a_t02_aoi_oxygen3_hai_pv",
  32: "plc_a_program_smolt_a_t02_aoi_oxygen4_hai_pv",
  33: "plc_a_program_smolt_a_t02_aoi_oxygen5_hai_pv",
  34: "plc_a_program_smolt_a_t03_aoi_oxygen1_hai_pv",
  35: "plc_a_program_smolt_a_t03_aoi_oxygen2_hai_pv",
  36: "plc_a_program_smolt_a_t03_aoi_level_hai_pv",
  37: "plc_a_program_smolt_a_t03_aoi_oxygen3_hai_pv",
  38: "plc_a_program_smolt_a_t03_aoi_oxygen4_hai_pv",
  39: "plc_a_program_smolt_a_t03_aoi_oxygen5_hai_pv",
  40: "plc_a_program_smolt_a_t04_aoi_oxygen1_hai_pv",
  41: "plc_a_program_smolt_a_t04_aoi_oxygen2_hai_pv",
  42: "plc_a_program_smolt_a_t04_aoi_oxygen3_hai_pv",
  43: "plc_a_program_smolt_a_t04_aoi_oxygen4_hai_pv",
  44: "plc_a_program_smolt_a_t04_aoi_oxygen5_hai_pv",
  45: "plc_a_program_smolt_a_t04_aoi_level_hai_pv",
  46: "plc_a_program_smolt_a_t01_aoi_oxygen1_hai_pv",
  47: "plc_a_program_smolt_a_t01_aoi_oxygen2_hai_pv",
  48: "plc_a_program_smolt_a_t01_aoi_oxygen3_hai_pv",
  49: "plc_a_program_smolt_a_t01_aoi_oxygen4_hai_pv",
  50: "plc_a_program_smolt_a_t01_aoi_oxygen5_hai_pv",
  51: "plc_c_program_ld_aoi_ld_ai_mixer_lt01_hai_pv",
  52: "plc_c_program_ld_aoi_ld_ai_mixer_wt01_hai_pv",
  53: "plc_c_program_ld_aoi_ld_ai_supply_ft01_hai_pv",
  54: "plc_c_program_ld_aoi_ld_ai_supply_pt01_hai_pv",
  55: "plc_b_program_smolt_b_aoi_co2sensor_hai_pv",
  56: "plc_b_program_smolt_b_aoi_degaslevel_hai_pv",
  57: "plc_b_program_smolt_b_aoi_degasvacflow_hai_pv",
  58: "plc_b_program_smolt_b_aoi_degasvaclevel_hai_pv",
  59: "plc_b_program_smolt_b_aoi_filterlevelafter_hai_pv",
  60: "plc_b_program_smolt_b_aoi_filterlevelbefore_hai_pv",
  61: "plc_b_program_smolt_b_aoi_flowfresh_hai_pv",
  62: "plc_b_program_smolt_b_aoi_flowsea_hai_pv",
  63: "plc_b_program_smolt_b_aoi_flowsensorout_hai_pv",
  64: "plc_b_program_smolt_b_aoi_heatpumpcondctrl_hai_pv",
  65: "plc_b_program_smolt_b_aoi_ozoneinair1_hai_pv",
  66: "plc_b_program_smolt_b_aoi_ozoneinair2_hai_pv",
  67: "plc_b_program_smolt_b_aoi_ozoneinair3_hai_pv",
  68: "plc_b_program_smolt_b_aoi_ozoneinjpump1_current_hai_pv",
  69: "plc_b_program_smolt_b_aoi_ozoneinjpump2_current_hai_pv",
  70: "plc_b_program_smolt_b_aoi_ozoneinwater1_hai_pv",
  71: "plc_b_program_smolt_b_aoi_ozoneinwater2_hai_pv",
  72: "plc_b_program_smolt_b_aoi_ozonepress1_hai_pv",
  73: "plc_b_program_smolt_b_aoi_ozonepress2_hai_pv",
  74: "plc_b_program_smolt_b_aoi_phousphsensor_hai_pv",
  75: "plc_b_program_smolt_b_aoi_presssensor_hai_pv",
  76: "plc_b_program_smolt_b_aoi_salinitybackup_hai_pv",
  77: "plc_b_program_smolt_b_aoi_salinityctrl_hai_pv",
  78: "plc_b_program_smolt_b_aoi_systemphbup_hai_pv",
  79: "plc_b_program_smolt_b_aoi_systemphctrl_hai_pv",
  80: "plc_b_program_smolt_b_aoi_temperaturebackup_hai_pv",
  81: "plc_b_program_smolt_b_aoi_temperaturectrl_hai_pv",
  82: "plc_b_program_smolt_b_t01_aoi_level_hai_pv",
  83: "plc_b_program_smolt_b_t02_aoi_level_hai_pv",
  84: "plc_b_program_smolt_b_t02_aoi_oxygen1_hai_pv",
  85: "plc_b_program_smolt_b_t02_aoi_oxygen2_hai_pv",
  86: "plc_b_program_smolt_b_t02_aoi_oxygen3_hai_pv",
  87: "plc_b_program_smolt_b_t02_aoi_oxygen4_hai_pv",
  88: "plc_b_program_smolt_b_t02_aoi_oxygen5_hai_pv",
  89: "plc_b_program_smolt_b_t03_aoi_oxygen1_hai_pv",
  90: "plc_b_program_smolt_b_t03_aoi_oxygen2_hai_pv",
  91: "plc_b_program_smolt_b_t03_aoi_level_hai_pv",
  92: "plc_b_program_smolt_b_t03_aoi_oxygen3_hai_pv",
  93: "plc_b_program_smolt_b_t03_aoi_oxygen4_hai_pv",
  94: "plc_b_program_smolt_b_t03_aoi_oxygen5_hai_pv",
  95: "plc_b_program_smolt_b_t04_aoi_oxygen1_hai_pv",
  96: "plc_b_program_smolt_b_t04_aoi_oxygen2_hai_pv",
  97: "plc_b_program_smolt_b_t04_aoi_oxygen3_hai_pv",
  98: "plc_b_program_smolt_b_t04_aoi_oxygen4_hai_pv",
  99: "plc_b_program_smolt_b_t04_aoi_oxygen5_hai_pv",
  100: "plc_b_program_smolt_b_t04_aoi_level_hai_pv",
  101: "plc_b_program_smolt_b_t01_aoi_oxygen1_hai_pv",
  102: "plc_b_program_smolt_b_t01_aoi_oxygen2_hai_pv",
  103: "plc_b_program_smolt_b_t01_aoi_oxygen3_hai_pv",
  104: "plc_b_program_smolt_b_t01_aoi_oxygen4_hai_pv",
  105: "plc_b_program_smolt_b_t01_aoi_oxygen5_hai_pv",
  106: "plc_a_program_mainprogram_aoi_pm500_current_l1_hai_pv",
  107: "plc_a_program_mainprogram_aoi_pm500_current_l2_hai_pv",
  108: "plc_a_program_mainprogram_aoi_pm500_current_l3_hai_pv",
  109: "plc_a_program_mainprogram_aoi_pm500_pf_l1_hai_pv",
  110: "plc_a_program_mainprogram_aoi_pm500_pf_l2_hai_pv",
  111: "plc_a_program_mainprogram_aoi_pm500_pf_l3_hai_pv",
  112: "plc_a_program_mainprogram_aoi_pm500_pf_total_hai_pv",
  113: "plc_a_program_mainprogram_aoi_pm500_sa2_current_l1_hai_pv",
  114: "plc_a_program_mainprogram_aoi_pm500_sa2_current_l2_hai_pv",
  115: "plc_a_program_mainprogram_aoi_pm500_sa2_current_l3_hai_pv",
  116: "plc_a_program_mainprogram_aoi_pm500_sa2_pf_l1_hai_pv",
  117: "plc_a_program_mainprogram_aoi_pm500_sa2_pf_l2_hai_pv",
  118: "plc_a_program_mainprogram_aoi_pm500_sa2_pf_l3_hai_pv",
  119: "plc_a_program_mainprogram_aoi_pm500_sa2_pf_total_hai_pv",
  120: "plc_a_program_mainprogram_aoi_pm500_sa2_voltage_l1_l2_hai_pv",
  121: "plc_a_program_mainprogram_aoi_pm500_sa2_voltage_l1_l3_hai_pv",
  122: "plc_a_program_mainprogram_aoi_pm500_sa2_voltage_l1_n_hai_pv",
  123: "plc_a_program_mainprogram_aoi_pm500_sa2_voltage_l2_l3_hai_pv",
  124: "plc_a_program_mainprogram_aoi_pm500_sa2_voltage_l2_n_hai_pv",
  125: "plc_a_program_mainprogram_aoi_pm500_sa2_voltage_l3_n_hai_pv",
  126: "plc_a_program_mainprogram_aoi_pm500_voltage_l1_l2_hai_pv",
  127: "plc_a_program_mainprogram_aoi_pm500_voltage_l1_l3_hai_pv",
  128: "plc_a_program_mainprogram_aoi_pm500_voltage_l1_n_hai_pv",
  129: "plc_a_program_mainprogram_aoi_pm500_voltage_l2_l3_hai_pv",
  130: "plc_a_program_mainprogram_aoi_pm500_voltage_l2_n_hai_pv",
  131: "plc_a_program_mainprogram_aoi_pm500_voltage_l3_n_hai_pv",
  132: "plc_b_program_mainprogram_aoi_pm500_current_l1_hai_pv",
  133: "plc_b_program_mainprogram_aoi_pm500_current_l2_hai_pv",
  134: "plc_b_program_mainprogram_aoi_pm500_current_l3_hai_pv",
  135: "plc_b_program_mainprogram_aoi_pm500_pf_l1_hai_pv",
  136: "plc_b_program_mainprogram_aoi_pm500_pf_l2_hai_pv",
  137: "plc_b_program_mainprogram_aoi_pm500_pf_l3_hai_pv",
  138: "plc_b_program_mainprogram_aoi_pm500_pf_total_hai_pv",
  139: "plc_b_program_mainprogram_aoi_pm500_sb2_current_l1_hai_pv",
  140: "plc_b_program_mainprogram_aoi_pm500_sb2_current_l2_hai_pv",
  141: "plc_b_program_mainprogram_aoi_pm500_sb2_current_l3_hai_pv",
  142: "plc_b_program_mainprogram_aoi_pm500_sb2_pf_l1_hai_pv",
  143: "plc_b_program_mainprogram_aoi_pm500_sb2_pf_l2_hai_pv",
  144: "plc_b_program_mainprogram_aoi_pm500_sb2_pf_l3_hai_pv",
  145: "plc_b_program_mainprogram_aoi_pm500_sb2_pf_total_hai_pv",
  146: "plc_b_program_mainprogram_aoi_pm500_sb2_voltage_l1_l2_hai_pv",
  147: "plc_b_program_mainprogram_aoi_pm500_sb2_voltage_l1_l3_hai_pv",
  148: "plc_b_program_mainprogram_aoi_pm500_sb2_voltage_l1_n_hai_pv",
  149: "plc_b_program_mainprogram_aoi_pm500_sb2_voltage_l2_l3_hai_pv",
  150: "plc_b_program_mainprogram_aoi_pm500_sb2_voltage_l2_n_hai_pv",
  151: "plc_b_program_mainprogram_aoi_pm500_sb2_voltage_l3_n_hai_pv",
  152: "plc_b_program_mainprogram_aoi_pm500_voltage_l1_l2_hai_pv",
  153: "plc_b_program_mainprogram_aoi_pm500_voltage_l1_l3_hai_pv",
  154: "plc_b_program_mainprogram_aoi_pm500_voltage_l1_n_hai_pv",
  155: "plc_b_program_mainprogram_aoi_pm500_voltage_l2_l3_hai_pv",
  156: "plc_b_program_mainprogram_aoi_pm500_voltage_l2_n_hai_pv",
  157: "plc_b_program_mainprogram_aoi_pm500_voltage_l3_n_hai_pv",
  158: "plc_c_program_ld_aoi_ld_ai_silo_lt01_hai_pv",
  159: "plc_a_program_smolt_a_aoi_systemphctrl2_hai_pv",
  160: "plc_b_program_smolt_b_aoi_systemphctrl2_hai_pv",
  161: "plc_b_program_smolt_b_aoi_temperatureheatingsystem_hai_pv",
  162: "plc_b_program_smolt_b_aoi_flowheatingsystem_hai_pv",
  163: "plc_a_program_smolt_a_aoi_flowheatingsystem_hai_pv",
  164: "plc_a_program_smolt_a_aoi_temperatureheatingsystem_hai_pv",
  165: "plc_a_program_smolt_a_aoi_temperatureseawater_hai_pv",
  166: "plc_b_program_smolt_b_aoi_temperatureseawater_hai_pv",
  167: "plc_c_program_oxygen_aoi_oxy_supply_pt01_hai_pv",
  168: "plc_c_program_oxygen_aoi_oxy_supply_pt02_hai_pv",
  169: "plc_c_program_oxygen_aoi_oxy_supply_wt01_hai_pv",
  170: "plc_c_program_oxygen_aoi_oxy_supply_wt02_hai_pv",
  171: "plc_c_program_oxygen_udt_chart_oxy_supply_wt01_hai_pv",
  172: "plc_c_program_oxygen_udt_chart_oxy_supply_wt02_hai_pv",
  173: "plc_c_program_oxygen_udt_chart_oxy_supply_total_hai_pv",
};

const hallsMap = {
  plc_a: 1,
  plc_b: 2,
};

var fs = require("fs");
var Parser = require("@episage/dbf-parser");
const hex = require("ascii-hex");

String.prototype.splice = function (idx, rem, str) {
  return this.slice(0, idx) + str + this.slice(idx + Math.abs(rem));
};

module.exports = function (callback, filePath) {
  console.log(`Processing file ${filePath}`);

  var parser = Parser(fs.createReadStream(filePath), "binary");

  let numberOfRecords;
  parser.on("header", (h) => {
    numberOfRecords = h.numberOfRecords;
  });

  parser.on("record", (record) => {
    var i = record.Value.length;
    hexastring = "";
    while (i--) {
      const char = record.Value[i];
      const hexRep = hex(char);
      hexastring += hexRep.toString(16);
    }

    while (hexastring.length < 16) {
      hexastring = hexastring + "0";
    }

    const value = Buffer(hexastring, "hex").readDoubleBE(0);

    record.Value = value;

    WriteToFile(record);
  });

  parser.on("error", (error) => {
    console.log(error);
  });

  let res = {};
  let totalNumLines = 0;
  async function WriteToFile(record) {
    try {
      const dateString = `${record.Date}T${record.Time}`;
      const dateRecordedString = dateString.splice(4, 0, "-").splice(7, 0, "-");
      const dateRecorded = new Date(dateRecordedString);

      let tagKey = tagsTemplate[record.TagIndex];

      let currentPlc;
      Object.keys(hallsMap).forEach((key) => {
        if (tagKey.includes(key)) {
          currentPlc = key;
        }
      });

      tagKey = tagKey
        .replace("plc_a_program_", "")
        .replace("plc_b_program_", "")
        .replace("plc_c_program_", "")
        .replace("_hai_pv", "")
        .replace("_a_", "_")
        .replace("_b_", "_")
        .replace("_aoi_", "_");

      if (currentPlc) {
        const dateStringHall = dateString + currentPlc;

        if (!res[dateStringHall]) {
          res[dateStringHall] = {
            dateRecorded,
            hallId: hallsMap[currentPlc],
          };
        }
        res[dateStringHall][tagKey] = Number(record.Value);
      } else {
        Object.keys(hallsMap).forEach((key) => {
          const dateStringHall = dateString + key;

          if (!res[dateStringHall]) {
            res[dateStringHall] = {
              dateRecorded,
              hallId: hallsMap[key],
            };
          }

          res[dateStringHall][tagKey] = record.Value;
        });
      }
    } catch (err) {
      console.log("------- ERROR OCCURED --------");
      console.log(err);
    }

    totalNumLines++;

    if (numberOfRecords == totalNumLines) {
      // Make the huge object to a list
      let test = Object.entries(res);
      let test2 = test.map((e) => e[1]);
      callback(null, test2);
    }
  }
};
