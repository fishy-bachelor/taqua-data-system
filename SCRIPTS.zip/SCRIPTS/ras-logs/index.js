var fs = require("fs");
var readline = require("readline");
var Parser = require("@episage/dbf-parser");
const hex = require("ascii-hex");
const fetch = require("node-fetch");

String.prototype.splice = function (idx, rem, str) {
  return this.slice(0, idx) + str + this.slice(idx + Math.abs(rem));
};

const tagsTemplate = {};
const NUMINDEXES = 167;
const hallsMap = {
  plc_a: 1,
  plc_b: 2,
};
const plcKeys = Object.keys(hallsMap);

var files = fs
  .readdirSync(__dirname + "/data/input")
  .filter((file) => file.includes("Float"));
var fileIndex = 0;

function readTags() {
  var lineReader = readline.createInterface({
    input: fs.createReadStream(__dirname + "/data/tagname.csv"),
  });

  lineReader.on("line", (line) => {
    let [name, index] = line.split(",");
    if (name.includes("PROGRAM")) {
      tagsTemplate[index] = name
        .slice(2, name.length)
        .replace("[", "")
        .replace("]", "_")
        .replace(":", "_")
        .replace(".", "_")
        .replace(".", "_")
        .toLowerCase();
    }

    if (NUMINDEXES == Object.keys(tagsTemplate).length) {
      readValues();
    }
  });
}
readTags();

// Reading all values in one file and saving as CSV
function readValues() {
  console.log(`Processing file ${fileIndex + 1} of ${files.length}`);

  const file = files[fileIndex];
  var parser = Parser(
    fs.createReadStream(__dirname + `/data/input/${file}`),
    "binary"
  );

  let numberOfRecords;
  parser.on("header", (h) => {
    numberOfRecords = h.numberOfRecords;
  });

  parser.on("record", (record) => {
    var i = record.Value.length;
    hexastring = "";
    while (i--) {
      const char = record.Value[i];
      const hexRep = hex(char);
      hexastring += hexRep.toString(16);
    }

    while (hexastring.length < 16) {
      hexastring = hexastring + "0";
    }

    const value = Buffer(hexastring, "hex").readDoubleBE(0);

    record.Value = value;

    WriteToFile(record);
  });

  parser.on("error", (error) => {
    console.log(error);
  });

  let res = {};
  let totalNumLines = 0;
  async function WriteToFile(record) {
    try {
      const dateString = `${record.Date}T${record.Time}`;
      const dateRecordedString = dateString.splice(4, 0, "-").splice(7, 0, "-");
      const dateRecorded = new Date(dateRecordedString);

      let tagKey = tagsTemplate[record.TagIndex];

      let currentPlc;
      Object.keys(hallsMap).forEach((key) => {
        if (tagKey.includes(key)) {
          currentPlc = key;
        }
      });

      tagKey = tagKey
        .replace("plc_a_program_", "")
        .replace("plc_b_program_", "")
        .replace("plc_c_program_", "")
        .replace("_hai_pv", "")
        .replace("_a_", "_")
        .replace("_b_", "_")
        .replace("_aoi_", "_");

      if (currentPlc) {
        const dateStringHall = dateString + currentPlc;

        if (!res[dateStringHall]) {
          res[dateStringHall] = {
            dateRecorded,
            hallId: hallsMap[currentPlc],
          };
        }
        res[dateStringHall][tagKey] = Number(record.Value);
      } else {
        Object.keys(hallsMap).forEach((key) => {
          const dateStringHall = dateString + key;

          if (!res[dateStringHall]) {
            res[dateStringHall] = {
              dateRecorded,
              hallId: hallsMap[key],
            };
          }

          res[dateStringHall][tagKey] = record.Value;
        });
      }
    } catch (err) {
      console.log("------- ERROR OCCURED --------");
      console.log(err);
      console.log(record);
    }

    totalNumLines++;

    if (numberOfRecords == totalNumLines) {
      // Make the huge object to a list

      let test = Object.entries(res);
      let test2 = test.map((e) => e[1]);

      await pushToAPi(test2);

      fs.writeFileSync(
        __dirname +
          `/data/output/${file.replace(".DAT", ".json").split(" ").join("")}`,
        JSON.stringify(test2),
        (err) => {
          console.log(err);
        }
      );

      if (fileIndex < files.length) {
        fileIndex += 1;
        readValues();
      } else {
        console.log("Completed!");
      }
    }
  }

  let pushToAPi = async (payload) => {
    let localUrl = "http://localhost:5000/RasLog";
    let LocalapiKey = "JWT-token here";

    // let devUrl = "XXX;
    // let apiKey =
    //   "JWT-token here";

    console.log("POST");
    console.time("POST");
    try {
      const result = await fetch(localUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: LocalapiKey,
        },
        body: JSON.stringify(payload),
      });
      console.timeEnd("POST");
      console.log(result.status);
    } catch (error) {
      console.log(error);
    }
  };
}
