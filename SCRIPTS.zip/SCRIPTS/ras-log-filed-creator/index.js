// Example object
//  {
//     key: 'ph',
//     text: 'ph',
//     unit: 'ph',
//     type: 'line',
//     color: '#029390',
//     source: 'RAS'
//   }

const fs = require("fs");
const path = require("path");
var randomColor = require("randomcolor");

let rawdata = fs.readFileSync(path.resolve(__dirname, "object.json"));
let object = JSON.parse(rawdata);
let keys = Object.keys(object);

const fields = [];

for (let key of keys) {
  fields.push({
    key: key,
    text: key,
    unit: "ras",
    type: "line",
    color: randomColor({ luminosity: "dark" }),
    source: "RAS",
  });
}

fs.writeFileSync(__dirname + "/output.json", JSON.stringify(fields));
