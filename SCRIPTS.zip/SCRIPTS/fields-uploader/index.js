const fs = require("fs");
const path = require("path");
const fetch = require("node-fetch");

let rawdata = fs.readFileSync(path.resolve(__dirname, "fields.json"));
let keys = JSON.parse(rawdata);

async function upload(key) {
  if (key.source == "manual") {
    key.source = 0;
  } else if (key.source == "feeding") {
    key.source = 1;
  } else {
    key.source = 2;
  }

  key.name = key.text;
  key.deleted = false;

  // REMAP FIELDS
  try {
    const result = await fetch("http://localhost:5000/dataKey", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: "<JWT-TOKEN here>",
      },
      body: JSON.stringify(key),
    });

    console.log(result.status);
  } catch (e) {
    console.log(e);
  }
}

console.log(keys.length);
for (key of keys) {
  upload(key);
}
