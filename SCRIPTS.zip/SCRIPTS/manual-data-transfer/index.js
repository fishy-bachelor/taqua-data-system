const Fs = require("fs");
const CsvReadableStream = require("csv-reader");
const fetch = require("node-fetch");

let inputStream = Fs.createReadStream("hall2-cleaned.csv", "utf8");

inputStream
  .pipe(
    new CsvReadableStream({
      parseNumbers: true,
      parseBooleans: true,
      trim: true,
    })
  )
  .on("data", async function (row) {
    try {
      if (!row[0].includes("Dato")) {
        const data = row.join(",").split(";");
        const [
          date,
          time,
          sign,
          temp,
          phChannel,
          phSensor,
          tgp,
          oxygen,
          res,
          co2,
          salinitet,
          ledningsEvne,
          redox,
          ammonium,
          ammoniak,
          nitritt,
          nitrat,
          alkalitet,
          alkalitet2,
          turbidited,
          speedvannm3,
          speedvann2,
          speedvann3,
          speedvannm5,
          speedvannm6,
          utforing,
          utforing2,
        ] = data;

        const [day, month, year] = date.split("/");
        const datetime = `20${year}-${month < 10 ? "0" + month : month}-${
          day < 10 ? "0" + day : day
        }T10:00`;

        console.log(
          JSON.stringify({
            dateRecorded: new Date(datetime).toISOString(),
            tgp: parseFloat(tgp.replace(",", ".")),
            oxygen: parseFloat(oxygen.replace(",", ".")),
            res: parseFloat(res.replace(",", ".")),
            redox: parseFloat(redox.replace(",", ".")),
            ammonium: parseFloat(ammonium.replace(",", ".")),
            nitritt: parseFloat(nitritt.replace(",", ".")),
            nitrat: parseFloat(nitrat.replace(",", ".")),
            alkalitet: parseInt(alkalitet.replace(",", ".")),
            turbiditet: parseFloat(turbidited.replace(",", ".")),
            speedWater: parseFloat(speedvannm3.replace(",", ".")),
            comment: "",
            hallId: 2,
          })
        );

        try {
          const result = await fetch("https://localhost:5000/ManualInput", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: "<JWT-token here>",
            },
            body: JSON.stringify({
              dateRecorded: new Date(datetime).toISOString(),
              tgp: parseFloat(tgp.replace(",", ".")),
              oxygen: parseFloat(oxygen.replace(",", ".")),
              res: parseFloat(res.replace(",", ".")),
              redox: parseFloat(redox.replace(",", ".")),
              ammonium: parseFloat(ammonium.replace(",", ".")),
              nitritt: parseFloat(nitritt.replace(",", ".")),
              nitrat: parseFloat(nitrat.replace(",", ".")),
              alkalitet: parseInt(alkalitet.replace(",", ".")),
              turbiditet: parseFloat(turbidited.replace(",", ".")),
              speedWater: parseFloat(speedvannm3.replace(",", ".")),
              comment: "",
              hallId: 1,
            }),
          });
          console.log(result);
        } catch (error) {
          console.log(error.message);
        }
      }
    } catch (error) {
      console.log(error.message);
    }
  });
