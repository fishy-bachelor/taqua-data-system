﻿using System;
namespace Scheduler.Models
{
    public class Hall
    {

        public int Id { get; set; }

        public string Name { get; set; }

        public string Comment { get; set; }

        public bool Deleted { get; set; }

        //public virtual ICollection<Pool> Pools { get; set; }
    }
}
