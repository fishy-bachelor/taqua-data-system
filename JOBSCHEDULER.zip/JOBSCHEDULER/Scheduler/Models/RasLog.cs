﻿using System;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Scheduler.Models
{
    public class RasLogs
    {
       public List<RasLog> logs { get; set; }
    }

    public class RasLog
    {
        [JsonProperty("dateRecorded")]
        public DateTime DateRecorded { get; set; }
        [JsonProperty("ph")]
        public double Ph { get; set; }
        [JsonProperty("temperature")]
        public double Temperature { get; set; }
        [JsonProperty("hallId")]
        public int Hall { get; set; }
    }
}
