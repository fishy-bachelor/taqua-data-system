﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Scheduler.Models
{
    public class FeedingLogs
    {
        public List<FeedingLog> logs { get; set; }
    }

    public class FeedingLog
    {
        [JsonProperty("dateRecorded")]
        public DateTime DateRecorded { get; set; }
        [JsonProperty("poolId")]
        public int Pool { get; set; }
        [JsonProperty("amount")]
        public double Amount { get; set; }
        [JsonProperty("type")]
        public int Type { get; set; }
        [JsonProperty("toEquipment")]
        public string ToEquipment { get; set; }
        [JsonProperty("materialName")]
        public string MaterialName { get; set; }

    }
}
