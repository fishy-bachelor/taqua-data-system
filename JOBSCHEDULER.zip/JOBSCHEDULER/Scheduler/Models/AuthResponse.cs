﻿using System;
using Newtonsoft.Json;

namespace Scheduler.Models
{
    public class AuthResponse
    {
        [JsonProperty("id")]
        public int Id { get; set; }
        [JsonProperty("email")]
        public string Email { get; set; }
        [JsonProperty("token")]
        public string Token { get; set; }
        [JsonProperty("role")]
        public int Role { get; set; }

    }
}
