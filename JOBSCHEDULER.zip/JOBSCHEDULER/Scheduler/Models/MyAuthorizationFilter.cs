﻿using System;
using Hangfire.Dashboard;

namespace Scheduler.Models
{
    public class MyAuthorizationFilter : IDashboardAuthorizationFilter
    {
        public bool Authorize(DashboardContext context)
        {
            // Allow all authenticated users to see the Dashboard (potentially dangerous).
            return true;
        }
    }
}
