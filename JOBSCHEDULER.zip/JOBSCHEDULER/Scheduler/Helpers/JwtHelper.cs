﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Scheduler.Models;
using Scheduler.Services;

namespace Scheduler.Helpers
{
    public static class JwtHelper
    {
        public static string APIToken = "";


        public static async Task InspectTokenAsync()
        {
            if (APIToken != "")
            {
                var tokenExpiresAt = JWTService.GetExpiryTimestamp(APIToken);
                int result = DateTime.Compare(tokenExpiresAt, new DateTime());
                // The token has expired
                if (result < 0)
                {
                    await JwtHelper.GetNewTokenAsync();
                }
            }
            else { await JwtHelper.GetNewTokenAsync(); };
        }

        public static async Task GetNewTokenAsync()
        {
            try
            {
                var payload = new AuthRequest
                {
                    Email = Startup.StaticConfig.GetConnectionString("LoginUser"),
                    Password = Startup.StaticConfig.GetConnectionString("LoginPass"),
                };
                //client.BaseAddress = new Uri("http://localhost:5000/");
                var strigifyedPayload = JsonConvert.SerializeObject(payload);

                var httpContent = new StringContent(strigifyedPayload, Encoding.UTF8, "application/json");

                using (var httpClient = new HttpClient())
                {
                    // Do the actual request and await the response
                    var httpResponse = await httpClient.PostAsync(Startup.StaticConfig.GetConnectionString("ApiEndpoint") + "Auth/signIn", httpContent);

                    // If the response contains content we want to read it!
                    if (httpResponse.Content != null)
                    {
                        var responseContent = await httpResponse.Content.ReadAsStringAsync();
                        var response = JsonConvert.DeserializeObject<AuthResponse>(responseContent);
                        APIToken = response.Token;

                    }
                }
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
        }
    }
}
