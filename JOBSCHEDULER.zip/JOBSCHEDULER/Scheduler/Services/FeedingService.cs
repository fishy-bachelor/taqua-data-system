﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Scheduler.Helpers;
using Scheduler.Models;

namespace Scheduler.Services
{
    public class FeedingService
    {
        public static async Task GetAndUploadFeedingAsync()
        {
            await JwtHelper.InspectTokenAsync();
            var data = GetAllResData();
            _ = UploadDataAsync(data);
        }
        public static async Task UploadDataAsync(List<FeedingLog> data)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    httpClient.DefaultRequestHeaders.Authorization
                             = new AuthenticationHeaderValue("Bearer", JwtHelper.APIToken);
                    var strigifyedPayload = JsonConvert.SerializeObject(data);
                    var httpContent = new StringContent(strigifyedPayload, Encoding.UTF8, "application/json");
                    var httpResponse = await httpClient.PostAsync(Startup.StaticConfig.GetConnectionString("ApiEndpoint") + "FeedingLog", httpContent);
                    Console.WriteLine(httpResponse);
                }
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }

        }

        public static List<FeedingLog> GetAllResData()
        {
            var entities = new FeedingLogs

            {
                logs = new List<FeedingLog>()

            };
            var logsLength = RandomNumber(1, 10);
            for (int i = 0; i < logsLength; i++)
            {
                // Sperad logs evenly for every 10th minute
                //  var seconds = (10 * 60) / logsLength;
                //  var span = TimeSpan.FromSeconds(seconds * i);
                var span = TimeSpan.FromSeconds(i);
                //var span = TimeSpan.FromSeconds(-RandomDouble(70 * 3, 140 * 3));
                entities.logs.Add(new FeedingLog
                {
                    Amount = RandomDouble(10, 20),
                    Pool = RandomNumber(1, 8),
                    Type = 3,
                    ToEquipment = "Tank",
                    DateRecorded = DateTime.Now.Add(span)
                });
            }
            return entities.logs;
        }

        public static int RandomNumber(int min, int max)
        {
            var _random = new Random();
            return _random.Next(min, max);
        }

        public static double RandomDouble(int min, int max)
        {
            var _random = new Random();
            var number = min + _random.NextDouble() * (max - min);
            return number;
        }
    }
}

