﻿using System;
using System.IdentityModel.Tokens.Jwt;

namespace Scheduler.Services
{
    public class JwtToken
    {
        public long exp { get; set; }
    }
    public static class JWTService
    {
                

        public static DateTime GetExpiryTimestamp(string accessToken)
        {
            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.ReadJwtToken(accessToken);

            var tokenExpiresAt = token.ValidTo;
            return tokenExpiresAt;
        }
    }
}
